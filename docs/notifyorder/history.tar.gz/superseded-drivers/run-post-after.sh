#!/bin/bash
# The first final broad selection was refused for an explicitly selected build
# helper. Preserve the active differential chain; run the corrected selection
# once its PRE and unit jobs have released this CPU/port allocation.
set -u
cd /home/user/Projects/cx-notifyorder
for attempt in $(seq 18000); do
  [ -f docs/notifyorder/final-unit-status.log ] && rg -q '^freshness rc=' docs/notifyorder/final-unit-status.log && break
  sleep 1
done
rg -q '^freshness rc=' docs/notifyorder/final-unit-status.log || exit 2
mv docs/notifyorder/gate-broad-post.log docs/notifyorder/gate-broad-post-selection-refused.log
taskset -c 96-111 bash docs/notifyorder/run-proof.sh post
taskset -c 96-111 make -q all $(cat docs/notifyorder/production-targets.txt) \
  >docs/notifyorder/freshness-after-broad.log 2>&1
printf 'after-broad freshness rc=%s\n' "$?" >>docs/notifyorder/final-unit-status.log
