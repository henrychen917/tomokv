#!/bin/bash
set -u
cd /home/user/Projects/cx-notifyorder
# Wait only for the already-running directed PRE/POST/PAD gate chain.
for attempt in $(seq 900); do
  [ "$(wc -l <docs/notifyorder/directed-status.log)" -ge 3 ] && break
  sleep 1
done
[ "$(wc -l <docs/notifyorder/directed-status.log)" -ge 3 ] || exit 2
export REDIS74_ROOT=/home/user/Projects/redis
export GATE_DIFFER_ORACLE_BIN="$PWD/docs/notifyorder/oracle-104"
export GATE_NOTIFY_ORACLE_CORES=104
GATE_ONLY_JOBS=notify_order taskset -c 96-111 bash tests/gate.sh quick \
  --server-cores 96-104 --load-cores 105-111 --load-smt '' --ports 25800-25899 \
  --candidate-binary "$PWD/build/notifyorder/tomokv-no-salvage" \
  >docs/notifyorder/gate-no-salvage.log 2>&1
printf 'no-salvage server rc=%s\n' "$?" >>docs/notifyorder/proof-status.log
# Gate's unit job names build/netcmd-unit literally. Substitute the throwaway
# entry-patched control only for this serverless job, and restore on every exit.
cp -p build/netcmd-unit build/notifyorder/netcmd-unit-positive
restore_unit(){ cp -p build/notifyorder/netcmd-unit-positive build/netcmd-unit; }
trap restore_unit EXIT INT TERM
cp build/notifyorder/netcmd-unit-no-salvage build/netcmd-unit
GATE_ONLY_JOBS=netcmd_units taskset -c 96-111 bash tests/gate.sh quick \
  --server-cores 96-104 --load-cores 105-111 --load-smt '' --ports 25800-25899 \
  --candidate-binary "$PWD/build/tomokv" >docs/notifyorder/gate-no-salvage-unit.log 2>&1
printf 'no-salvage unit rc=%s\n' "$?" >>docs/notifyorder/proof-status.log
restore_unit
trap - EXIT INT TERM
taskset -c 96-111 bash docs/notifyorder/run-proof.sh post
taskset -c 96-111 bash docs/notifyorder/run-proof.sh differ
taskset -c 96-111 bash docs/notifyorder/run-proof.sh pre
