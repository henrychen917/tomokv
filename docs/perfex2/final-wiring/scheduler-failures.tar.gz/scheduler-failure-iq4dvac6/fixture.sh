set -u
PASS=0; FAIL=0; TIER=full; CORES=0; LOAD_CORES=0; PORT=19000; GATE_RATIO=6:2; ALL_BUILD_CORES=0
GATE_PARTIAL=${WIRE_PARTIAL:-0}
source tests/gate_subset.sh
LEDGER="$RUN_DIR/ledger"; TIMINGS="$RUN_DIR/timings"; ROW_T=$(date +%s.%N)
: > "$LEDGER"; : > "$TIMINGS"
mkdir -p "$RUN_DIR/jobs" "$RUN_DIR/started" "$RUN_DIR/completed"
mkfifo "$RUN_DIR/pause"; exec 3<>"$RUN_DIR/pause"
pause(){ read -r -t .02 -u 3 ignored || :; }
phase(){ :; }
quiet_wait(){ :; }
ROW_HISTORY="$RUN_DIR/history"; ROW_RUN_ID=test; ROW_PLAN="$RUN_DIR/plan.json"
export GATE_DIFFER_HISTORY="$RUN_DIR/differ-history"
python3 tests/gate_history.py prepare --history "$ROW_HISTORY" --output "$ROW_PLAN"
cleanup(){ row_unwatch; [ -z "${name:-}" ] || : > "$TMPDIR/cleaned"; }
reap_children(){ :; } # Real teardown is covered by gate_history's owned-process controls.

GATE_SLOTS=134
CANONICAL=(release asan config_unit flip_unit filter_unit ring_unit climonfix racefix_counters racefix_climon lbplanner_units exbatch_units exbatch_live persistfix_units perfex_units perfex_live clientfix core_units flipfix_units wb_rule_units wbland_units reorder_sync reorder_engagement reorder_identity wb_policy lb-stationary-1s lb-stationary-2s netio-1s netio-2s splitlocal_units storage_units atomic_units netcmd_units netcap respcompat acl_metadata boot_grammar cmd_metadata wait_units readonly release_batteries atomic_batteries feature-split-0 feature-split-1 fused-0 fused-1 feature-armed-0 feature-armed-1 evict-lfu-split-0 evict-lfu-armed-0 evict-lruclock-split-0 evict-lruclock-armed-0 evict-lfu-split-1 evict-lfu-armed-1 evict-lruclock-split-1 evict-lruclock-armed-1 bplus acl_recheck aclfix sort debug-0 debug-1 script_bounds scriptfix efficiency dump_restore auth authfix snapshot-epoll snapshot-uring notify flip flipctl flip_saturated atomic_floor aof-epoll aof-uring aof_frame tls feature-cell-1s-0-0-0-0 feature-cell-1s-0-0-0-1 feature-cell-1s-0-0-1-0 feature-cell-1s-0-0-1-1 feature-cell-1s-0-1-0-0 feature-cell-1s-0-1-0-1 feature-cell-1s-0-1-1-0 feature-cell-1s-0-1-1-1 feature-cell-1s-1-0-0-0 feature-cell-1s-1-0-0-1 feature-cell-1s-1-0-1-0 feature-cell-1s-1-0-1-1 feature-cell-1s-1-1-0-0 feature-cell-1s-1-1-0-1 feature-cell-1s-1-1-1-0 feature-cell-1s-1-1-1-1 feature-cell-2s-0-0-0-0 feature-cell-2s-0-0-0-1 feature-cell-2s-0-0-1-0 feature-cell-2s-0-0-1-1 feature-cell-2s-0-1-0-0 feature-cell-2s-0-1-0-1 feature-cell-2s-0-1-1-0 feature-cell-2s-0-1-1-1 feature-cell-2s-1-0-0-0 feature-cell-2s-1-0-0-1 feature-cell-2s-1-0-1-0 feature-cell-2s-1-0-1-1 feature-cell-2s-1-1-0-0 feature-cell-2s-1-1-0-1 feature-cell-2s-1-1-1-0 feature-cell-2s-1-1-1-1 feature-cell-split-home-min feature-cell-fused-home-max-nopin feature-cell-split-shards-auto abba_selftest multidb-1s-0-0 multidb-1s-0-1 multidb-1s-1-0 multidb-1s-1-1 multidb-2s-0-0 multidb-2s-0-1 multidb-2s-1-0 multidb-2s-1-1 asan_batteries replyoff zc rldbg rlcache differ-split-0 differ-split-1 differ-equivalence differ-armed-0 differ-armed-1 globcase)
COMPLETION_ORDER=(release asan config_unit flip_unit filter_unit ring_unit climonfix racefix_counters racefix_climon lbplanner_units exbatch_units exbatch_live persistfix_units perfex_units perfex_live clientfix core_units flipfix_units wb_rule_units wbland_units reorder_sync reorder_engagement reorder_identity wb_policy lb-stationary-1s lb-stationary-2s netio-1s netio-2s splitlocal_units storage_units atomic_units netcmd_units netcap respcompat acl_metadata boot_grammar cmd_metadata wait_units readonly release_batteries feature-split-0 feature-split-1 fused-0 fused-1 feature-armed-0 feature-armed-1 evict-lfu-split-0 evict-lfu-armed-0 evict-lruclock-split-0 evict-lruclock-armed-0 evict-lfu-split-1 evict-lfu-armed-1 evict-lruclock-split-1 evict-lruclock-armed-1 bplus acl_recheck aclfix sort debug-0 debug-1 script_bounds scriptfix efficiency dump_restore auth authfix snapshot-epoll snapshot-uring notify flip flipctl flip_saturated atomic_floor aof-epoll aof-uring aof_frame tls feature-cell-1s-0-0-0-0 feature-cell-1s-0-0-0-1 feature-cell-1s-0-0-1-0 feature-cell-1s-0-0-1-1 feature-cell-1s-0-1-0-0 feature-cell-1s-0-1-0-1 feature-cell-1s-0-1-1-0 feature-cell-1s-0-1-1-1 feature-cell-1s-1-0-0-0 feature-cell-1s-1-0-0-1 feature-cell-1s-1-0-1-0 feature-cell-1s-1-0-1-1 feature-cell-1s-1-1-0-0 feature-cell-1s-1-1-0-1 feature-cell-1s-1-1-1-0 feature-cell-1s-1-1-1-1 feature-cell-2s-0-0-0-0 feature-cell-2s-0-0-0-1 feature-cell-2s-0-0-1-0 feature-cell-2s-0-0-1-1 feature-cell-2s-0-1-0-0 feature-cell-2s-0-1-0-1 feature-cell-2s-0-1-1-0 feature-cell-2s-0-1-1-1 feature-cell-2s-1-0-0-0 feature-cell-2s-1-0-0-1 feature-cell-2s-1-0-1-0 feature-cell-2s-1-0-1-1 feature-cell-2s-1-1-0-0 feature-cell-2s-1-1-0-1 feature-cell-2s-1-1-1-0 feature-cell-2s-1-1-1-1 feature-cell-split-home-min feature-cell-fused-home-max-nopin feature-cell-split-shards-auto abba_selftest multidb-1s-0-0 multidb-1s-0-1 multidb-1s-1-0 multidb-1s-1-1 multidb-2s-0-0 multidb-2s-0-1 multidb-2s-1-0 multidb-2s-1-1 asan_batteries replyoff zc rldbg rlcache differ-split-0 differ-split-1 differ-equivalence differ-armed-0 differ-armed-1 globcase atomic_batteries)
SLOT_CORES=(120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121)
SLOT_LOAD_CORES=(120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121 122 123 120 121)
SLOT_PORTS=(19000 19003 19006 19009 19012 19015 19018 19021 19024 19027 19030 19033 19036 19039 19042 19045 19048 19051 19054 19057 19060 19063 19066 19069 19072 19075 19078 19081 19084 19087 19090 19093 19096 19099 19102 19105 19108 19111 19114 19117 19120 19123 19126 19129 19132 19135 19138 19141 19144 19147 19150 19153 19156 19159 19162 19165 19168 19171 19174 19177 19180 19183 19186 19189 19192 19195 19198 19201 19204 19207 19210 19213 19216 19219 19222 19225 19228 19231 19234 19237 19240 19243 19246 19249 19252 19255 19258 19261 19264 19267 19270 19273 19276 19279 19282 19285 19288 19291 19294 19297 19300 19303 19306 19309 19312 19315 19318 19321 19324 19327 19330 19333 19336 19339 19342 19345 19348 19351 19354 19357 19360 19363 19366 19369 19372 19375 19378 19381 19384 19387 19390 19393 19396 19399)
say(){ printf '  %-52s %s\n' "$1" "$2"; }
canonical_label(){ sed -E \
      -e 's/(direct|hits|records|skipped|suppressed|zc_sends)=[0-9]+/\1=N/g' \
      -e 's/(dispatched==executed) \([0-9]+\)/\1 (N)/' \
      -e 's/(atomic MGET\/MSET floor) \([0-9]+\/s/\1 (N\/s/' \
      -e 's/(TLS connection slots all freed) \([0-9]+\/[0-9]+\)/\1 (N\/N)/'; }
# Explicit scopes begin before the row's work, including compound shell assertions. A
# watchdog bounds the WHOLE row rather than only Python: compiler, redis-cli, pipelines,
# shell loops and waits all count. On expiry the family stops red; later rows are visibly
# unreached through the existing completion/count checks. No timeout becomes a skip.
ROW_ID=; ROW_WATCHDOG=0; ROW_EXPIRED=0; ROW_START=0; ROW_PAUSED=0
ROW_WATCH_SEQUENCE=0; ROW_WATCHDOG_START=0; ROW_WATCH_PARENT=0; ROW_WATCH_PARENT_START=0
row_clock(){
  # Kernel uptime is monotonic and has 10 ms resolution. A wall-clock/NTP step
  # must neither manufacture an expiry nor extend a hung row's measured history.
  # Bash reads it directly, avoiding another Python startup for every endpoint.
  read -r ROW_NOW row_idle < /proc/uptime || exit 2
}
row_watch(){
  local parent_stat parent_start remaining parent_pid=$BASHPID
  read -r parent_stat < "/proc/$BASHPID/stat"
  parent_stat=${parent_stat##*) }; read -ra parent_fields <<< "$parent_stat"
  parent_start=${parent_fields[19]}
  ROW_WATCH_PARENT=$parent_pid; ROW_WATCH_PARENT_START=$parent_start
  ROW_WATCH_SEQUENCE=$((${ROW_WATCH_SEQUENCE:-0}+1))
  ROW_WATCH_GENERATION="$parent_pid.$parent_start.$ROW_WATCH_SEQUENCE"
  ROW_WATCH_CANCEL="${ROW_MARKER%.json}.$ROW_WATCH_GENERATION.cancel"
  ROW_WATCH_RECEIPT="${ROW_MARKER%.json}.$ROW_WATCH_GENERATION.cancelled"
  row_clock
  remaining=$(awk -v budget="$ROW_TIMEOUT" -v start="$ROW_START" -v now="$ROW_NOW" -v paused="$ROW_PAUSED" \
      'BEGIN {v=budget-(now-start-paused); print (v>0?v:0.001)}')
  python3 tests/gate_history.py watch --pid "$parent_pid" --parent-start "$parent_start" \
      --seconds "$remaining" --marker "$ROW_MARKER" --generation "$ROW_WATCH_GENERATION" \
      --cancel-request "$ROW_WATCH_CANCEL" --cancel-receipt "$ROW_WATCH_RECEIPT" &
  ROW_WATCHDOG=$!
  ROW_WATCHDOG_START=0
  if { read -r parent_stat < "/proc/$ROW_WATCHDOG/stat"; } 2>/dev/null; then
    parent_stat=${parent_stat##*) }; read -ra parent_fields <<< "$parent_stat"
    [ "${parent_fields[1]}" != "$parent_pid" ] || ROW_WATCHDOG_START=${parent_fields[19]}
  fi
}
row_watch_probe(){
  local state fields
  ROW_WATCH_STATE=gone
  if { read -r state < "/proc/$ROW_WATCHDOG/stat"; } 2>/dev/null; then
    state=${state##*) }; read -ra fields <<< "$state"
    if [ "${fields[1]}" != "${ROW_WATCH_PARENT:-0}" ] ||
        [ "${fields[19]}" != "${ROW_WATCHDOG_START:-0}" ] ||
        [ "$BASHPID" != "${ROW_WATCH_PARENT:-0}" ]; then
      ROW_WATCH_STATE=mismatch
    else ROW_WATCH_STATE=${fields[0]}
    fi
  fi
}
row_watch_clock(){
  local uptime idle whole fraction
  read -r uptime idle < /proc/uptime || return 1
  whole=${uptime%.*}; fraction=${uptime#*.}00
  ROW_WATCH_CLOCK=$((10#$whole*100+10#${fraction:0:2}))
}
row_watch_receipt(){
  local line expected lines=()
  [ -f "${ROW_WATCH_RECEIPT:-}" ] || return 1
  mapfile -t lines < "$ROW_WATCH_RECEIPT"
  [ "${#lines[@]}" = 1 ] || return 1
  IFS= read -r line < "$ROW_WATCH_RECEIPT" || return 1
  printf -v expected 'CANCELLED\t%s\t%s\t%s\t%s\t%s' "$ROW_WATCH_PARENT" "$ROW_WATCH_PARENT_START" \
      "$ROW_WATCHDOG" "$ROW_WATCHDOG_START" "$ROW_WATCH_GENERATION"
  [ "$line" = "$expected" ]
}
row_unwatch(){
  local watcher_rc=0 until expired=0 forced=0 can_wait=1
  if [ "$ROW_WATCHDOG" -gt 0 ]; then
    # Captured 2026-09-10: TERM in Bash's fork/exec transition was lost, leaving three
    # Python watchers sleeping for 900s while their parents waited forever. An EXIT-owner
    # guard prevents false publication but cannot make that first signal reliable.
    # Publish a generation-specific request before TERM; a child that starts afterwards
    # acknowledges it. Pause/rearm generations never share cancellation evidence.
    row_watch_probe
    if [ "$ROW_WATCH_STATE" != gone ] && [ "$ROW_WATCH_STATE" != Z ] &&
        [ "$ROW_WATCH_STATE" != mismatch ] && [ ! -f "$ROW_MARKER" ]; then
      if ! { printf 'CANCEL\t%s\t%s\t%s\t%s\t%s\n' "$ROW_WATCH_PARENT" "$ROW_WATCH_PARENT_START" \
          "$ROW_WATCHDOG" "$ROW_WATCHDOG_START" "$ROW_WATCH_GENERATION" > "$ROW_WATCH_CANCEL.tmp" &&
          mv "$ROW_WATCH_CANCEL.tmp" "$ROW_WATCH_CANCEL"; }; then ROW_MONITOR_FAILED=1; fi
      kill -TERM "$ROW_WATCHDOG" 2>/dev/null || :
    fi
    row_watch_clock || { ROW_MONITOR_FAILED=1; return 1; }
    until=$((ROW_WATCH_CLOCK+500)) # Match watch()'s existing five-second cleanup grace.
    while :; do
      row_watch_probe
      case "$ROW_WATCH_STATE" in
        gone|Z) break;;
        mismatch)
          ROW_MONITOR_FAILED=1; can_wait=0
          say "$ROW_ID" 'FAIL (row watchdog PID/start or direct-parent identity changed)'
          break;;
      esac
      row_watch_clock || { ROW_MONITOR_FAILED=1; can_wait=0; break; }
      if [ -f "$ROW_MARKER" ] && [ "$expired" = 0 ]; then
        # Expiry owns descendant reclamation. Allow its full five seconds plus one
        # second for marker publication/scheduling; never TERM/KILL it immediately.
        expired=1; until=$((ROW_WATCH_CLOCK+600))
      fi
      if [ "$ROW_WATCH_CLOCK" -ge "$until" ]; then
        forced=1; ROW_MONITOR_FAILED=1
        say "$ROW_ID" 'FAIL (row watchdog cancellation/expiry cleanup exceeded its bounded grace)'
        # This exceptional path pays for a pidfd helper so PID reuse across inspection
        # and SIGKILL cannot touch another process. Forced cleanup can never turn green.
        python3 tests/gate_history.py signal-child --pid "$ROW_WATCHDOG" --start "$ROW_WATCHDOG_START" \
            --parent "$ROW_WATCH_PARENT" --parent-start "$ROW_WATCH_PARENT_START" || :
        row_watch_clock || { can_wait=0; break; }
        until=$((ROW_WATCH_CLOCK+100))
        while :; do
          row_watch_probe
          case "$ROW_WATCH_STATE" in gone|Z) break;; mismatch) can_wait=0; break;; esac
          row_watch_clock || { can_wait=0; break; }
          [ "$ROW_WATCH_CLOCK" -lt "$until" ] || { can_wait=0; break; }
          sleep .01
        done
        break
      fi
      sleep .01
    done
    # A published timeout owns its five-second kill escalation. Let it finish so a
    # TERM-ignoring child cannot survive the correctness barrier into performance.
    # wait is reached only after this exact child is gone/zombie, never while it runs.
    if [ "$can_wait" = 1 ]; then
      wait "$ROW_WATCHDOG" 2>/dev/null || watcher_rc=$?
    else
      watcher_rc=255; ROW_MONITOR_FAILED=1
      say "$ROW_ID" 'FAIL (row watchdog remains live/unowned; refusing an unbounded wait)'
    fi
    if [ "$watcher_rc" != 143 ] &&
        { [ "$watcher_rc" != 0 ] || { [ ! -f "$ROW_MARKER" ] && ! row_watch_receipt; }; }; then
      ROW_MONITOR_FAILED=1
      say "$ROW_ID" "FAIL (row watchdog exited unexpectedly: $watcher_rc)"
    fi
    ROW_WATCHDOG=0
    [ "$forced" = 0 ] && [ "$can_wait" = 1 ] || return 1
  fi
}
row_begin(){
  if [ -n "$ROW_ID" ]; then
    bad "$ROW_ID" "row scope was replaced without a verdict"
    exit 2
  fi
  quiet_wait
  ROW_ID=$(printf '%s\n' "$1" | canonical_label)
  ROW_HISTORY_ID="$ROW_ID${2:+ [$2]}"
  local budget
  budget=$(python3 tests/gate_history.py budget --correctness --plan "$ROW_PLAN" \
      --label "$ROW_HISTORY_ID" --base-label "$ROW_ID") || exit 2
  IFS=$'\t' read -r ROW_TIMEOUT ROW_MEDIAN ROW_BASIS <<< "$budget"
  # The ABBA row's recorded history is dominated by runs that aborted before measuring (median
  # 0.42s), so a history-derived budget kills every genuine measurement at 30s -- three overnight
  # rounds on 2026-09-13 died exactly that way. The row only reports now; give it the full-matrix
  # budget on every basis, including the 900s no-history default and explicit plan entries.
  if [ "$ROW_ID" = 'headline ABBA vs last pushed binary' ]; then
    # Only timeout negative controls override the production full-matrix budget.
    ROW_TIMEOUT=${GATE_ABBA_ROW_BUDGET_S:-43200}; ROW_BASIS=abba-full-matrix-not-history
  fi
  if [ "$ROW_ID" = 'tailgen client-lb outstanding bound' ]; then
    ROW_TIMEOUT=90; ROW_BASIS=tailgen-populate-3s-warmup-20s-window
  fi
  ROW_MARKER="$TMPDIR/row-timeout-$BASHPID.json"
  rm -f "$ROW_MARKER"
  row_clock
  ROW_EXPIRED=0; ROW_MONITOR_FAILED=0; ROW_PAUSED=0; ROW_START=$ROW_NOW
  trap row_timeout USR1
  row_watch
  printf '  row budget: %ss; median=%ss; %s; %s\n' "$ROW_TIMEOUT" "$ROW_MEDIAN" "$ROW_BASIS" "$ROW_ID"
}
row_timeout(){
  trap '' USR1
  ROW_EXPIRED=1
  ledger FAIL "${ROW_ID:-row watchdog}"
  exit 124
}
row_finish(){
  row_clock
  local now=$ROW_NOW
  row_unwatch
  ROW_SECONDS=$(awk -v start="$ROW_START" -v now="$now" -v paused="$ROW_PAUSED" \
      'BEGIN {v=now-start-paused; printf "%.6f", (v>0?v:0)}')
  if [ -f "$ROW_MARKER" ] || awk -v elapsed="$ROW_SECONDS" -v budget="$ROW_TIMEOUT" 'BEGIN {exit !(elapsed>=budget)}'; then
    ROW_EXPIRED=1
  fi
}
row_save_history(){
  local verdict=$1 scored=${2:-1} timed=() identity=()
  [ "$ROW_EXPIRED" != 1 ] || { verdict=FAIL; timed=(--timed-out); }
  [ "${ROW_MONITOR_FAILED:-0}" = 0 ] || verdict=FAIL
  [ "$scored" != 1 ] || identity=(--ledger-label "$ROW_ID")
  python3 tests/gate_history.py record --history "$ROW_HISTORY" --run-id "$ROW_RUN_ID" \
      --label "$ROW_HISTORY_ID" --seconds "$ROW_SECONDS" --verdict "$verdict" \
      --scored "$scored" "${identity[@]}" "${timed[@]}"
}
ledger(){
  local verdict=$1 label=$2 scored=${3:-1} identity duration
  if [ -n "$ROW_ID" ]; then
    row_finish
    identity=$ROW_ID; duration=$ROW_SECONDS
    [ "${ROW_MONITOR_FAILED:-0}" = 0 ] || verdict=FAIL
    if [ "$ROW_EXPIRED" = 1 ]; then
      verdict=FAIL
      # TIMEOUT is distinct in the report and timed_out history; it still fails the gate.
      say "$identity" "TIMEOUT ${ROW_TIMEOUT}s; median=${ROW_MEDIAN}s; $ROW_BASIS"
    fi
    row_save_history "$verdict" "$scored" || exit 2
  else
    # Infrastructure failures (boot/worker/count) are red even without a normal row
    # scope. An unscoped SUCCESS is a harness defect, never manufactured zero timing.
    verdict=FAIL; duration=0
    identity=$(printf '%s\n' "$label" | canonical_label)
    [ "$1" != ok ] || say "$identity" 'FAIL (row was not timed: missing row_begin)'
  fi
  printf '%s\t%s\t%s\n' "$verdict" "$duration" "$identity" >> "$LEDGER"
  printf '%s\t%s\t%s\n' "$verdict" "$duration" "$label" >> "$TIMINGS"
  if [ "$verdict" = ok ]; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); fi
  ROW_ID=; ROW_EXPIRED=0
  trap - USR1
}
ok(){ say "$1" "ok"; ledger ok "$1"; }
bad(){ say "$1" "FAIL${2:+ ($2)}"; ledger FAIL "$1"; }
set_slot(){
  local slot=$1
  CORES=${SLOT_CORES[$slot]}; LOAD_CORES=${SLOT_LOAD_CORES[$slot]}; PORT=${SLOT_PORTS[$slot]}
  export GATE_CORES="$CORES" GATE_LOAD_CORES="$LOAD_CORES" GATE_PORT="$PORT"
  export GATE_FEATURE_PORT="$PORT" GATE_SPARE_PORT="$((PORT+2))"
  export GATE_DIFFER_ORACLE_PORT="$((PORT+1))" GATE_GLOBCASE_ORACLE_PORT="$((PORT+2))"
  export GATE_DIFFER_ORACLE_CORES="$CORES"
  taskset -pc "$LOAD_CORES" "$BASHPID" >/dev/null
}
WORKER_PIDS=()
JOB_NAMES=()
# ---- feature batteries: every shipped feature's directed test, BOTH atomic settings -----------
# The gate accumulates a section per landed feature (owner rule). Each test is directed and
# asserts its own mechanisms fired; the boot covers multi/blocking/pubsub+sharded/lua/limits.
# ONE list, shared with the fused+armed leg below, so the two legs cannot drift apart: a battery
# added here runs on the armed lane too, and the ledger arithmetic counts it twice per atomic mode.
FEATURE_BATTERIES="s6 multi_exec blocking blockmulti stream streamgroups pubsub lua_scripting scriptsurf limits resp3 bitfield dumprestore zsetops geo climon climon2 tracking hexpire servertail lcs concur edgeproto edgeenc edgetime arity contarity cmdgap aclsel expwide infofix pushtear netcmd"
feature_split_job(){
  local AT=$1 t FEATURE_ARGS
  boot "$CANDIDATE_BINARY" --atomic $AT --enable-debug-command yes \
      || bad "feature battery boot (atomic $AT)"
  for t in $FEATURE_BATTERIES; do
    FEATURE_ARGS=()
    [ "$t" = stream ] && FEATURE_ARGS+=(--release-build)
    row_begin "$t battery (atomic $AT)"
    py tests/$t.py 127.0.0.1 $PORT "${FEATURE_ARGS[@]}" >$TMPDIR/gate-$t-$AT.txt 2>&1 \
        && ok "$t battery (atomic $AT)" || bad "$t battery (atomic $AT)" "see $TMPDIR/gate-$t-$AT.txt"
  done
  stop
  row_begin "feature shutdown invariants (atomic $AT)"
  shutdown_clean \
      && ok "feature shutdown invariants (atomic $AT)" || bad "feature shutdown invariants (atomic $AT)"
}

# ---- FUSED + read-local ARMED: the recommended read-heavy posture runs the whole feature list ----
# The fused boots above never arm the local read lane, so until this leg no gate row had run a
# feature battery on the path that serves every clean GET/MGET in that posture. The boot row asserts
# the WIRE says so: INFO server thread_mode:1s AND read_local:1 -- the effective lane state, and the
# boot banner must agree with that resolved state. The shutdown row is the
# leg's vacuity guard: the lane's own hit counters must have moved during the batteries, or the 32
# rows between ran on the owner path and proved nothing about the armed one.
sample_armed_lane(){
  local label=$1 info hits
  info=$(redis-cli -h 127.0.0.1 -p "$PORT" INFO stats 2>/dev/null | tr -d '\r')
  hits=$(awk -F: '/^read_local_keyspace_hits:|^read_local_mget_local_hits:/{
      if ($2 !~ /^[0-9]+$/) invalid=1; n++; s+=$2
    } END {if (n==2 && !invalid) printf "%.0f\n", s; else exit 1}' <<<"$info")
  if ! [[ "$hits" =~ ^[0-9]+$ ]]; then
    ARMED_SAMPLE_FAILED=1
    printf '%s\tINVALID\n' "$label" >> "$TMPDIR/read-local-armed-$AT.tsv"
    return 1
  fi
  [ "$hits" -le "$ARMED_HITS" ] || ARMED_HITS=$hits
  printf '%s\t%s\n' "$label" "$hits" >> "$TMPDIR/read-local-armed-$AT.tsv"
}

feature_armed_job(){
  local AT=$1 t FEATURE_ARGS ARMED_INFO ARMED_MODE ARMED_RL ARMED_HITS ARMED_REPORT_MODE ARMED_REPORT_KIND
  local ARMED_SAMPLE_FAILED=0
  ARMED_HITS=0
  printf 'battery\thits\n' > "$TMPDIR/read-local-armed-$AT.tsv"
  row_begin "fused+armed boot line (atomic $AT)"
  if boot_fused "$CANDIDATE_BINARY" --atomic "$AT" --read-local 1 --enable-debug-command yes; then
    ARMED_INFO=$(redis-cli -h 127.0.0.1 -p "$PORT" INFO server 2>/dev/null | tr -d '\r')
    ARMED_MODE=$(printf '%s\n' "$ARMED_INFO" | sed -n 's/^thread_mode://p')
    ARMED_RL=$(printf '%s\n' "$ARMED_INFO" | sed -n 's/^read_local://p')
    [ "$ARMED_MODE" = 1s ] && [ "$ARMED_RL" = 1 ] \
        && grep -Eq '^tomokv-cpp: .*thread-mode=1s,.*read-local=1([,[:space:]]|$)' "$SRVLOG" \
        && ok "fused+armed boot line (atomic $AT)" \
        || bad "fused+armed boot line (atomic $AT)" "wire mode=$ARMED_MODE read_local=$ARMED_RL; banner must agree; see $SRVLOG"
  else
    bad "fused+armed boot line (atomic $AT)" "server did not boot; see $SRVLOG"
  fi
  for t in $FEATURE_BATTERIES; do
    FEATURE_ARGS=()
    [ "$t" = stream ] && FEATURE_ARGS+=(--release-build)
    row_begin "fused+armed $t battery (atomic $AT)"
    py tests/$t.py 127.0.0.1 $PORT "${FEATURE_ARGS[@]}" >$TMPDIR/gate-fusedarmed-$t-$AT.txt 2>&1 \
        && ok "fused+armed $t battery (atomic $AT)" \
        || bad "fused+armed $t battery (atomic $AT)" "see $TMPDIR/gate-fusedarmed-$t-$AT.txt"
    # RESETSTAT in a later battery must not erase an observed execution of this lane.
    # No synthetic reads: witness the actual battery, and latch malformed INFO as a failure.
    sample_armed_lane "$t" || :
  done
  row_begin "fused+armed shutdown report + lane fired (hits=N, atomic $AT)"
  sample_armed_lane final || :
  stop
  ARMED_REPORT_MODE=$(shutdown_value thread_mode)
  ARMED_REPORT_KIND=$(shutdown_value work.kind)
  shutdown_clean && [ "$ARMED_REPORT_MODE" = 1s ] && [ "$ARMED_REPORT_KIND" = fused ] \
      && [ "$ARMED_SAMPLE_FAILED" -eq 0 ] && [ "$ARMED_HITS" -gt 0 ] \
      && ok "fused+armed shutdown report + lane fired (hits=$ARMED_HITS, atomic $AT)" \
      || bad "fused+armed shutdown report + lane fired (atomic $AT)" \
             "mode=$ARMED_REPORT_MODE kind=$ARMED_REPORT_KIND peak_hits=$ARMED_HITS sample_failed=$ARMED_SAMPLE_FAILED; see $SRVLOG"
}

job_label(){
  case "$1" in
    feature-split-*) echo "s6 battery (atomic ${1##*-})";;
    feature-armed-*) echo "fused+armed boot line (atomic ${1##*-})";;
    differ-split) echo 'Redis 7.4 differential matrix';;
    differ-armed) echo 'Redis 7.4 differential matrix (armed fused + read-local)';;
    differ-split-[01]) echo "Redis 7.4 differential part (split, atomic ${1##*-})";;
    differ-armed-[01]) echo "Redis 7.4 differential part (armed fused, atomic ${1##*-})";;
    differ-equivalence) echo 'mode equivalence part (all execution modes and knobs)';;
    flipctl) echo 'flip controller: ramp gate, hold, surge + mix re-maneuvers';;
    evict-*) local kind section mode atomic
      IFS=- read -r kind section mode atomic <<< "$1"
      [ "$mode" != armed ] || mode=fused+armed
      echo "eviction $section battery ($mode, atomic $atomic)";;
    feature-cell-*) echo "feature ${1#feature-cell-}";;
    *) echo "correctness family $1";;
  esac
}
job_body(){
  local name=$1 label; label=$(job_label "$name")
  case "$name" in
    multidb-*) job_multidb "$name";;
    feature-cell-*) job_feature_cell "$name";;
    snapshot-*) job_snapshot "$name";;
    aof-*) job_aof "$name";;
    debug-*) job_debug "$name";;
    fused-*) job_fused "$name";;
    netio-*) job_netio "${name##*-}";;
    lb-stationary-*) job_lb_stationary "${name##*-}";;
    feature-split-*) feature_split_job "${name##*-}";;
    feature-armed-*) feature_armed_job "${name##*-}";;
    differ-*)
      export GATE_DIFFER_GEOMETRY=split
      export GATE_DIFFER_OUT="$TMPDIR/differ"
      export GATE_DIFFER_PART="${name#differ-}" GATE_DIFFER_PLAN="$RUN_DIR/differ-plan.json"
      [[ "$name" != differ-armed-* ]] || export GATE_DIFFER_GEOMETRY=armed-fused
      row_begin "$label"
      # Private rows retain their watchdog and verdict evidence. Only the two complete folds
      # below are scored publicly; all atomic lifetimes and every equivalence stream are required.
      if tests/differ_gate.sh "$CANDIDATE_BINARY" "$PORT" "$((PORT+1))" "$CORES" "$GATE_RATIO"; then
        say "$label" ok; ledger ok "$label" 0
      else
        say "$label" FAIL; ledger FAIL "$label" 0
      fi;;
    evict-*)
      local kind section mode atomic
      IFS=- read -r kind section mode atomic <<< "$name"
      if [ "$mode" = split ]; then
        boot "$CANDIDATE_BINARY" --atomic "$atomic" || bad "eviction $section boot (split, atomic $atomic)"
      else
        boot_fused "$CANDIDATE_BINARY" --atomic "$atomic" --read-local 1 \
            || bad "eviction $section boot (fused+armed, atomic $atomic)"
      fi
      row_begin "$label"
      py tests/evict_battery.py "$PORT" "$section" >"$TMPDIR/battery.log" 2>&1 \
          && ok "$label" || bad "$label" "see $TMPDIR/battery.log"
      stop;;
    flipctl)
      boot "$CANDIDATE_BINARY" --ratio 6:2 --atomic 0 --enable-debug-command yes --flip-auto 1 \
          || bad 'flipctl boot'
      # Retain the original bounded stationary-hold re-rolls and every directed assertion.
      row_begin "$label"
      python3 tests/flipctl.py --host 127.0.0.1 --port "$PORT" --stable-seconds 30 \
          >"$TMPDIR/battery.log" 2>&1 && ok "$label" || bad "$label" "see $TMPDIR/battery.log"
      stop;;
    *) "job_$name";;
  esac
}
job_recover(){
  local name=$1 slot=$2 rc=$3 dir="$RUN_DIR/jobs/$1" label now
  [ ! -f "$dir/done" ] || return 0
  mkdir -p "$dir"
  touch "$dir/ledger" "$dir/timings" # Preserve earlier verdicts if the finalizer was interrupted.
  label=$(job_label "$name")
  if ! grep -q $'^FAIL\t' "$dir/ledger"; then
    # Unreached infrastructure has no measured row scope; zero is explicit, and must
    # never enter exact timing history. Both ledger formats retain their three columns.
    printf 'FAIL\t0\t%s\n' "$label" >> "$dir/ledger"
    printf 'FAIL\t0\t%s\n' "$label" >> "$dir/timings"
  fi
  printf 'GATE: family %s did not publish completion (exit %s); partial rows retained\n' \
      "$name" "$rc" >> "$dir/output.log"
  [ "$rc" != 0 ] || rc=1
  now=$(date +%s.%N)
  [ -f "$dir/family.tsv" ] || printf '%s\t%s\t%s\t%s\n' "$name" "$slot" "$now" "$now" > "$dir/family.tsv"
  printf '%s\t%s\t%s\n' "$rc" \
      "$(awk -F '\t' '$1=="ok"{n++} END{print n+0}' "$dir/ledger")" \
      "$(awk -F '\t' '$1=="FAIL"{n++} END{print n+0}' "$dir/ledger")" > "$dir/done.tmp"
  mv "$dir/done.tmp" "$dir/done"
}
job_finalize(){
  # A fast row can cancel its watchdog after fork but before Python exec. Bash may then
  # run the inherited EXIT trap in that child (captured 2026-09-10), while its parent correctly
  # waits status143. Only the worker may publish its ledger/done or reclaim its children.
  # Keep row_unwatch's unexpected-status checks: this fixes ownership, not the verdict rule.
  [ "$BASHPID" = "$CLEANUP_OWNER" ] || return 0
  local rc=$1 ended
  trap - EXIT INT TERM
  if [ -n "$ROW_ID" ]; then
    bad "$ROW_ID" "family exited $rc before this row produced a verdict"
    [ "$rc" != 0 ] || rc=1
  fi
  if ! cleanup; then
    bad "$(job_label "$name")" "owned process teardown did not complete"
    rc=1
  fi
  if [ "$rc" != 0 ] && ! grep -q $'^FAIL\t' "$LEDGER"; then
    bad "$(job_label "$name")" "worker exited $rc after its rows"
  fi
  # EXIT is the publication point even for row_timeout's exit124. Preserve every partial
  # row (including its own duration) and publish the actual counts after bounded cleanup.
  PASS=$(awk -F '\t' '$1=="ok"{n++} END{print n+0}' "$LEDGER")
  FAIL=$(awk -F '\t' '$1=="FAIL"{n++} END{print n+0}' "$LEDGER")
  ended=$(date +%s.%N)
  printf '%s\t%s\t%s\t%s\n' "$name" "$slot" "$started" "$ended" > "$TMPDIR/family.tsv"
  printf '%s\t%s\t%s\n' "$rc" "$PASS" "$FAIL" > "$TMPDIR/done.tmp"
  mv "$TMPDIR/done.tmp" "$TMPDIR/done"
  exit "$rc"
}
run_job(){ (
  local name=$1 slot=$2 started=$EPOCHREALTIME ended rc CLEANUP_OWNER=$BASHPID
  WORKER_PIDS=(); SRV=0; GLOBCASE_ORACLE=0; MMPID=0; PAUSABLE_PID=0
  PASS=0; FAIL=0; ROW_ID=; ROW_WATCHDOG=0; ROW_EXPIRED=0
  export TMPDIR="$RUN_DIR/jobs/$name"
  mkdir -p "$TMPDIR"
  LEDGER="$TMPDIR/ledger"; TIMINGS="$TMPDIR/timings"
  : > "$LEDGER"; : > "$TIMINGS"
  trap 'job_finalize "$?" >>"$TMPDIR/output.log" 2>&1' EXIT
  trap 'exit 130' INT TERM
  set_slot "$slot"
  BUILD_CORES="$CORES,$LOAD_CORES"
  BUILD_JOBS=$(taskset -c "$BUILD_CORES" nproc)
  export PARBUILD_JOBS="$BUILD_JOBS"
  quiet_wait
  started=$(date +%s.%N); ROW_T=$started
  job_body "$name" >"$TMPDIR/output.log" 2>&1
  rc=$?
  exit "$rc"
); }
plan_jobs(){
  # Serialization is limited to binary publication, shared release-object writes, one job per
  # CPU/three-port slot, and the operations inside a shared boot/recovery chain. All files written
  # by independent batteries are private TMPDIR/mktemp paths; the coordinator alone owns ledgers.
  # TLS uses PORT+1, nested servertail uses PORT+2, and oracle boots use these same reserved ports.
  # NIC's global namespace/interface changes and every regression measurement follow the final
  # join barrier. atomic_batteries also waits for every other family: its RYOW row contains
  # a performance assertion, so it is an explicit exception to parallel correctness work.
  # Correctness traffic is modest and stays on each slot's two or more physical load cores.
  # Compilers use that slot's server+load cores. The release build alone unlocks release jobs;
  # ASAN and standalone units do not delay boots, and full-only builds start immediately too.
  JOB_NAMES=(release asan core_tsan_build waits_tsan_build racefix_tsan_build tailgen_build)
  [ "$TIER" != full ] || JOB_NAMES+=(rldbg)
  JOB_NAMES+=(config_unit flip_unit filter_unit ring_unit storage_units
              production_units acl_metadata cmd_metadata abba_selftest)
  # Start long waits and whole boot families early; short jobs occupy the slots they release.
  if [ "$TIER" = full ]; then
    # Each target already rebooted between atomic modes. Those four independent lifetimes can
    # occupy separate CPU/port/TMPDIR slots; seeds and the accumulated-state MULTI repeats cannot.
    # Plan failure remains loud and makes every required differential fold red, while unrelated
    # correctness jobs still run and retain their evidence.
    JOB_NAMES+=(differ-split-0 differ-split-1 differ-armed-0 differ-armed-1 differ-equivalence)
  fi
  local atomic mode section slot FM FR FO FQ FF
  for section in lruclock lfu; do
    for atomic in 0 1; do for mode in split armed; do JOB_NAMES+=("evict-$section-$mode-$atomic"); done; done
  done
  JOB_NAMES+=(flipctl)
  for atomic in 0 1; do JOB_NAMES+=("feature-split-$atomic" "feature-armed-$atomic"); done
  for mode in 1s 2s; do
    for FR in 0 1; do for atomic in 0 1; do JOB_NAMES+=("multidb-$mode-$FR-$atomic"); done; done
  done
  JOB_NAMES+=(aof-epoll aof-uring snapshot-epoll snapshot-uring debug-0 debug-1
              wb_policy netio-1s netio-2s lb-stationary-1s lb-stationary-2s
              reorder_sync reorder_engagement reorder_identity
              core_units flipfix_units climonfix clientfix racefix_counters racefix_climon persistfix_units perfex_units perfex_live lbplanner_units exbatch_units exbatch_live wb_rule_units wbland_units splitlocal_units atomic_units netcmd_units netcap respcompat boot_grammar wait_units readonly
              release_batteries atomic_batteries bplus acl_recheck aclfix sort script_bounds scriptfix
              efficiency dump_restore auth authfix notify flip flip_saturated atomic_floor
              aof_frame tls fused-0 fused-1)
  [ "$TIER" != full ] || JOB_NAMES+=(asan_batteries replyoff zc rlcache globcase)
  for FM in 1s 2s; do
    for FR in 0 1; do for FC in 0 1; do for FQ in 0 1; do for FF in 0 1; do
      JOB_NAMES+=("feature-cell-$FM-$FR-$FC-$FQ-$FF")
    done; done; done; done
  done
  JOB_NAMES+=(feature-cell-split-home-min feature-cell-fused-home-max-nopin feature-cell-split-shards-auto)
}
start_workers(){
  phase parallel-begin
  plan_jobs
  select_jobs || exit $?
  if [[ " ${JOB_NAMES[*]} " == *' differ-'* ]]; then
    python3 tests/differ_fanout.py plan --run "${ROW_RUN_ID:-$RUN_DIR}" --output "$RUN_DIR/differ-plan.json" \
        --repeats "${GATE_DIFFER_MULTI_REPEATS:-4}" || true
  fi
  local slot name selected pending queue_fd
  mkdir -p "$RUN_DIR/claimed"
  for ((slot=0; slot<GATE_SLOTS; slot++)); do
    (
      WORKER_PIDS=(); SRV=0; GLOBCASE_ORACLE=0; MMPID=0; PAUSABLE_PID=0
      trap 'exit 130' INT TERM
      while :; do
        exec {queue_fd}>"$RUN_DIR/queue.lock"
        flock "$queue_fd"
        selected=; pending=0
        for name in "${JOB_NAMES[@]}"; do
          [ ! -d "$RUN_DIR/claimed/$name" ] || continue
          pending=1
          if job_ready "$name"; then
            selected=$name
            mkdir "$RUN_DIR/claimed/$name"
            break
          fi
        done
        flock -u "$queue_fd"; exec {queue_fd}>&-
        if [ -n "$selected" ]; then
          run_job "$selected" "$slot"
          job_recover "$selected" "$slot" "$?"
        elif [ "$pending" = 0 ]; then break
        else sleep 0.2
        fi
      done
    ) &
    WORKER_PIDS+=("$!")
  done
}
collect_differ_group(){
  local group=$1 name dir p live row verdict duration label fold_rc=0
  local parts=("differ-$group-0" "differ-$group-1")
  [ "$group" != split ] || parts+=(differ-equivalence)
  label=$(job_label "differ-$group")
  for name in "${parts[@]}"; do
    dir="$RUN_DIR/jobs/$name"
    while [ ! -f "$dir/done" ]; do
      live=0
      for p in "${WORKER_PIDS[@]}"; do kill -0 "$p" 2>/dev/null && live=1; done
      [ "$live" = 1 ] || break
      sleep 0.2
    done
    [ ! -f "$dir/output.log" ] || cat "$dir/output.log"
  done
  # Fold only after every named child's normal finalizer has published its real exit and cleanup
  # result. The helper revalidates ordered leg inventories and coverage, including failed-seed
  # replays; a missing/unreached child is one failed original row, never a smaller passing matrix.
  row=$(python3 tests/differ_fanout.py fold --plan "$RUN_DIR/differ-plan.json" --group "$group" \
      --run-directory "$RUN_DIR" --row-plan "$ROW_PLAN" --row-history "$ROW_HISTORY" --row-run "$ROW_RUN_ID") || fold_rc=$?
  # A completed failed matrix still has real elapsed time and public-label history. Accept
  # that nonzero helper result only as one exact FAIL row for this group; malformed/empty
  # output or an error accompanied by an ok fragment remains an infrastructure failure.
  if ! [[ "$row" =~ ^(ok|FAIL)$'\t'[0-9]+([.][0-9]+)?$'\t'"$label"$ ]] ||
      { [ "$fold_rc" -ne 0 ] && [[ "$row" != FAIL$'\t'* ]]; }; then
    bad "$label" "incomplete differential children or malformed fold; see $RUN_DIR/jobs/differ-*"
    return
  fi
  IFS=$'\t' read -r verdict duration label <<< "$row"
  printf '%s\n' "$row" >> "$LEDGER"
  printf '%s\n' "$row" >> "$TIMINGS"
  if [ "$fold_rc" = 124 ]; then
    say "$label" "TIMEOUT (${duration}s across concurrent children)"
  else
    say "$label" "$verdict (${duration}s across concurrent children)"
  fi
  if [ "$verdict" = ok ]; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); fi
}
collect_job(){
  case "$1" in differ-split|differ-armed) collect_differ_group "${1#differ-}"; return;; esac
  local name=$1 dir="$RUN_DIR/jobs/$1" live p job_rc job_pass job_fail ledger_counts ledger_pass ledger_fail
  local completion=()
  while [ ! -f "$dir/done" ]; do
    live=0
    for p in "${WORKER_PIDS[@]}"; do kill -0 "$p" 2>/dev/null && live=1; done
    [ "$live" = 1 ] || break
    sleep 0.2
  done
  if [ ! -s "$dir/ledger" ] || [ ! -f "$dir/done" ]; then
    bad "$(job_label "$name")" "worker did not complete; see $dir"
    return
  fi
  mapfile -t completion < "$dir/done"
  read -r job_rc job_pass job_fail <<< "${completion[0]:-}"
  if [ "${#completion[@]}" != 1 ] ||
      ! [[ "$job_rc" =~ ^(0|[1-9][0-9]{0,2})$ && "$job_pass" =~ ^[0-9]+$ && "$job_fail" =~ ^[0-9]+$ ]] ||
      [ "$job_rc" -gt 255 ]; then
    bad "$(job_label "$name")" "malformed worker completion; see $dir"
    return
  fi
  if ! ledger_counts=$(awk -F '\t' '
      NF != 3 || $1 !~ /^(ok|FAIL)$/ || $2 !~ /^[0-9]+([.][0-9]+)?$/ || $3 == "" {exit 1}
      $1 == "ok" {passed++}
      $1 == "FAIL" {failed++}
      END {printf "%d %d\n", passed, failed}' "$dir/ledger"); then
    bad "$(job_label "$name")" "malformed worker ledger; see $dir"
    return
  fi
  read -r ledger_pass ledger_fail <<< "$ledger_counts"
  # The completion record is independent failure evidence. Ignoring its counts lets an
  # explicit failed completion turn green when its fragment contains only passing rows.
  # Require an exact inventory agreement before publishing either artifact to the gate.
  if [ "$job_pass" != "$ledger_pass" ] || [ "$job_fail" != "$ledger_fail" ]; then
    bad "$(job_label "$name")" "worker completion disagrees with ledger ($job_pass/$job_fail versus $ledger_pass/$ledger_fail); see $dir"
    return
  fi
  # A child can print success and then fail (including during teardown). Its process result is
  # evidence too: never let a previously emitted green fragment swallow that failure.
  if [ "$job_rc" -ne 0 ] && [ "$ledger_fail" = 0 ]; then
    cat "$dir/output.log"
    bad "$(job_label "$name")" "worker exited $job_rc after its rows; see $dir"
    return
  fi
  cat "$dir/output.log"
  cat "$dir/ledger" >> "$LEDGER"; cat "$dir/timings" >> "$TIMINGS"
  PASS=$((PASS + ledger_pass))
  FAIL=$((FAIL + ledger_fail))
  ROW_T=$(date +%s.%N)
}
join_workers(){
  local p
  for p in "${WORKER_PIDS[@]}"; do wait "$p" || bad 'correctness worker completion'; done
  WORKER_PIDS=()
  BUILD_CORES=$ALL_BUILD_CORES
  cat "$RUN_DIR"/jobs/*/family.tsv > "$RUN_DIR/families.tsv"
}
stop_workers(){ reap_children; }


# The bodies below preserve every same-server sequence and persistence recovery chain. Only
# dispatch moved: collection at the original tier/source positions remains the ledger contract.
ASAN="$PWD/build/gate-cache/tomokv-asan"
RLDBG="$PWD/build/gate-cache/tomokv-rlcachedbg"
CORE_TSAN="$PWD/build/gate-cache/core-concurrency-tsan"
WAITS_TSAN="$PWD/build/gate-cache/waits-unit-tsan"
FEATURE_OUTPUT=${GATE_FEATURE_OUTPUT:-$(mktemp -d "$PWD/build/gate-feature.XXXXXX")}

reject_boot(){
  local conf=() directory
  # A broken rejection may accidentally start a server. Its affinity, bind, data directory and
  # lifetime must still obey this slot. Config-file paths remain first, as the parser requires.
  if [[ "$1" != --* ]]; then conf=("$1"); shift; fi
  directory=$(mktemp -d "$TMPDIR/reject-boot.XXXXXX") || return 1
  timeout --kill-after=5 10 taskset -c "$CORES" "$CANDIDATE_BINARY" "${conf[@]}" \
      --port "$PORT" --bind 127.0.0.1 --shards 16 --ratio "$GATE_RATIO" --dir "$directory" --save '' "$@"
}

store_build(){
  local variant=${1:-} flags=${CXXFLAGS-'-std=c++20 -O2 -g -Wall -Wextra -march=native -pthread'}
  # Match the two Makefile recipes, including the later -O1 override for TSan. Their former
  # single compiler invocation serialized the large translation units on every cache miss.
  # Reuse the header-aware cache and keep compilation on this slot while other batteries run.
  if [ "$variant" = tsan ]; then
    flags+=' -O1 -fsanitize=thread -fno-omit-frame-pointer -no-pie'
  fi
  flags+=' -ffunction-sections -fdata-sections -DTOMO_STORE_REGRESSION_TEST'
  flags+=' -I.'
  pausable taskset -c "$CORES,$LOAD_CORES" tests/parbuild.sh \
      "$PWD/build/store-regression${variant:+-$variant}" \
      "$PWD/build/gate-cache/store${variant:+-$variant}-objects" \
      "$flags" '-Wl,--gc-sections' \
      tests/store_regression.cc src/cmd/t_hash.cc src/cmd/t_hash_ttl.cc src/cmd/storesize.cc
}

job_release(){
if [ "$BUILD_CANDIDATE" = 1 ]; then
  row_begin "release build (+footprint locks)"
  pausable taskset -c "$BUILD_CORES" make -j"$BUILD_JOBS" >$TMPDIR/gate-build.txt 2>&1 \
    && ok "release build (+footprint locks)" || bad "release build" "see $TMPDIR/gate-build.txt"
else
  row_begin "release build (+footprint locks)" external-candidate
  [ -x "$CANDIDATE_BINARY" ] && ok "release build (+footprint locks)" \
      || bad "release build" "candidate is not executable: $CANDIDATE_BINARY"
fi
if [ "$FAIL" = 0 ] && [ -n "$RECEIPT_START" ]; then
  # Publish the binary binding before this worker's done marker unlocks release batteries.
  # A binding problem withholds certification; it does not delete or bypass any gate row.
  # An external executable has no demonstrated relationship to this source tree. Its full
  # diagnostic run remains useful, but only our normal source build can obtain a push receipt.
  if [ "$BUILD_CANDIDATE" = 1 ]; then
    python3 tests/gate_receipt.py bind --start "$RECEIPT_START" --candidate "$CANDIDATE_BINARY" \
        >"$RUN_DIR/receipt-bind.log" 2>&1 || cat "$RUN_DIR/receipt-bind.log" >&2
  else
    echo 'GATE RECEIPT WITHHELD: --candidate-binary skips the source build; all diagnostic rows still run, but external bytes cannot certify this source tree' \
        >"$RUN_DIR/receipt-bind.log"
    cat "$RUN_DIR/receipt-bind.log" >&2
  fi
fi
}

job_asan(){
# 42 translation units: compiled in parallel with a header-aware object cache rather than in one
# serial g++, which cost 365s and was the largest row in the gate.
row_begin "ASAN build"
pausable taskset -c "$BUILD_CORES" tests/parbuild.sh $ASAN "$PWD/build/gate-cache/obj-asan" \
    "-std=c++20 -O1 -g -fsanitize=address -march=native -pthread -I." \
    "-luring -pthread -lssl -lcrypto" \
    src/main.cc src/net/tls.cc src/core/*.cc src/cmd/*.cc src/snapshot/*.cc src/persist/*.cc 2>$TMPDIR/gate-asan-build.txt \
    && ok "ASAN build" || bad "ASAN build" "see $TMPDIR/gate-asan-build.txt"
}

job_config_unit(){
quiet_wait
row_begin "configuration docs match parser"
taskset -c "$CORES" python3 tests/docs_drift.py --self-test >"$TMPDIR/docs-drift.log" 2>&1 \
    && ok "configuration docs match parser" \
    || bad "configuration docs match parser" "see $TMPDIR/docs-drift.log"
# docsregen: +1 quick and +1 full; config_unit is collected before the quick exit.
# EXPECT_QUICK/EXPECT_FULL remain maintainer-owned.
row_begin "Redis config quoting + mid-value #"
g++ -std=c++20 -O2 -I. tests/config_parser_test.cc -o $TMPDIR/tomokv-config-parser-test \
    && taskset -c "$CORES" $TMPDIR/tomokv-config-parser-test \
    && ok "Redis config quoting + mid-value #" || bad "Redis config quoting + mid-value #"
}

job_flip_unit(){
# The flip-controller MODEL (fingerprint classes, ramp gate, count-noise rejection) has a unit
# test that nothing built; a model regression surfaced only in flipctl.py's live 2-5 min row.
row_begin "flip controller model unit"
g++ -std=c++20 -O2 -I. tests/flipctl_unit.cc src/core/flipctl.cc -o $TMPDIR/tomokv-flipctl-unit \
    2>$TMPDIR/gate-flipctl-unit.txt \
    && $TMPDIR/tomokv-flipctl-unit >>$TMPDIR/gate-flipctl-unit.txt 2>&1 \
    && ok "flip controller model unit" \
    || bad "flip controller model unit" "see $TMPDIR/gate-flipctl-unit.txt"
}

job_flipfix_units(){
# flipfix IO4.4/CT4.3: two serverless rows, collected BEFORE the quick-tier exit (+2/+2). Each runs
# the core fixture's selection under ASAN/UBSAN (production_units) and under TSAN (core_tsan_build):
# a planned connection closing during FLIP must stay owned and allocated until its source drops it,
# and the monitor must read fingerprint windows through the release/acquire publication.
flipfix_unit(){
  quiet_wait
  unit_ready core-concurrency-unit && \
      ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 \
      taskset -c "$CORES" ./build/core-concurrency-unit "$1" \
          >"$TMPDIR/gate-$1.txt" 2>&1 && \
      tsan_unit "$CORE_TSAN" core-concurrency-tsan \
          "PASS core concurrency $1 (state assertions fired)" "$1"
}
row_begin "FLIP planned-connection close lifetime (ASAN+TSAN)"
flipfix_unit flipfix-plan \
    && ok "FLIP planned-connection close lifetime (ASAN+TSAN)" \
    || bad "FLIP planned-connection close lifetime (ASAN+TSAN)" "see $TMPDIR/gate-flipfix-plan.txt and $TMPDIR/tsan-core-concurrency-tsan-flipfix-plan.log"
row_begin "FLIP fingerprint publication (ASAN+TSAN)"
flipfix_unit flipfix-fingerprint \
    && ok "FLIP fingerprint publication (ASAN+TSAN)" \
    || bad "FLIP fingerprint publication (ASAN+TSAN)" "see $TMPDIR/gate-flipfix-fingerprint.txt and $TMPDIR/tsan-core-concurrency-tsan-flipfix-fingerprint.log"
}

job_filter_unit(){
row_begin "B+ counting-fingerprint filter unit"
g++ -std=c++20 -O2 -pthread -I. tests/foreign_read_safety_test.cc \
    -o $TMPDIR/tomokv-foreign-read-safety-test \
    && $TMPDIR/tomokv-foreign-read-safety-test \
    && ok "B+ counting-fingerprint filter unit" \
    || bad "B+ counting-fingerprint filter unit"
}

job_ring_unit(){
# THE RYOW WRITE RING, INCLUDING ITS ARMING TRANSIENT (DESIGN-RINGDIET.md). The connection records
# nothing until a local read arms it, so the reads that arrive with pre-arming writes still in
# flight must be DEMOTED -- and the fence that demotes them must be one-shot, or a 1:1 connection
# would never be served locally again. That is a per-frame ordering property of the ROB, so it is
# tested server-less and deterministically here rather than inferred from a live counter: the five
# directed arming cases plus a 200k-frame soak that starts UNARMED and crosses the transition, on
# top of the fourteen ring cases the sizing lane left (which this row also brings into the gate for
# the first time -- they were `make unit` only). 20 cases, one row.
row_begin "read-local write ring + arming transient unit"
g++ -std=c++20 -O2 -march=native -pthread -I. tests/read_local_write_ring_unit.cc \
    -o $TMPDIR/tomokv-read-local-write-ring-unit 2>$TMPDIR/gate-ring-unit.txt \
    && $TMPDIR/tomokv-read-local-write-ring-unit >>$TMPDIR/gate-ring-unit.txt 2>&1 \
    && ok "read-local write ring + arming transient unit" \
    || bad "read-local write ring + arming transient unit" "see $TMPDIR/gate-ring-unit.txt"
# SV1: logical owners i/i+64 need no 65-CPU allocation in a parallel gate slot.
row_begin "climon 128-owner delivery mask"
pausable taskset -c "$CORES" make -j"$BUILD_JOBS" build/climon-mask-unit build/climon-mask-old-unit \
    >"$TMPDIR/climon-mask.log" 2>&1 \
    && taskset -c "$CORES" ./build/climon-mask-unit >>"$TMPDIR/climon-mask.log" 2>&1 \
    && { taskset -c "$CORES" ./build/climon-mask-old-unit >"$TMPDIR/climon-mask-old.log" 2>&1; test "$?" -eq 1; } \
    && grep -q '^FAIL climon mask: disarm retains the other owner at distance 64$' "$TMPDIR/climon-mask-old.log" \
    && ok "climon 128-owner delivery mask" \
    || bad "climon 128-owner delivery mask" "see $TMPDIR/climon-mask.log"

# RL1: all three completion paths must release a covered MGET fence before retirement.
# One new row, collected before the quick exit; EXPECT counts remain maintainer-owned.
row_begin "read-local MGET fence symmetry unit"
pausable taskset -c "$BUILD_CORES" make -j"$BUILD_JOBS" build/rlfence-unit \
    >$TMPDIR/gate-rlfence-unit.txt 2>&1 \
    && taskset -c "$CORES" ./build/rlfence-unit >>$TMPDIR/gate-rlfence-unit.txt 2>&1 \
    && py tests/read_local_lane.py --self-test mget-fence >>$TMPDIR/gate-rlfence-unit.txt 2>&1 \
    && ok "read-local MGET fence symmetry unit" \
    || bad "read-local MGET fence symmetry unit" "see $TMPDIR/gate-rlfence-unit.txt"

}

job_climonfix(){
  row_begin "shutdown policy + signal handoff serverless"
  unit_ready shutdown-unit && taskset -c "$CORES" ./build/shutdown-unit \
      >"$TMPDIR/shutdown-unit.log" 2>&1 \
      && ok "shutdown policy + signal handoff serverless" \
      || bad "shutdown policy + signal handoff serverless" "see $TMPDIR/shutdown-unit.log"
  local mode stop_case label
  for mode in 1s 2s; do
    for stop_case in command sigterm sigint; do
      label="shutdown persistence ($mode, $stop_case)"
      row_begin "$label"
      py tests/shutdown_persist.py --binary "$CANDIDATE_BINARY" --cores "$CORES" \
          --port "$PORT" --ratio "$GATE_RATIO" --mode "$mode" --case "$stop_case" \
          --output "$TMPDIR/shutdown-$mode-$stop_case" >"$TMPDIR/shutdown-$mode-$stop_case.log" 2>&1 \
          && ok "$label" || bad "$label" "see $TMPDIR/shutdown-$mode-$stop_case.log"
    done
  done
}

job_lbplanner_units(){
# Connreset: the observer must join before server teardown on rejected baselines.
# One new serverless row BEFORE the quick exit (+1 quick/full); counts are owner-owned.
row_begin "LB sampler exceptional cleanup + negative control"
if py tests/connreset_harness_test.py >"$TMPDIR/connreset-harness.log" 2>&1 \
    && { py tests/connreset_harness_test.py --negative-control >"$TMPDIR/connreset-negative.log" 2>&1; test "$?" -eq 1; } \
    && grep -q 'FAIL: test_baseline_failure_joins_monitor_before_server_and_preserves_cause' "$TMPDIR/connreset-negative.log"; then
  ok "LB sampler exceptional cleanup + negative control"
else
  bad "LB sampler exceptional cleanup + negative control" "see $TMPDIR/connreset-harness.log and $TMPDIR/connreset-negative.log"
fi
# CT1: one hand-off witness row, collected BEFORE the quick exit (+1 quick/full).
row_begin "LB monitor plan handoff + negative controls"
if unit_ready lbplanner-units && taskset -c "$CORES" python3 tests/lbplanner_checks.py \
    >"$TMPDIR/lbplanner-unit.log" 2>&1; then
  ok "LB monitor plan handoff + negative controls"
else
  bad "LB monitor plan handoff + negative controls" "see $TMPDIR/lbplanner-unit.log"
fi
}

job_perfex_units(){
  local check label
  for check in clock batch; do
    label="perfex $check binary regression"
    row_begin "$label"
    if taskset -c "$CORES" python3 tests/perfex_checks.py "$check" --binary "$CANDIDATE_BINARY" \
        >"$TMPDIR/perfex-$check.log" 2>&1; then
      ok "$label"
    else
      bad "$label" "see $TMPDIR/perfex-$check.log"
    fi
  done
}

job_perfex_live(){
  local mode label launch_fn
  for mode in 1s 2s; do
    label="perfex TTL sampler beat ($mode)"
    row_begin "$label"
    launch_fn=boot; [ "$mode" != 1s ] || launch_fn=boot_fused
    # A failed boot is this row's failure; never run the client against an old listener.
    if py tests/perfex_checks.py prepare --clock-file "$TMPDIR/perfex-clock" &&
        LD_PRELOAD="$TMPDIR/perfex-clock.so" TOMO_PERFEX_CLOCK="$TMPDIR/perfex-clock" "$launch_fn" "$CANDIDATE_BINARY" --atomic 1 --read-local 0 --databases 1 \
        --key-lb 0 --client-lb 0 --flip-auto 0 --enable-debug-command yes \
        --save '' --appendonly no && \
        py tests/perfex_checks.py sampler --port "$PORT" --clock-file "$TMPDIR/perfex-clock" \
          >"$TMPDIR/perfex-sampler-$mode.log" 2>&1; then
      ok "$label"
    else
      bad "$label" "see $TMPDIR/perfex-sampler-$mode.log and $SRVLOG"
    fi
    stop
  done
}

job_persistfix_units(){
# PS1/PS2/PS14: one row, collected BEFORE the quick-tier exit. EXPECT stays owner-owned.
row_begin "AOF publication/shutdown witnesses + negative controls"
if unit_ready persistfix-units && taskset -c "$CORES" python3 tests/persistfix_checks.py \
    >"$TMPDIR/persistfix-unit.log" 2>&1; then
  ok "AOF publication/shutdown witnesses + negative controls"
else
  bad "AOF publication/shutdown witnesses + negative controls" "see $TMPDIR/persistfix-unit.log"
fi
}

job_exbatch_units(){
  local group label
  for group in publication watch metadata; do
    label="exbatch $group unit + negative controls"
    row_begin "$label"
    if unit_ready exbatch-unit && unit_ready exbatch-db0-unit && \
        taskset -c "$CORES" python3 tests/exbatch_checks.py "$group" \
          >"$TMPDIR/exbatch-$group.log" 2>&1; then
      ok "$label"
    else
      bad "$label" "see $TMPDIR/exbatch-$group.log"
    fi
  done
}

job_exbatch_live(){
  local mode label launch_fn
  for mode in 1s 2s; do
    label="exbatch publication and WATCH lifecycle ($mode)"
    row_begin "$label"
    launch_fn=boot; [ "$mode" != 1s ] || launch_fn=boot_fused
    if "$launch_fn" "$CANDIDATE_BINARY" --atomic 1 --read-local 1 --databases 4 \
        --key-lb 0 --client-lb 0 --flip-auto 0 --enable-debug-command yes \
        --save '' --appendonly no && \
        py tests/exbatch.py 127.0.0.1 "$PORT" >"$TMPDIR/exbatch-$mode.log" 2>&1; then
      ok "$label"
    else
      bad "$label" "see $TMPDIR/exbatch-$mode.log and $SRVLOG"
    fi
    stop
  done
}

job_clientfix(){
  local mode case label
  # Each regression owns its boot on this job's assigned port; no preboot to collide with.
  for mode in 1s 2s; do
    for case in tracking-cap tracking-pipeline reply-skip pattern-cleanup pause-deadline geo-count geo-store; do
      label="clientfix $case ($mode)"
      row_begin "$label"
      if py tests/clientfix.py --binary "$CANDIDATE_BINARY" --port "$PORT" \
          --cores "$CORES" --ratio "$GATE_RATIO" --mode "$mode" --case "$case" \
          >"$TMPDIR/clientfix-$case-$mode.log" 2>&1; then
        ok "$label"
      else
        bad "$label" "see $TMPDIR/clientfix-$case-$mode.log"
      fi
    done
  done
}

job_core_units(){
# SURVIVING core concurrency regressions. Seven rows, all ABOVE the quick-tier exit.
# Each selection asserts its hazardous state; ASAN/UBSAN and bounded interleaving hooks
# make a broken mechanism fail. The fixture starts no server and opens no listener.
CORE_UNIT_READY=0
unit_ready core-concurrency-unit && CORE_UNIT_READY=1
for core_row in watch lifetime drain route snapshot config notify; do
  row_begin "core concurrency $core_row"
  quiet_wait
  if [ "$CORE_UNIT_READY" = 1 ] && \
      ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 \
      taskset -c "$CORES" ./build/core-concurrency-unit "$core_row" \
          >"$TMPDIR/gate-core-$core_row.txt" 2>&1 && \
      tsan_unit "$CORE_TSAN" core-concurrency-tsan \
          "PASS core concurrency $core_row (state assertions fired)" "$core_row"; then
    ok "core concurrency $core_row"
  else
    bad "core concurrency $core_row" "see $TMPDIR/gate-core-$core_row.txt, $TMPDIR/tsan-core-concurrency-tsan-$core_row.log, and $RUN_DIR/jobs/production_units/build.log and $RUN_DIR/jobs/core_tsan_build/build.log"
  fi
done
# Two topology witnesses, collected with core_units BEFORE the quick-tier exit.
# Each mode runs its own forced-window, retry-restored and missing-window controls.
for mode in 1s 2s; do
  row_begin "read-local topology demotion ($mode)"
  if unit_ready rltopo-unit && \
      ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 \
      taskset -c "$CORES" ./build/rltopo-unit "$mode" \
          >"$TMPDIR/gate-rltopo-$mode.txt" 2>&1 && \
      grep -Fxq "PASS rltopo $mode (demotions, zero retries, negative controls, arm transients)" \
          "$TMPDIR/gate-rltopo-$mode.txt"; then
    ok "read-local topology demotion ($mode)"
  else
    bad "read-local topology demotion ($mode)" "see $TMPDIR/gate-rltopo-$mode.txt and $RUN_DIR/jobs/production_units/build.log"
  fi
done
}

job_wb_rule_units(){
  local group label
  for group in policy phase stages split-phase; do
    label="writeback c12 $group witnesses + negative controls"
    row_begin "$label"
    if unit_ready wb-rule-units && taskset -c "$CORES" python3 tests/wb_rule_checks.py check "$group" \
        >"$TMPDIR/wb-rule-$group.log" 2>&1; then
      ok "$label"
    else
      bad "$label" "see $TMPDIR/wb-rule-$group.log and $RUN_DIR/jobs/production_units/build.log"
    fi
  done
}

job_wbland_units(){
  local group label
  for group in clauses paths; do
    label="writeback policy $group witnesses + negative controls"
    row_begin "$label"
    if unit_ready wbland-units && taskset -c "$CORES" python3 tests/wbland_checks.py check "$group" \
        >"$TMPDIR/wbland-$group.log" 2>&1; then
      ok "$label"
    else
      bad "$label" "see $TMPDIR/wbland-$group.log and $RUN_DIR/jobs/production_units/build.log"
    fi
  done
}

job_reorder_sync(){
  local label='R7 generated envelope parity'
  row_begin "$label"
  py tests/r7shadow_sync.py >"$TMPDIR/sync.log" 2>&1 \
      && py tests/r7shadow_sync_test.py >>"$TMPDIR/sync.log" 2>&1 \
      && ok "$label" || bad "$label" "see $TMPDIR/sync.log"
}
job_reorder_engagement(){
  local label='R7 production engagement (both database runtimes)'
  row_begin "$label"
  if unit_ready reorder-engagement-unit && unit_ready reorder-engagement-unit-db0 &&
      taskset -c "$CORES" python3 tests/reorder_receipt.py build/reorder-engagement-unit "$TMPDIR/multi" \
          --engagement >"$TMPDIR/engagement.log" 2>&1 &&
      taskset -c "$CORES" python3 tests/reorder_receipt.py build/reorder-engagement-unit-db0 "$TMPDIR/db0" \
          --engagement >>"$TMPDIR/engagement.log" 2>&1; then
    ok "$label"
  else bad "$label" "see $TMPDIR/engagement.log and production_units/build.log"; fi
}
job_reorder_identity(){
  local label='R7 FIFO twin off-path identity + negative controls'
  row_begin "$label"
  py tests/reorder_receipt.py "$CANDIDATE_BINARY" "$TMPDIR/receipt" >"$TMPDIR/receipt.log" 2>&1 \
      && ok "$label" || bad "$label" "see $TMPDIR/receipt.log"
}
job_wb_policy(){
  local label='writeback policies 0/1: 22 standard fixtures'
  local mode policy boot_fn rc=0
  # One scored row owns four boots and compares independent policy lifetimes.
  row_begin "$label"
  unit_ready wbland-units && py tests/wb_policy.py --traces >"$TMPDIR/traces.log" 2>&1 || rc=1
  for mode in 1s 2s; do
    boot_fn=boot; [ "$mode" != 1s ] || boot_fn=boot_fused
    for policy in 1 0; do
      local compare=()
      [ "$policy" != 0 ] || compare=(--compare "$TMPDIR/$mode-1.json")
      if "$boot_fn" "$CANDIDATE_BINARY" --wb-policy "$policy" --enable-debug-command yes &&
          py tests/wb_policy.py --port "$PORT" --policy "$policy" --output "$TMPDIR/$mode-$policy.json" \
              "${compare[@]}" >"$TMPDIR/$mode-$policy.log" 2>&1; then :; else rc=1; fi
      stop
    done
  done
  [ "$rc" = 0 ] && ok "$label" || bad "$label" "see $TMPDIR/*.log"
}
job_netio(){
  local mode=$1 boot_fn=boot engine rc=0 label="epoll directed correctness ($1)"
  [ "$mode" != 1s ] || boot_fn=boot_fused
  row_begin "$label"
  for engine in uring epoll; do
    if "$boot_fn" "$CANDIDATE_BINARY" --net-io "$engine" &&
        py tests/netio.py 127.0.0.1 "$PORT" "$engine" >"$TMPDIR/$engine.log" 2>&1; then :; else rc=1; fi
    stop
  done
  [ "$rc" = 0 ] && ok "$label" || bad "$label" "see $TMPDIR/{uring,epoll}.log"
}
job_lb_stationary(){
  local mode=$1 boot_fn=boot label="stationary balanced LB holds still ($1)"
  [ "$mode" != 1s ] || boot_fn=boot_fused
  row_begin "$label"
  if "$boot_fn" "$CANDIDATE_BINARY" --key-lb 1 --client-lb 1 --flip-auto 0 --enable-debug-command yes &&
      py tests/lb_stationary.py --port "$PORT" --output "$TMPDIR/hold.json" >"$TMPDIR/hold.log" 2>&1; then
    ok "$label"
  else bad "$label" "see $TMPDIR/hold.log and $SRVLOG"; fi
  stop
}

job_splitlocal_units(){
  local label="splitlocal template forwarding + old-argument controls"
  row_begin "$label"
  if unit_ready splitlocal-unit && taskset -c "$CORES" python3 tests/splitlocal_checks.py check \
      --output "$TMPDIR/splitlocal-controls" >"$TMPDIR/splitlocal.log" 2>&1; then
    ok "$label"
  else
    bad "$label" "see $TMPDIR/splitlocal.log and $RUN_DIR/jobs/production_units/build.log"
  fi
}

job_storage_units(){
# Twelve storage regressions, all BEFORE the quick-tier exit. The hash reaper is production code;
# store-boundary spies make held epochs, capture cursors, eviction and allocation failures exact.
# No case skips. Build failure makes every dependent row red. EXPECT constants are maintainer-owned.
STORE_REGRESSION_BUILT=0; STORE_TSAN_BUILT=0
store_build >$TMPDIR/gate-store-build.txt 2>&1 & store_pid=$!
store_build tsan >$TMPDIR/gate-store-flags-build.txt 2>&1 & store_tsan_pid=$!
wait "$store_pid" && STORE_REGRESSION_BUILT=1
wait "$store_tsan_pid" && STORE_TSAN_BUILT=1
for STORE_CASE in unlinked randomkey rehash rollback snapshot-eviction flags aof-eviction intents imported-hash field-index-failure hash-bytes deadline-allocation-failure; do
  row_begin "storage $STORE_CASE regression"
  STORE_RUN=(./build/store-regression "$STORE_CASE")
  STORE_CASE_BUILT=$STORE_REGRESSION_BUILT
  if [ "$STORE_CASE" = flags ]; then
    # Only this process disables address randomization: GCC TSan otherwise collides with the
    # host's mappings before main. A runtime race report or unavailable TSan is a red row.
    STORE_CASE_BUILT=0
    [ "$STORE_TSAN_BUILT" = 1 ] && STORE_CASE_BUILT=1
    STORE_RUN=(setarch x86_64 -R ./build/store-regression-tsan flags)
  fi
  quiet_wait
  if [ "$STORE_CASE_BUILT" = 1 ] && \
      "${STORE_RUN[@]}" \
          >$TMPDIR/gate-store-$STORE_CASE.txt 2>&1; then
    ok "storage $STORE_CASE regression"
  else
    bad "storage $STORE_CASE regression" "see $TMPDIR/gate-store-build.txt, $TMPDIR/gate-store-$STORE_CASE-build.txt and $TMPDIR/gate-store-$STORE_CASE.txt"
  fi
done
}

job_atomic_units(){
# ST1/ST10: two rows collected here, before the quick-tier exit (+2 quick/full).
for FLUSHFIX_CASE in flush headers; do
  row_begin "flushfix $FLUSHFIX_CASE witnesses"
  if unit_ready flushfix-units && taskset -c "$CORES" python3 tests/flushfix_checks.py check "$FLUSHFIX_CASE" \
      >"$TMPDIR/flushfix-$FLUSHFIX_CASE.log" 2>&1; then
    ok "flushfix $FLUSHFIX_CASE witnesses"
  else
    bad "flushfix $FLUSHFIX_CASE witnesses" "see $TMPDIR/flushfix-$FLUSHFIX_CASE.log"
  fi
done
row_begin "multidb serverless owners"
unit_ready multidb-unit && taskset -c "$CORES" ./build/multidb-unit \
    >"$TMPDIR/multidb-unit.log" 2>&1 \
    && taskset -c "$CORES" python3 tests/mdbqsbr_checks.py build/mdbqsbr-unit \
        >>"$TMPDIR/multidb-unit.log" 2>&1 \
    && ok "multidb serverless owners" \
    || bad "multidb serverless owners" "see $TMPDIR/multidb-unit.log"
row_begin "multidb global namespace boundary"
unit_ready multidb-boundary-unit && taskset -c "$CORES" ./build/multidb-boundary-unit \
    >"$TMPDIR/multidb-boundary-unit.log" 2>&1 \
    && python3 tests/multidb_serial.py --self-test >>"$TMPDIR/multidb-boundary-unit.log" 2>&1 \
    && ok "multidb global namespace boundary" \
    || bad "multidb global namespace boundary" "see $TMPDIR/multidb-boundary-unit.log"
# ST2: one serverless row before the quick-tier exit. The owner changes EXPECT.
# Both database images share this equality and bounded-work witness.
row_begin "storesize published monitoring"
unit_ready storesize-unit && taskset -c "$CORES" python3 tests/storesize_checks.py check-all build/storesize-unit \
    >"$TMPDIR/storesize-unit.log" 2>&1 \
    && ok "storesize published monitoring" \
    || bad "storesize published monitoring" "see $TMPDIR/storesize-unit.log"
# One serverless EXECABORT/WATCH row, collected BEFORE the quick exit (+1/+1).
# AT15: one serverless row before the quick exit (+1/+1); EXPECT/fixtures are owner-owned.
row_begin "MULTI admin command replies"
at15_ok=1
for variant in at15-unit at15-db0-unit; do
  if ! unit_ready "$variant"; then at15_ok=0; continue; fi
  for mode in 1s 2s; do
    taskset -c "$CORES" "./build/$variant" "$mode" \
        >"$TMPDIR/$variant-$mode.log" 2>&1 || at15_ok=0
  done
done
[ "$at15_ok" = 1 ] && ok "MULTI admin command replies" \
    || bad "MULTI admin command replies" "see $TMPDIR/at15-*.log"

# EXPECT_* and the ledger-label fixture remain maintainer-owned.
row_begin "EXECABORT releases WATCH reservation"
execabort_ok=1
for variant in execabort-watch-unit execabort-watch-db0-unit; do
  if ! unit_ready "$variant"; then execabort_ok=0; continue; fi
  for mode in 1s 2s; do
    for control in armed no-watch no-error; do
      args=("$mode"); [ "$control" = armed ] || args+=("$control")
      taskset -c "$CORES" "./build/$variant" "${args[@]}" \
          >"$TMPDIR/$variant-$mode-$control.log" 2>&1 || execabort_ok=0
    done
  done
  if taskset -c "$CORES" "./build/$variant" 2s no-arm \
      >"$TMPDIR/$variant-no-arm.log" 2>&1; then
    execabort_ok=0
  elif ! grep -qF 'WATCH window never armed' "$TMPDIR/$variant-no-arm.log"; then
    execabort_ok=0
  fi
done
[ "$execabort_ok" = 1 ] && ok "EXECABORT releases WATCH reservation" \
    || bad "EXECABORT releases WATCH reservation" "see $TMPDIR/execabort-watch-*.log"
# SURVIVING.md's atomic lane, plus the post-APPLY diagnostic: one build and sixteen
# named defect rows. This collection site remains above the quick-tier exit.
row_begin "atomic survivors unit build"
unit_ready atomic-survivors-unit \
    && ok "atomic survivors unit build" \
    || bad "atomic survivors unit build" "see $RUN_DIR/jobs/production_units/build.log"
for defect in admission closure script_keys rename_overlay write_latest script_apply post_apply_probe \
              lua_conversion watch_parent watch_cycle mset_arity watch_oom lua_lines \
              library_limit stage_flag instruction_limit; do
  quiet_wait
  row_begin "atomic survivor: $defect"
  taskset -c "$CORES" ./build/atomic-survivors-unit "$defect" \
      >"$TMPDIR/gate-atomic-survivors-$defect.txt" 2>&1 \
      && ok "atomic survivor: $defect" \
      || bad "atomic survivor: $defect" "see $TMPDIR/gate-atomic-survivors-$defect.txt"
done
}

job_netcmd_units(){
# Surviving networking/command audit: deterministic serverless failure states, both tiers.
# notify-retry and flush prepare a four-thread topology. Workers inherit their small load
# slot, so every unit case runs on the assigned eight-CPU server slot instead.
row_begin "netcmd regression build"
unit_ready netcmd-unit \
    && ok "netcmd regression build" || bad "netcmd regression build" "see $RUN_DIR/jobs/production_units/build.log"
# CD1: +1 row before the quick-tier exit; EXPECT counts remain maintainer-owned.
# wbknobs: +2/+2 before the quick exit; owner authorized matching EXPECT updates.
for NETCMD_CASE in streams zpop notify-oom notify-retry flush output pubsub receive config wb-small-pipe wb-complete-visits hexpire-oom; do
  row_begin "netcmd $NETCMD_CASE regression"
  taskset -c "$CORES" ./build/netcmd-unit "$NETCMD_CASE" >$TMPDIR/gate-netcmd-$NETCMD_CASE.txt 2>&1 \
      && ok "netcmd $NETCMD_CASE regression" \
      || bad "netcmd $NETCMD_CASE regression" "see $TMPDIR/gate-netcmd-$NETCMD_CASE.txt"
done
for ENCODING_CASE in knob precedence; do
  row_begin "encodingfix $ENCODING_CASE"
  unit_ready encodingfix-unit && taskset -c "$CORES" ./build/encodingfix-unit "$ENCODING_CASE" \
      >"$TMPDIR/gate-encodingfix-$ENCODING_CASE.txt" 2>&1 \
      && ok "encodingfix $ENCODING_CASE" \
      || bad "encodingfix $ENCODING_CASE" "see $TMPDIR/gate-encodingfix-$ENCODING_CASE.txt"
done
row_begin "NET1 serverless bounds + scan + reclamation"
unit_ready netcap-unit && taskset -c "$CORES" ./build/netcap-unit >"$TMPDIR/gate-netcap-unit.txt" 2>&1 \
    && ok "NET1 serverless bounds + scan + reclamation" \
    || bad "NET1 serverless bounds + scan + reclamation" "see $TMPDIR/gate-netcap-unit.txt"
}

job_netcap(){
# Four live rows, collected before the quick exit. Same eight-core/16-shard geometry;
# fixed client ownership makes the second-connection IO-thread claim observable.
local mode engine label booted
for mode in 1s 2s; do for engine in uring epoll; do
  label="NET1 inline + query cap ($mode, $engine)"
  row_begin "$label"
  booted=0
  if [ "$mode" = 1s ]; then
    boot_fused "$CANDIDATE_BINARY" --net-io "$engine" --enable-debug-command yes \
        --client-lb 0 --save '' && booted=1
  else
    boot "$CANDIDATE_BINARY" --thread-mode 2s --net-io "$engine" --enable-debug-command yes \
        --client-lb 0 --save '' && booted=1
  fi
  if [ "$booted" = 1 ] && py tests/netcap.py 127.0.0.1 "$PORT" \
      >"$TMPDIR/gate-netcap-$mode-$engine.txt" 2>&1; then
    ok "$label"
  else
    bad "$label" "see $TMPDIR/gate-netcap-$mode-$engine.txt and $SRVLOG"
  fi
  stop
done; done
}

job_respcompat(){
# NET13/14/15/16: one aggregate row, both differential geometries and atomic modes.
# Raw protocol cases own this row and its Redis oracle, outside the valid-command
# fan-out plan. Keep its shell pass total exactly equal to the planned comparisons.
local mode atomic compatible=1 booted oracle_ready=0 oracle_port=$((PORT+1))
local oracle_bin=${GATE_DIFFER_ORACLE_BIN:-$REDIS74_ROOT/src/redis-server} oracle_dir
row_begin "RESP protocol error compatibility"
guard_port "$oracle_port"
oracle_dir=$(mktemp -d "$TMPDIR/respcompat-oracle.XXXXXX") || compatible=0
if [ "$compatible" = 1 ] && [ -x "$oracle_bin" ]; then
  taskset -c "${GATE_DIFFER_ORACLE_CORES:-$CORES}" "$oracle_bin" \
      --port "$oracle_port" --bind 127.0.0.1 --save '' --appendonly no --dir "$oracle_dir" \
      >"$TMPDIR/gate-respcompat-oracle.txt" 2>&1 &
  # The gate's existing oracle slot is included in normal and watchdog cleanup.
  GLOBCASE_ORACLE=$!
  for _ in $(seq 100); do
    kill -0 "$GLOBCASE_ORACLE" 2>/dev/null || break
    if [ "$(port_listeners "$oracle_port")" = "$GLOBCASE_ORACLE" ] &&
       (exec 3<>/dev/tcp/127.0.0.1/"$oracle_port") 2>/dev/null; then
      oracle_ready=1
      break
    fi
    sleep 0.1
  done
fi
if [ "$oracle_ready" = 1 ]; then
for atomic in 0 1; do for mode in 1s 2s; do
  booted=0
  if [ "$mode" = 1s ]; then
    boot_fused "$CANDIDATE_BINARY" --read-local 1 --atomic "$atomic" --save '' && booted=1
  else
    boot "$CANDIDATE_BINARY" --thread-mode 2s --atomic "$atomic" --save '' && booted=1
  fi
  if [ "$booted" != 1 ] || ! py tests/respcompat.py 127.0.0.1 "$PORT" \
      --oracle 127.0.0.1 "$oracle_port" >"$TMPDIR/gate-respcompat-$mode-a$atomic.txt" 2>&1; then
    compatible=0
  fi
  stop
done; done
else
  compatible=0
fi
if [ "$GLOBCASE_ORACLE" -gt 0 ]; then
  kill -TERM "$GLOBCASE_ORACLE" 2>/dev/null
  if ! timeout --kill-after=1 10 tail --sleep-interval=.1 --pid="$GLOBCASE_ORACLE" -f /dev/null; then
    compatible=0
    kill -KILL "$GLOBCASE_ORACLE" 2>/dev/null
  fi
  wait "$GLOBCASE_ORACLE" 2>/dev/null || compatible=0
  GLOBCASE_ORACLE=0
fi
[ -z "$(port_listeners "$oracle_port")" ] || compatible=0
if [ "$compatible" = 1 ]; then
  ok "RESP protocol error compatibility"
else
  bad "RESP protocol error compatibility" "see $TMPDIR/gate-respcompat-*.txt and $SRVLOG"
fi
}

job_acl_metadata(){
if [ "$ORACLE_OK" = 1 ]; then
  row_begin "generated Redis 7.4 ACL categories"
  python3 tools/gen_acl_categories.py --redis-root "$REDIS74_ROOT" \
      --check src/cmd/acl_categories_generated.h \
      && ok "generated Redis 7.4 ACL categories" || bad "generated Redis 7.4 ACL categories"
else
  bad "generated Redis 7.4 ACL categories" "oracle source tree missing at $REDIS74_ROOT"
fi
}

job_boot_grammar(){
row_begin "reject --mode (flag deleted)"
reject_boot --mode 3s      2>&1 | grep -q "unknown" && ok "reject --mode (flag deleted)" || bad "reject --mode (flag deleted)"
row_begin "reject --spread"
reject_boot --spread 4:4   2>&1 | grep -q "unknown"  && ok "reject --spread"    || bad "reject --spread"
row_begin "reject --nodes"
reject_boot --nodes 2      2>&1 | grep -q "unknown"  && ok "reject --nodes"     || bad "reject --nodes"
row_begin "reject 3-part ratio"
reject_boot --ratio 4:4:2  2>&1 | grep -q "deleted"  && ok "reject 3-part ratio"|| bad "reject 3-part ratio"
row_begin "reject missing conf"
reject_boot /nonexistent-conf 2>&1 | grep -q "cannot open" && ok "reject missing conf" || bad "reject missing conf"
printf 'florb 1\n' > $TMPDIR/gate-bad.conf
row_begin "reject bad conf key"
reject_boot $TMPDIR/gate-bad.conf 2>&1 | grep -q "unknown argument" && ok "reject bad conf key" || bad "reject bad conf key"
printf 'aclfile %s\nuser alice on nopass ~* &* +@all\n' "$TMPDIR/gate-users.acl" > $TMPDIR/gate-acl-mixed.conf
row_begin "reject aclfile + conf user lines"
reject_boot $TMPDIR/gate-acl-mixed.conf 2>&1 | grep -q \
    "Configuring Redis with users defined in redis.conf and at the same setting an ACL file path is invalid" \
    && ok "reject aclfile + conf user lines" || bad "reject aclfile + conf user lines"
}

job_cmd_metadata(){
# A registered command with no generated metadata row makes command_metadata_init fail, and the
# server then refuses to boot at all -- every row below goes red at once with no indication which
# command is at fault. Static, so it fires before any server starts.
row_begin "cmdmeta covers every registered command"
py tests/cmdmeta_coverage.py --redis-root "$REDIS74_ROOT" >$TMPDIR/gate-cmdmeta-coverage.txt 2>&1 \
    && ok "cmdmeta covers every registered command" \
    || bad "cmdmeta covers every registered command" "see $TMPDIR/gate-cmdmeta-coverage.txt"
}

job_wait_units(){
# MERGEWAITS.md: six rows, all BEFORE the quick-tier exit. Build/boot failure belongs to its
# dependent row, so it cannot change the count. The retirement row intentionally includes lazy
# expiry: cx-waits alone still fails that broader no-quiescence-wait law. Never skip/xfail it.
row_begin "waits config publication + admission unit"
unit_ready waits-unit \
    && taskset -c "$CORES" ./build/waits-unit >>$TMPDIR/gate-waits-unit.txt 2>&1 \
    && tsan_unit "$WAITS_TSAN" waits-unit-tsan "waits unit: PASS" \
    && ok "waits config publication + admission unit" \
    || bad "waits config publication + admission unit" "see $TMPDIR/gate-waits-unit.txt, $TMPDIR/tsan-waits-unit-tsan.log, and $RUN_DIR/jobs/waits_tsan_build/build.log"
row_begin "reads never wait for retirement quiescence"
unit_ready rehash-waits-unit \
    && taskset -c "$CORES" ./build/rehash-waits-unit retirement \
        >>$TMPDIR/gate-rehash-waits-unit.txt 2>&1 \
    && ok "reads never wait for retirement quiescence" \
    || bad "reads never wait for retirement quiescence" "see $TMPDIR/gate-rehash-waits-unit.txt"
}

job_readonly(){
for WAIT_MODE in split fused; do
  for WAIT_LOCAL in 0 1; do
    row_begin "read-only resize $WAIT_MODE read-local=$WAIT_LOCAL"
    WAIT_BOOTED=0
    if [ "$WAIT_MODE" = split ]; then
      boot "$CANDIDATE_BINARY" --atomic 1 --read-local "$WAIT_LOCAL" \
          --flip-auto 0 --enable-debug-command yes && WAIT_BOOTED=1
    else
      boot_fused "$CANDIDATE_BINARY" --atomic 1 --read-local "$WAIT_LOCAL" \
          --flip-auto 0 --enable-debug-command yes && WAIT_BOOTED=1
    fi
    WAIT_OK=0
    WAIT_LOG="$TMPDIR/gate-rehash-readonly-$WAIT_MODE-$WAIT_LOCAL.txt"
    if [ "$WAIT_BOOTED" = 1 ] && py tests/rehash_readonly.py 127.0.0.1 "$PORT" "$WAIT_MODE" "$WAIT_LOCAL" >"$WAIT_LOG" 2>&1; then
      WAIT_OK=1
    fi
    if [ "$SRV" -gt 0 ]; then stop; fi
    if [ "$WAIT_OK" = 1 ] && shutdown_clean >>"$WAIT_LOG" 2>&1; then
      ok "read-only resize $WAIT_MODE read-local=$WAIT_LOCAL"
    else
      bad "read-only resize $WAIT_MODE read-local=$WAIT_LOCAL" "see $WAIT_LOG and $SRVLOG"
    fi
  done
done
}

job_release_batteries(){
boot "$CANDIDATE_BINARY" --enable-debug-command yes || bad "release boot"
row_begin "torture battery"
py tests/torture.py 127.0.0.1 $PORT >$TMPDIR/gate-tort.txt 2>&1 \
    && ok "torture battery" || bad "torture battery" "see $TMPDIR/gate-tort.txt"
row_begin "RYOW battery"
py tests/ryow.py 127.0.0.1 $PORT >$TMPDIR/gate-ryow.txt 2>&1 \
    && ok "RYOW battery" || bad "RYOW battery" "see $TMPDIR/gate-ryow.txt"
row_begin "ACL category runtime table"
py tests/acl_categories.py 127.0.0.1 $PORT >$TMPDIR/gate-acl-categories.txt 2>&1 \
    && ok "ACL category runtime table" || bad "ACL category runtime table" "see $TMPDIR/gate-acl-categories.txt"
row_begin "ACL LOAD/SAVE no-file errors"
py tests/acl.py 127.0.0.1 $PORT - >$TMPDIR/gate-acl-nofile.txt 2>&1 \
    && ok "ACL LOAD/SAVE no-file errors" || bad "ACL LOAD/SAVE no-file errors" "see $TMPDIR/gate-acl-nofile.txt"
# Idle-loop ceiling: owner-written counters remove scheduler/jiffy noise and name a spinning
# thread. The helper requires two fresh LBSIGNALS captures and a sampling iteration, so a missing
# DEBUG surface or cached/empty dump cannot turn this row green.
row_begin "idle loop ceiling (LBSIGNALS, 1s)"
py tests/spinprobe.py "$PORT" "$SRV" --idle-only >$TMPDIR/gate-idle-signals.txt 2>&1 \
    && ok "idle loop ceiling (LBSIGNALS, 1s)" \
    || bad "idle loop ceiling" "see $TMPDIR/gate-idle-signals.txt"
stop
# shutdown invariants + fired counters, from the TERM dump
row_begin "shutdown invariants (nothing stuck)"
shutdown_clean && py tests/lbsignals.py --shutdown "$SRVLOG" \
    && ok "shutdown invariants (nothing stuck)" || bad "shutdown invariants"
row_begin "direct-reply fired (direct=N)"
D=$(shutdown_value wb.direct)
[ -n "$D" ] && [ "$D" -gt 0 ] && ok "direct-reply fired (direct=$D)" || bad "direct-reply fired"
row_begin "dispatched==executed (N)"
R=$(shutdown_value work.dispatched)
E=$(shutdown_value work.executed)
[ -n "$R" ] && [ "$R" = "$E" ] && ok "dispatched==executed ($R)" || bad "dispatched==executed" "$R vs $E"
}

job_atomic_batteries(){
# Explicit ON boot plus the non-vacuous epoch-MVCC gates. atomic_torn includes its own OFF control,
# predecessor/promotion counters, overlapping writers, window liveness, and live CONFIG flips.
boot "$CANDIDATE_BINARY" --atomic 1 --enable-debug-command yes || bad "atomic release boot"
row_begin "atomic torn/window battery"
py tests/atomic_torn.py 127.0.0.1 $PORT --release-build >$TMPDIR/gate-atomic-torn.txt 2>&1 \
    && ok "atomic torn/window battery" || bad "atomic torn/window battery" "see $TMPDIR/gate-atomic-torn.txt"
row_begin "atomic RYOW/mixed-write battery"
py tests/atomic_ryow.py 127.0.0.1 $PORT >$TMPDIR/gate-atomic-ryow.txt 2>&1 \
    && ok "atomic RYOW/mixed-write battery" || bad "atomic RYOW/mixed-write battery" "see $TMPDIR/gate-atomic-ryow.txt"
row_begin "atomic owner-local hazard battery"
py tests/atomic_hazards.py 127.0.0.1 $PORT >$TMPDIR/gate-atomic-hazards.txt 2>&1 \
    && ok "atomic owner-local hazard battery" \
    || bad "atomic owner-local hazard battery" "see $TMPDIR/gate-atomic-hazards.txt"
stop
row_begin "atomic shutdown invariants"
shutdown_clean \
    && ok "atomic shutdown invariants" || bad "atomic shutdown invariants"
}

job_fused(){
# ---- FUSED mode: one boot per atomic mode, coarse three-stream production subset --------------
local AT=${1##*-}
  row_begin "fused boot line (atomic $AT)"
  if boot_fused "$CANDIDATE_BINARY" --atomic "$AT" --enable-debug-command yes; then
    FUSED_INFO=$(redis-cli -h 127.0.0.1 -p "$PORT" INFO server 2>/dev/null | tr -d '\r')
    FUSED_MODE=$(printf '%s\n' "$FUSED_INFO" | sed -n 's/^thread_mode://p')
    [ "$FUSED_MODE" = 1s ] \
        && grep -Eq '^tomokv-cpp: .*thread-mode=1s,.*read-local=0([,[:space:]]|$)' "$SRVLOG" \
        && ok "fused boot line (atomic $AT)" \
        || bad "fused boot line (atomic $AT)" "wire mode=$FUSED_MODE; banner must say read-local=0; see $SRVLOG"
  else
    bad "fused boot line (atomic $AT)" "server did not boot; see $SRVLOG"
  fi
  for t in s6 multi_exec edgeproto atomfix; do
    row_begin "fused $t battery (atomic $AT)"
    python3 "tests/$t.py" 127.0.0.1 "$PORT" >"$TMPDIR/gate-fused-$t-$AT.txt" 2>&1 \
        && ok "fused $t battery (atomic $AT)" \
        || bad "fused $t battery (atomic $AT)" "see $TMPDIR/gate-fused-$t-$AT.txt"
  done
  row_begin "fused spinprobe battery (atomic $AT)"
  py tests/spinprobe.py "$PORT" "$SRV" >"$TMPDIR/gate-fused-spinprobe-$AT.txt" 2>&1 \
      && ok "fused spinprobe battery (atomic $AT)" \
      || bad "fused spinprobe battery (atomic $AT)" \
             "see $TMPDIR/gate-fused-spinprobe-$AT.txt"
  row_begin "fused shutdown report (atomic $AT)"
  stop
  FUSED_REPORT_MODE=$(shutdown_value thread_mode)
  FUSED_REPORT_KIND=$(shutdown_value work.kind)
  shutdown_clean && [ "$FUSED_REPORT_MODE" = 1s ] && [ "$FUSED_REPORT_KIND" = fused ] \
      && ok "fused shutdown report (atomic $AT)" \
      || bad "fused shutdown report (atomic $AT)" \
             "mode=$FUSED_REPORT_MODE kind=$FUSED_REPORT_KIND; see $SRVLOG"
}

job_bplus(){
# ---- B+ pending-atomic filter: negative keys stay local, touched keys lower whole commands -----
# DEBUG geometry makes false positives impossible in these arms: A/B share one physical shard but
# use distinct filter cells, as do P/C on the other participating owner. ATOMIC-COMMIT-DELAY holds
# A/P after raw install and atomic_commit_holds proves the reserved/unpublished window was sampled.
boot_fused "$CANDIDATE_BINARY" --atomic 1 --read-local 1 \
    --enable-debug-command yes \
    || bad "B+ read-local purpose boot"
row_begin "B+ held-group GET/MGET filter battery"
py tests/bplus.py 127.0.0.1 "$PORT" >$TMPDIR/gate-bplus.txt 2>&1 \
    && ok "B+ held-group GET/MGET filter battery" \
    || bad "B+ held-group GET/MGET filter battery" "see $TMPDIR/gate-bplus.txt"
# Lane admission on the same armed boot: the debug cap makes 16 clients pipelining 64 GETs
# deterministically enter pressure. Require fired cap/quota counters, exact clean local
# completions, retired INFO keys absent, and separate mixed order/RYOW checks.
# The existing core route row observes actual owner-task publication under deterministic pressure.
row_begin "read-local lane admission battery"
py tests/read_local_lane.py 127.0.0.1 "$PORT" >$TMPDIR/gate-read-local-lane.txt 2>&1 \
    && ok "read-local lane admission battery" \
    || bad "read-local lane admission battery" "see $TMPDIR/gate-read-local-lane.txt"
# RL1: the held head MSET prevents retirement while INFO must report N local MGETs.
# These two rows, like the unit above, are collected BEFORE the quick-tier exit.
row_begin "read-local MGET fence battery (1s)"
py tests/read_local_lane.py 127.0.0.1 "$PORT" --mget-fence \
    >$TMPDIR/gate-rlfence-1s.txt 2>&1 \
    && ok "read-local MGET fence battery (1s)" \
    || bad "read-local MGET fence battery (1s)" "see $TMPDIR/gate-rlfence-1s.txt"
stop
row_begin "read-local MGET fence battery (2s)"
if boot "$CANDIDATE_BINARY" --atomic 1 --read-local 1 --enable-debug-command yes && \
    py tests/read_local_lane.py 127.0.0.1 "$PORT" --mget-fence \
        >$TMPDIR/gate-rlfence-2s.txt 2>&1; then
    ok "read-local MGET fence battery (2s)"
else
    bad "read-local MGET fence battery (2s)" "see $TMPDIR/gate-rlfence-2s.txt and $SRVLOG"
fi
stop
}

job_acl_recheck(){
# ---- ACL recheck over a CODED reply: exactly one reply per blocking command -------------------
# A blocking command's reply is discarded and replaced when the live ACL denies it at retire. A
# timeout answers "*-1" / "_", which are ReplyCode-carried, so a discard that clears only the byte
# buffer leaves the code standing and puts TWO replies on the wire. Its own boot in each thread
# mode: the battery creates an ACL user, and a live non-default user makes acl_active() true for
# everything else sharing the boot. Verified discriminating -- with Op::clear_reply() reverted to
# op.reply.clear() the four timeout rows fail and the rest pass.
boot "$CANDIDATE_BINARY" --enable-debug-command yes || bad "ACL-recheck reply boot (2s)"
row_begin "ACL recheck one-reply battery (2s)"
py tests/aclreply.py 127.0.0.1 "$PORT" >$TMPDIR/gate-aclreply-2s.txt 2>&1 \
    && ok "ACL recheck one-reply battery (2s)" \
    || bad "ACL recheck one-reply battery (2s)" "see $TMPDIR/gate-aclreply-2s.txt"
stop
boot_fused "$CANDIDATE_BINARY" --enable-debug-command yes || bad "ACL-recheck reply boot (1s)"
row_begin "ACL recheck one-reply battery (1s)"
py tests/aclreply.py 127.0.0.1 "$PORT" >$TMPDIR/gate-aclreply-1s.txt 2>&1 \
    && ok "ACL recheck one-reply battery (1s)" \
    || bad "ACL recheck one-reply battery (1s)" "see $TMPDIR/gate-aclreply-1s.txt"
stop
}

job_aclfix(){
# ---- round-4 ACL reproductions: each row boots its own listener (tests/aclfix.py) -------------
# sort CC4.8, streams-name CC4.9, save-load CC4.10, capacity CC4.24, wake-pop AT4.4 and
# wake-scatter AT4.6, in both thread modes on this slot's CORES/PORT: 16 shards, 2s at
# GATE_RATIO, 1s with read-local 1. Expectations are Redis 7.4.10 replies; the woken rows also
# require the element/PEL state the denial must leave. A row stays under 60 s (capacity's
# 65535 create/delete pairs plus the live-slot ceiling are about 8 s here).
  local mode case label
  for mode in 1s 2s; do
    for case in sort streams-name save-load capacity wake-pop wake-scatter; do
      label="aclfix $case ($mode)"
      row_begin "$label"
      if py tests/aclfix.py --binary "$CANDIDATE_BINARY" --port "$PORT" --cores "$CORES" \
          --mode "$mode" --ratio "$GATE_RATIO" --case "$case" \
          --output "$TMPDIR/aclfix-$case-$mode" >"$TMPDIR/aclfix-$case-$mode.log" 2>&1; then
        ok "$label"
      else
        bad "$label" "see $TMPDIR/aclfix-$case-$mode.log"
      fi
    done
  done
}

job_sort(){
# ---- SORT's dynamic keys: exact production gate geometry, both atomic modes -------------------
# tests/sort.py rejects any boot other than 16 shards at 6:2, buckets candidate names with
# DEBUG SHARD, and requires concrete BY and GET keys plus STORE destination on the executor slot
# opposite the source. No same-owner or one-executor run can satisfy this row.
for AT in 0 1; do
  boot "$CANDIDATE_BINARY" --ratio 6:2 --atomic "$AT" --enable-debug-command yes \
      || bad "cross-owner SORT boot (atomic $AT)"
  row_begin "cross-owner SORT battery (atomic $AT)"
  py tests/sort.py 127.0.0.1 "$PORT" >$TMPDIR/gate-sort-$AT.txt 2>&1 \
      && ok "cross-owner SORT battery (atomic $AT)" \
      || bad "cross-owner SORT battery (atomic $AT)" "see $TMPDIR/gate-sort-$AT.txt"
  stop
done
}

job_debug(){
# ---- debug-surface batteries: these drive DEBUG subcommands, hence their own armed boot -------
local AT=${1##*-}
  boot "$CANDIDATE_BINARY" --atomic $AT --enable-debug-command yes \
      --key-lb 0 --client-lb 0 --flip-auto 0 \
      || bad "debug-surface boot (atomic $AT)"
  # AT1/AT2: exact owner interleavings plus live, witnessed EXEC/hop/wakeup races. Both
  # debug jobs are collected BEFORE the quick exit: +2 quick, +2 full.
  # EXPECT_* remains maintainer-owned. Boot-only balancers are disabled here; the
  # battery verifies its mode with CONFIG GET and never CONFIG SETs an immutable knob.
  row_begin "plain-write lost updates (atomic $AT)"
  py tests/atomic_plain.py --self-test >$TMPDIR/gate-atomic-plain-$AT.txt 2>&1 \
      && unit_ready atomic-survivors-unit \
      && taskset -c "$CORES" ./build/atomic-survivors-unit "plain_$AT" \
          >>$TMPDIR/gate-atomic-plain-$AT.txt 2>&1 \
      && py tests/atomic_plain.py 127.0.0.1 $PORT --atomic "$AT" \
          >>$TMPDIR/gate-atomic-plain-$AT.txt 2>&1 \
      && ok "plain-write lost updates (atomic $AT)" \
      || bad "plain-write lost updates (atomic $AT)" "see $TMPDIR/gate-atomic-plain-$AT.txt"
  # scriptatomic needs the armed boot for its cross-shard section (DEBUG SHARD proves the group
  # really spans owners; ATOMIC-COMMIT-DELAY / ATOMIC-READ-DELAY widen the window). It flips
  # `atomic` itself as well, so it covers both modes from either boot.
  # execatomic needs the armed boot too: DEBUG SHARD proves its reads really fan out over more
  # than one owner, and ATOMIC-FANOUT-DEFER parks all but the lead fragment of a cross-shard read
  # so a whole transaction can commit inside the fan-out on demand. It flips `atomic` itself, so
  # either boot covers both modes.
  # execiso is the in-EXEC half of the same story and needs the same armed boot: DEBUG SHARD proves
  # its reads fan out over more than one owner, and ATOMIC-FANOUT-DEFER now parks MULTI-child
  # fragments too, so a foreign transaction can be made to commit BETWEEN two fragments of one
  # in-EXEC read on demand. It flips `atomic` itself, so either boot covers both modes. Its armed
  # arms all assert atomic_exec_read_cuts advanced, so the row cannot print PASS on a run where the
  # transaction never entered the read-cut machinery.
  # execfix needs the armed boot for DEBUG SHARD: without it a "two-owner transaction" arm could
  # silently be a same-owner arm, and every write-loss row below would pass for the wrong reason.
  # It flips `atomic` itself, so either boot covers both modes. Its rows assert counters as well as
  # data -- atomic_predecessor_reads must stay 0 (the resolver never answered from a parked
  # predecessor) and atomic_gauge_underflows must stay 0 (the store returned exactly the version
  # bytes it charged) -- and a build that cannot report either counter FAILS rather than passing.
  # xscript needs the armed boot for the same reason plus one of its own: SCRIPT-STAGE-DEFER parks
  # every cross-owner gather except the coordinator's AFTER the reservation sub-wave has armed each
  # declared key and the cut is chosen, which is the only way to land a plain write inside that
  # window on demand. Its counters (script_keys_armed / script_write_tickets_forced /
  # script_group_occ_retries) are what make the reservation falsifiable rather than merely present.
  # multirace is the withdrawn-candidate half of multires and needs the same armed boot: DEBUG
  # SHARD is what proves the aborting MSETNX's blocker really lives on an owner other than its
  # victims', without which the install-then-veto race cannot occur and every round would pass for
  # the wrong reason. Its armed cases assert atomic_exec_order_holds advanced, so the row cannot
  # print PASS on a run where no transaction fragment ever met an undecided same-connection unit,
  # and its committed-MSETNX control asserts read-your-own-writes still crosses the two units --
  # a "fix" that merely hid the group's candidate would fail there.
  for t in lbsignals slowlog atomfix scriptatomic execatomic execiso execfix multires multirace session_monotonic xacct xmove xscript; do
    FEATURE_ARGS=()
    [ "$t" = xmove ] && FEATURE_ARGS+=(--release-build)
    row_begin "$t battery (atomic $AT)"
    py tests/$t.py 127.0.0.1 $PORT "${FEATURE_ARGS[@]}" >$TMPDIR/gate-$t-$AT.txt 2>&1 \
        && ok "$t battery (atomic $AT)" || bad "$t battery (atomic $AT)" "see $TMPDIR/gate-$t-$AT.txt"
  done
  stop
}

job_script_bounds(){
# ---- cross-owner script bounds: production auto budgets and four cut slots per IO ----------
for XS_MODE in limit window; do
  boot "$CANDIDATE_BINARY" --atomic 1 --enable-debug-command yes \
      || bad "xscript $XS_MODE control boot"
  row_begin "xscript $XS_MODE control"
  py tests/xscript.py 127.0.0.1 $PORT "$XS_MODE" >$TMPDIR/gate-xscript-$XS_MODE.txt 2>&1 \
      && ok "xscript $XS_MODE control" || bad "xscript $XS_MODE control" \
             "see $TMPDIR/gate-xscript-$XS_MODE.txt"
  stop
done
}

job_scriptfix(){
  # These rows own their boots and their one slot port. Never leave the slot's
  # preboot running while the Python lifetime guard starts a candidate.
  stop
  local mode case label
  for mode in 1s 2s; do
    for case in sandbox functions replies dump; do
      label="scriptfix $case ($mode)"
      row_begin "$label"
      if py tests/scriptfix.py "$case" --binary "$CANDIDATE_BINARY" \
          --port "$PORT" --cores "$CORES" --mode "$mode" \
          --output "$TMPDIR/scriptfix" >"$TMPDIR/scriptfix-$case-$mode.log" 2>&1; then
        ok "$label"
      else
        bad "$label" "see $TMPDIR/scriptfix-$case-$mode.log"
      fi
    done
  done
}

job_efficiency(){
# ---- efficiency guards: each needs a boot geometry of its own, so each gets its own server ----
# Exact mechanism checks run on every build; timing budgets require the explicit release-build
# flag. A ratio of wall times is still a performance claim (see DESIGN-GATEHYGIENE.md).
# --shards 1 for the same reason as the borrow guard: the sidecar under test is per shard, and the
# battery asserts that precondition rather than quietly measuring a diluted one.
boot "$CANDIDATE_BINARY" --shards 1 --enable-debug-command yes || bad "expire-index guard boot"
row_begin "expire-index growth bound"
py tests/expireindex.py 127.0.0.1 $PORT --release-build >$TMPDIR/gate-expireindex.txt 2>&1 \
    && ok "expire-index growth bound" || bad "expire-index growth bound" "see $TMPDIR/gate-expireindex.txt"
stop

# one shard so every borrow lands in ONE registry (the quantity under test), and a small zc-min so
# an ordinary-sized value still takes the borrow path and pays registry cost.
boot "$CANDIDATE_BINARY" --shards 1 --zc-min 64 --client-output-buffer-limit "normal 0 0 0" \
    --enable-debug-command yes || bad "borrow-registry guard boot"
row_begin "borrow-registry growth bound"
py tests/borrow_registry.py 127.0.0.1 $PORT --release-build >$TMPDIR/gate-borrow.txt 2>&1 \
    && ok "borrow-registry growth bound" || bad "borrow-registry growth bound" "see $TMPDIR/gate-borrow.txt"
stop

# This row restores the original manual ownership geometry: two real owners plus empty fillers.
# It boots its own arms; the maintainer runs it on the quiet box with the rest of the gate.
quiet_wait
row_begin "cross-shard dispatch scaling"
XDS_PORT=$PORT XDS_CPUS=$CORES XDS_BIN="$CANDIDATE_BINARY" bash tests/xshard_dispatch_scale.sh \
    >$TMPDIR/gate-xds.txt 2>&1 \
    && ok "cross-shard dispatch scaling" || bad "cross-shard dispatch scaling" "see $TMPDIR/gate-xds.txt"
}

job_dump_restore(){
# ---- Redis-wire DUMP/RESTORE survives the native snapshot/restart boundary -------------------
DUMPRESTORE_DIR=$(mktemp -d $TMPDIR/gate-dumprestore.XXXXXX)
boot "$CANDIDATE_BINARY" --atomic 1 --dir "$DUMPRESTORE_DIR" --dbfilename dumprestore.tomo \
    || bad "DUMP/RESTORE restart preparation boot"
row_begin "DUMP/RESTORE prepare + native SAVE"
py tests/dumprestore.py 127.0.0.1 $PORT prepare_restart \
    >$TMPDIR/gate-dumprestore-restart.txt 2>&1 \
    && ok "DUMP/RESTORE prepare + native SAVE" \
    || bad "DUMP/RESTORE restart preparation" "see $TMPDIR/gate-dumprestore-restart.txt"
stop
boot "$CANDIDATE_BINARY" --atomic 1 --dir "$DUMPRESTORE_DIR" \
    --dbfilename dumprestore.tomo \
    || bad "DUMP/RESTORE snapshot reload boot"
row_begin "DUMP/RESTORE cross-restart round-trip"
py tests/dumprestore.py 127.0.0.1 $PORT verify_restart \
    >>$TMPDIR/gate-dumprestore-restart.txt 2>&1 \
    && ok "DUMP/RESTORE cross-restart round-trip" \
    || bad "DUMP/RESTORE cross-restart round-trip" "see $TMPDIR/gate-dumprestore-restart.txt"
stop
row_begin "DUMP/RESTORE restart shutdown invariants"
shutdown_clean \
    && ok "DUMP/RESTORE restart shutdown invariants" \
    || bad "DUMP/RESTORE restart shutdown invariants"
}

job_authfix(){
# Each row owns fresh config files, server PIDs and this worker's reserved port.
stop
row_begin "authfix CG4.1 binary config requirepass"
py tests/authfix.py --binary "$CANDIDATE_BINARY" --port "$PORT" --cores "$CORES" --ratio "$GATE_RATIO" \
    --case config-nul --output "$TMPDIR/authfix-config" >"$TMPDIR/authfix-config.log" 2>&1 \
    && ok "authfix CG4.1 binary config requirepass" \
    || bad "authfix CG4.1 binary config requirepass" "see $TMPDIR/authfix-config.log"
row_begin "authfix CG4.2 missing config value refuses boot"
py tests/authfix.py --binary "$CANDIDATE_BINARY" --port "$PORT" --cores "$CORES" --ratio "$GATE_RATIO" \
    --case arity --output "$TMPDIR/authfix-arity" >"$TMPDIR/authfix-arity.log" 2>&1 \
    && ok "authfix CG4.2 missing config value refuses boot" \
    || bad "authfix CG4.2 missing config value refuses boot" "see $TMPDIR/authfix-arity.log"
row_begin "authfix SV4.2 binary requirepass rewrite restart"
py tests/authfix.py --binary "$CANDIDATE_BINARY" --port "$PORT" --cores "$CORES" --ratio "$GATE_RATIO" \
    --case rewrite --output "$TMPDIR/authfix-rewrite" >"$TMPDIR/authfix-rewrite.log" 2>&1 \
    && ok "authfix SV4.2 binary requirepass rewrite restart" \
    || bad "authfix SV4.2 binary requirepass rewrite restart" "see $TMPDIR/authfix-rewrite.log"
row_begin "authfix SV4.1 slowlog credential redaction (1s)"
py tests/authfix.py --binary "$CANDIDATE_BINARY" --port "$PORT" --cores "$CORES" --ratio "$GATE_RATIO" \
    --case slowlog-1s --output "$TMPDIR/authfix-slowlog-1s" >"$TMPDIR/authfix-slowlog-1s.log" 2>&1 \
    && ok "authfix SV4.1 slowlog credential redaction (1s)" \
    || bad "authfix SV4.1 slowlog credential redaction (1s)" "see $TMPDIR/authfix-slowlog-1s.log"
row_begin "authfix SV4.1 slowlog credential redaction (2s)"
py tests/authfix.py --binary "$CANDIDATE_BINARY" --port "$PORT" --cores "$CORES" --ratio "$GATE_RATIO" \
    --case slowlog-2s --output "$TMPDIR/authfix-slowlog-2s" >"$TMPDIR/authfix-slowlog-2s.log" 2>&1 \
    && ok "authfix SV4.1 slowlog credential redaction (2s)" \
    || bad "authfix SV4.1 slowlog credential redaction (2s)" "see $TMPDIR/authfix-slowlog-2s.log"
}

job_auth(){
# ---- auth + audit DEBUG (purpose-booted; each test asserts its gate actually opened) -----------
row_begin "reject bad protected-mode"
reject_boot --protected-mode maybe 2>&1 | grep -q "protected-mode wants" \
    && ok "reject bad protected-mode" || bad "reject bad protected-mode"
row_begin "reject bad enable-debug-command"
reject_boot --enable-debug-command maybe 2>&1 | grep -q "enable-debug-command wants" \
    && ok "reject bad enable-debug-command" || bad "reject bad enable-debug-command"
boot "$CANDIDATE_BINARY" --requirepass gatepass || bad "auth purpose boot"
row_begin "AUTH/HELLO/protected state machine"
py tests/auth.py 127.0.0.1 $PORT gatepass >$TMPDIR/gate-auth.txt 2>&1 \
    && ok "AUTH/HELLO/protected state machine" || bad "AUTH/HELLO/protected state machine" "see $TMPDIR/gate-auth.txt"
stop
ACL_DIR=$(mktemp -d $TMPDIR/gate-acl.XXXXXX)
ACL_FILE="$ACL_DIR/users.acl"
: > "$ACL_FILE"
boot "$CANDIDATE_BINARY" --aclfile "$ACL_FILE" || bad "ACL purpose boot"
row_begin "ACL battery (atomic off)"
py tests/acl.py 127.0.0.1 $PORT "$ACL_FILE" >$TMPDIR/gate-acl.txt 2>&1 \
    && ok "ACL battery (atomic off)" || bad "ACL battery (atomic off)" "see $TMPDIR/gate-acl.txt"
stop
ACL_ATOMIC_FILE="$ACL_DIR/users-atomic.acl"
: > "$ACL_ATOMIC_FILE"
boot "$CANDIDATE_BINARY" --aclfile "$ACL_ATOMIC_FILE" --atomic 1 || bad "ACL atomic purpose boot"
row_begin "ACL battery (atomic on)"
py tests/acl.py 127.0.0.1 $PORT "$ACL_ATOMIC_FILE" >$TMPDIR/gate-acl-atomic.txt 2>&1 \
    && ok "ACL battery (atomic on)" || bad "ACL battery (atomic on)" "see $TMPDIR/gate-acl-atomic.txt"
stop
DEBUG_DIR=$(mktemp -d $TMPDIR/gate-debug.XXXXXX)
boot "$CANDIDATE_BINARY" --enable-debug-command local --dir "$DEBUG_DIR" --dbfilename reload.tomo \
    || bad "DEBUG purpose boot"
row_begin "DEBUG toggle/reload battery"
py tests/debug.py 127.0.0.1 $PORT >$TMPDIR/gate-debug.txt 2>&1 \
    && ok "DEBUG toggle/reload battery" || bad "DEBUG toggle/reload battery" "see $TMPDIR/gate-debug.txt"
row_begin "typed snapshot round-trip incl stream"
{ redis_cli_expect_ok FLUSHALL \
    && py tests/snap_typed_roundtrip.py $PORT build_save \
    && py tests/debug_load.py 127.0.0.1 "$PORT" RELOAD \
    && py tests/snap_typed_roundtrip.py $PORT verify; } \
    >$TMPDIR/gate-snap-typed.txt 2>&1 \
    && ok "typed snapshot round-trip incl stream" \
    || bad "typed snapshot round-trip incl stream" "see $TMPDIR/gate-snap-typed.txt"
stop
}

job_snapshot(){
# ---- snapshot data/sync engines: cut, typed round-trip, and typed preimage race ----------------
local NET_IO=${1##*-}
  SNAP_DIR=$(mktemp -d "$TMPDIR/gate-snapshot-${NET_IO}.XXXXXX")
  boot "$CANDIDATE_BINARY" --protected-mode no --net-io "$NET_IO" \
      --dir "$SNAP_DIR" --dbfilename cut.tomo \
      || bad "snapshot cut boot ($NET_IO)"
  row_begin "snapshot concurrent cut ($NET_IO)"
  py tests/snap_cut_battery.py "$PORT" save \
      >"$TMPDIR/gate-snapshot-cut-${NET_IO}.txt" 2>&1 \
      && ok "snapshot concurrent cut ($NET_IO)" \
      || bad "snapshot concurrent cut ($NET_IO)" \
             "see $TMPDIR/gate-snapshot-cut-${NET_IO}.txt"
  stop
  boot "$CANDIDATE_BINARY" --protected-mode no --net-io "$NET_IO" \
      --dir "$SNAP_DIR" --dbfilename cut.tomo \
      || bad "snapshot cut reload boot ($NET_IO)"
  row_begin "snapshot cut reload ($NET_IO)"
  py tests/snap_cut_battery.py "$PORT" verify_cut \
      >>"$TMPDIR/gate-snapshot-cut-${NET_IO}.txt" 2>&1 \
      && ok "snapshot cut reload ($NET_IO)" \
      || bad "snapshot cut reload ($NET_IO)" \
             "see $TMPDIR/gate-snapshot-cut-${NET_IO}.txt"
  stop

  # The cut battery above writes only single keys, so it passes on a tree whose snapshot tears
  # every cross-shard atomic group. These two arms are the ones that can tell the difference:
  # generation-tagged groups, a live MGET reader that must stay clean throughout, and the
  # cuts_waited counter that separates a real group drain from a vacuous one. Both arms were
  # confirmed to FAIL on the pre-fix tree (44-53 and 10-13 torn groups per cut respectively).
  GROUP_DIR=$(mktemp -d "$TMPDIR/gate-snapshot-groups-${NET_IO}.XXXXXX")
  boot "$CANDIDATE_BINARY" --protected-mode no --net-io "$NET_IO" --atomic 1 \
      --enable-debug-command yes --dir "$GROUP_DIR" --dbfilename groups.tomo \
      || bad "atomic group cut boot ($NET_IO, atomic 1)"
  row_begin "snapshot never tears a cross-shard MSET group ($NET_IO, atomic 1)"
  py tests/snap_cut_battery.py "$PORT" atomic_groups "$GROUP_DIR/groups.tomo" mset 5 \
      >"$TMPDIR/gate-snapshot-groups-mset-${NET_IO}.txt" 2>&1 \
      && grep -q "ATOMIC_GROUP_CUT PASS" "$TMPDIR/gate-snapshot-groups-mset-${NET_IO}.txt" \
      && ok "snapshot never tears a cross-shard MSET group ($NET_IO, atomic 1)" \
      || bad "snapshot never tears a cross-shard MSET group ($NET_IO, atomic 1)" \
             "see $TMPDIR/gate-snapshot-groups-mset-${NET_IO}.txt"
  stop
  # CONTROL ARM: the DEFAULT --atomic 0. EXEC force-admits a group at either setting, so a
  # transaction is atomic to readers here too and the file must agree with them.
  boot "$CANDIDATE_BINARY" --protected-mode no --net-io "$NET_IO" --atomic 0 \
      --enable-debug-command yes --dir "$GROUP_DIR" --dbfilename groups.tomo \
      || bad "atomic group cut boot ($NET_IO, atomic 0)"
  row_begin "snapshot never tears a MULTI/EXEC group ($NET_IO, default atomic 0)"
  py tests/snap_cut_battery.py "$PORT" atomic_groups "$GROUP_DIR/groups.tomo" exec 3 \
      >"$TMPDIR/gate-snapshot-groups-exec-${NET_IO}.txt" 2>&1 \
      && grep -q "ATOMIC_GROUP_CUT PASS" "$TMPDIR/gate-snapshot-groups-exec-${NET_IO}.txt" \
      && ok "snapshot never tears a MULTI/EXEC group ($NET_IO, default atomic 0)" \
      || bad "snapshot never tears a MULTI/EXEC group ($NET_IO, default atomic 0)" \
             "see $TMPDIR/gate-snapshot-groups-exec-${NET_IO}.txt"
  stop

  TYPED_DIR=$(mktemp -d "$TMPDIR/gate-snapshot-typed-${NET_IO}.XXXXXX")
  boot "$CANDIDATE_BINARY" --protected-mode no --net-io "$NET_IO" \
      --dir "$TYPED_DIR" --dbfilename typed.tomo \
      || bad "typed snapshot boot ($NET_IO)"
  row_begin "typed snapshot save ($NET_IO)"
  py tests/snap_typed_roundtrip.py "$PORT" build_save \
      >"$TMPDIR/gate-snapshot-typed-${NET_IO}.txt" 2>&1 \
      && ok "typed snapshot save ($NET_IO)" \
      || bad "typed snapshot save ($NET_IO)" \
             "see $TMPDIR/gate-snapshot-typed-${NET_IO}.txt"
  stop
  boot "$CANDIDATE_BINARY" --protected-mode no --net-io "$NET_IO" \
      --dir "$TYPED_DIR" --dbfilename typed.tomo \
      || bad "typed snapshot reload boot ($NET_IO)"
  row_begin "typed snapshot reload ($NET_IO)"
  py tests/snap_typed_roundtrip.py "$PORT" verify \
      >>"$TMPDIR/gate-snapshot-typed-${NET_IO}.txt" 2>&1 \
      && ok "typed snapshot reload ($NET_IO)" \
      || bad "typed snapshot reload ($NET_IO)" \
             "see $TMPDIR/gate-snapshot-typed-${NET_IO}.txt"
  stop

  RACE_DIR=$(mktemp -d "$TMPDIR/gate-snapshot-race-${NET_IO}.XXXXXX")
  boot "$CANDIDATE_BINARY" --protected-mode no --net-io "$NET_IO" \
      --dir "$RACE_DIR" --dbfilename race.tomo --save '' --enable-debug-command yes \
      || bad "typed snapshot race boot ($NET_IO)"
  row_begin "typed snapshot preimage race ($NET_IO)"
  py tests/snap_typed_race.py "$PORT" race "$RACE_DIR/race.tomo" \
      >"$TMPDIR/gate-snapshot-race-${NET_IO}.txt" 2>&1 \
      && grep -q 'PREIMAGE-FIRED PASS' "$TMPDIR/gate-snapshot-race-${NET_IO}.txt" \
      && grep -q 'SNAPSHOT-TICKET-ORACLE PASS' "$TMPDIR/gate-snapshot-race-${NET_IO}.txt" \
      && ok "typed snapshot preimage race ($NET_IO)" \
      || bad "typed snapshot preimage race ($NET_IO)" \
             "see $TMPDIR/gate-snapshot-race-${NET_IO}.txt"
  stop
  boot "$CANDIDATE_BINARY" --protected-mode no --net-io "$NET_IO" \
      --dir "$RACE_DIR" --dbfilename race.tomo.cut \
      || bad "typed snapshot race reload boot ($NET_IO)"
  row_begin "typed snapshot race reload ($NET_IO)"
  py tests/snap_typed_race.py "$PORT" verify "$RACE_DIR/race.tomo.oracle.json" \
      >>"$TMPDIR/gate-snapshot-race-${NET_IO}.txt" 2>&1 \
      && ok "typed snapshot race reload ($NET_IO)" \
      || bad "typed snapshot race reload ($NET_IO)" \
             "see $TMPDIR/gate-snapshot-race-${NET_IO}.txt"
  stop

  # Each savefix row owns its boot and recovery; stop the job's listener first.
  for SAVEFIX_MODE in 1s 2s; do
    for SAVEFIX_ACTION in sigterm command; do
      row_begin "shutdown keeps acknowledged writes ($SAVEFIX_MODE, $SAVEFIX_ACTION, $NET_IO)"
      py tests/savefix.py --binary "$CANDIDATE_BINARY" --cores "$CORES" --port "$PORT" \
          --case acks --mode "$SAVEFIX_MODE" --action "$SAVEFIX_ACTION" \
          --net-io "$NET_IO" --ratio "$GATE_RATIO" \
          --output "$TMPDIR/savefix-acks-$SAVEFIX_MODE-$SAVEFIX_ACTION" \
          >"$TMPDIR/savefix-acks-$SAVEFIX_MODE-$SAVEFIX_ACTION.log" 2>&1 \
          && ok "shutdown keeps acknowledged writes ($SAVEFIX_MODE, $SAVEFIX_ACTION, $NET_IO)" \
          || bad "shutdown keeps acknowledged writes ($SAVEFIX_MODE, $SAVEFIX_ACTION, $NET_IO)" \
                 "see $TMPDIR/savefix-acks-$SAVEFIX_MODE-$SAVEFIX_ACTION.log"
    done
    for SAVEFIX_ATOMIC in 0 1; do
      row_begin "shutdown cancels BGSAVE capture ($SAVEFIX_MODE, atomic $SAVEFIX_ATOMIC, $NET_IO)"
      py tests/savefix.py --binary "$CANDIDATE_BINARY" --cores "$CORES" --port "$PORT" \
          --case bgsave --mode "$SAVEFIX_MODE" --atomic "$SAVEFIX_ATOMIC" \
          --net-io "$NET_IO" --ratio "$GATE_RATIO" \
          --output "$TMPDIR/savefix-bgsave-$SAVEFIX_MODE-$SAVEFIX_ATOMIC" \
          >"$TMPDIR/savefix-bgsave-$SAVEFIX_MODE-$SAVEFIX_ATOMIC.log" 2>&1 \
          && ok "shutdown cancels BGSAVE capture ($SAVEFIX_MODE, atomic $SAVEFIX_ATOMIC, $NET_IO)" \
          || bad "shutdown cancels BGSAVE capture ($SAVEFIX_MODE, atomic $SAVEFIX_ATOMIC, $NET_IO)" \
                 "see $TMPDIR/savefix-bgsave-$SAVEFIX_MODE-$SAVEFIX_ATOMIC.log"
    done
  done
}

job_notify(){
# ---- notify lane: integrated owner/retire seams plus both live atomic settings -----------------
boot "$CANDIDATE_BINARY" --notify-keyspace-events KEAmn --enable-debug-command yes \
    || bad "feature battery boot + notify CLI knob"   # armed: multi_exec.py needs DEBUG SHARD
                                                       # to locate a same-owner key pair, and it
                                                       # FAILS rather than skips without it
row_begin "MULTI feature battery"
py tests/multi_exec.py 127.0.0.1 $PORT >$TMPDIR/gate-multi.txt 2>&1 \
    && ok "MULTI feature battery" || bad "MULTI feature battery" "see $TMPDIR/gate-multi.txt"
row_begin "blocking feature battery"
py tests/blocking.py 127.0.0.1 $PORT >$TMPDIR/gate-blocking.txt 2>&1 \
    && ok "blocking feature battery" || bad "blocking feature battery" "see $TMPDIR/gate-blocking.txt"
row_begin "pubsub feature battery"
py tests/pubsub.py 127.0.0.1 $PORT >$TMPDIR/gate-pubsub.txt 2>&1 \
    && ok "pubsub feature battery" || bad "pubsub feature battery" "see $TMPDIR/gate-pubsub.txt"
row_begin "Lua feature battery"
py tests/lua_scripting.py 127.0.0.1 $PORT >$TMPDIR/gate-lua.txt 2>&1 \
    && ok "Lua feature battery" || bad "Lua feature battery" "see $TMPDIR/gate-lua.txt"
row_begin "keyspace notification battery (atomic 0/1)"
py tests/notify.py 127.0.0.1 $PORT >$TMPDIR/gate-notify.txt 2>&1 \
    && ok "keyspace notification battery (atomic 0/1)" \
    || bad "keyspace notification battery" "see $TMPDIR/gate-notify.txt"
stop
row_begin "feature battery shutdown invariants"
shutdown_clean \
    && ok "feature battery shutdown invariants" || bad "feature battery shutdown invariants"
}

job_flip(){
# ---- FLIP lane: runtime thread reshaping is a shipped feature and gates like one ---------------
# Four rows, each guarding a failure class that actually shipped once:
#   flip.py            the 542-check state battery (incl. same-split no-op moves NOTHING)
#   flip_under_load    value-verified traffic + flips: no drops, no BUSY, no regressions
#   flip_ttl           TTL state AND expiry events survive the shard/client moves a flip performs
#   saturated flips    a one-shot quiesce snapshot once refused ~every flip under 512-conn
#                      pipelined load while 8-conn tests sailed through; this row flips under
#                      real saturation and asserts every one APPLIES (live split == requested)
boot "$CANDIDATE_BINARY" --enable-debug-command yes || bad "flip battery boot"
row_begin "FLIP state battery"
py tests/flip.py 127.0.0.1 $PORT >$TMPDIR/gate-flip.txt 2>&1 \
    && ok "FLIP state battery" || bad "FLIP state battery" "see $TMPDIR/gate-flip.txt"
row_begin "FLIP under verified load"
py tests/flip_under_load.py 127.0.0.1 $PORT 20 >$TMPDIR/gate-flip-load.txt 2>&1 \
    && ok "FLIP under verified load" || bad "FLIP under verified load" "see $TMPDIR/gate-flip-load.txt"
row_begin "FLIP TTL + expiry events"
py tests/flip_ttl.py 127.0.0.1 $PORT >$TMPDIR/gate-flip-ttl.txt 2>&1 \
    && ok "FLIP TTL + expiry events" || bad "FLIP TTL + expiry events" "see $TMPDIR/gate-flip-ttl.txt"
row_begin "partial-frame conn parks (no io spin)"
py tests/spinprobe.py $PORT "$SRV" >$TMPDIR/gate-spinprobe.txt 2>&1 \
    && ok "partial-frame conn parks (no io spin)" || bad "partial-frame conn parks (no io spin)" "see $TMPDIR/gate-spinprobe.txt"
stop
# flipfix (IO4.1, IO4.2). Each row owns its boots on this slot's $PORT, now free. Closing peers
# during FLIPs once wedged the server or held each FLIP to its 5 s deadline; with save clauses
# armed a SIGTERM during a FLIP was not served and a second SIGINT was absorbed.
for NET_IO in uring epoll; do
  row_begin "FLIP close during FLIP ($NET_IO)"
  py tests/flipfix.py close --binary "$CANDIDATE_BINARY" --port "$PORT" --cores "$CORES" \
      --ratio "$GATE_RATIO" --net-io "$NET_IO" --output "$TMPDIR/flipfix-close-$NET_IO" \
      >"$TMPDIR/gate-flipfix-close-$NET_IO.txt" 2>&1 \
      && ok "FLIP close during FLIP ($NET_IO)" \
      || bad "FLIP close during FLIP ($NET_IO)" "see $TMPDIR/gate-flipfix-close-$NET_IO.txt"
done
row_begin "FLIP signal stop during FLIP + second SIGINT"
{ py tests/flipfix.py sigterm --binary "$CANDIDATE_BINARY" --port "$PORT" --cores "$CORES" \
      --ratio "$GATE_RATIO" --output "$TMPDIR/flipfix-sigterm" &&
  py tests/flipfix.py sigint --binary "$CANDIDATE_BINARY" --port "$PORT" --cores "$CORES" \
      --ratio "$GATE_RATIO" --output "$TMPDIR/flipfix-sigint"; } >"$TMPDIR/gate-flipfix-signal.txt" 2>&1 \
    && ok "FLIP signal stop during FLIP + second SIGINT" \
    || bad "FLIP signal stop during FLIP + second SIGINT" "see $TMPDIR/gate-flipfix-signal.txt"
}

job_flip_saturated(){
boot "$CANDIDATE_BINARY" --enable-debug-command yes || bad "flip battery reboot"
quiet_wait
row_begin "FLIP applies under saturated load"
(
  taskset -c "$LOAD_CORES" memtier_benchmark -s 127.0.0.1 -p $PORT --protocol=redis -t 8 -c 32 \
    --pipeline=16 --ratio=1:1 --key-pattern=R:R --key-minimum=1 --key-maximum=200000 -d 64 \
    --test-time=25 --distinct-client-seed --hide-histogram >/dev/null 2>&1 &
  MTPID=$!
  sleep 3
  SATOK=1
  TOTAL=$(redis-cli -p $PORT flip 2>/dev/null | paste - - | awk '/live_io/{a=$2} /live_ex/{b=$2} END{print a+b}')
  for FR in 25 75 50; do
    TIO=$(( TOTAL * FR / 100 )); [ "$TIO" -lt 2 ] && TIO=2; [ "$TIO" -gt $((TOTAL-2)) ] && TIO=$((TOTAL-2))
    OUT=$(redis-cli -p $PORT flip $TIO $((TOTAL-TIO)) 2>&1); sleep 1
    LIVE=$(redis-cli -p $PORT flip 2>/dev/null | paste - - | awk '/live_io/{print $2; exit}')
    { [ "$OUT" = "OK" ] && [ "$LIVE" = "$TIO" ]; } || { SATOK=0; echo "flip $TIO refused/missed: '$OUT' live=$LIVE" >>$TMPDIR/gate-flip-sat.txt; }
  done
  kill -9 $MTPID 2>/dev/null; wait "$MTPID" 2>/dev/null
  # The 256 SIGKILLed connections must REAP before shutdown or the drain line reports them as
  # live (observed: live_conns=256 on the oversubscribed gate cores, where io threads are starved
  # at the moment of the kill). Waiting for reaping keeps the shutdown invariant meaningful: dead
  # clients that never reap would be a real defect and still fail the row.
  for _ in $(seq 100); do
    LEFT=$(redis-cli -p $PORT info clients 2>/dev/null | tr -d '\r' | sed -n 's/^connected_clients://p')
    [ -n "$LEFT" ] && [ "$LEFT" -le 2 ] && break
    sleep 0.1
  done
  exit $((1 - SATOK))
) && ok "FLIP applies under saturated load" \
  || bad "FLIP applies under saturated load" "see $TMPDIR/gate-flip-sat.txt"
stop
# The saturation row kill -9s its memtier, so 256 aborted connections drain at shutdown -- the
# invariant line lands a beat after stop returns. Poll instead of racing it.
row_begin "flip battery shutdown invariants"
FLIPSHUT=0
for _ in $(seq 50); do
  shutdown_clean \
      && { FLIPSHUT=1; break; }
  sleep 0.1
done
[ "$FLIPSHUT" = 1 ] && ok "flip battery shutdown invariants" \
    || bad "flip battery shutdown invariants"
}

job_atomic_floor(){
# ---- atomic multi-key throughput floor -------------------------------------------------------
# A 9x per-op tax on the atomic chain-read path (tripwire armed by --enable-debug-command alone)
# once passed this gate 236/236: nothing here drove MGET/MSET through the resolver and asserted a
# rate. Floor = 120k on the oversubscribed gate cores; healthy measures ~600k (5x margin), the
# regression class this catches lands under 70k. Boots the harness posture on purpose -- debug
# enabled, tripwire NOT armed -- because that is the posture every bench and gate row runs in.
boot "$CANDIDATE_BINARY" --atomic 1 --enable-debug-command yes || bad "atomic mm floor boot"
row_begin "atomic MGET/MSET floor (N/s >= 120k)"
MM_K8="__key__ __key__ __key__ __key__ __key__ __key__ __key__ __key__"
MM_M8="__key__ __data__ __key__ __data__ __key__ __data__ __key__ __data__ __key__ __data__ __key__ __data__ __key__ __data__ __key__ __data__"
quiet_wait
taskset -c "$LOAD_CORES" memtier_benchmark -s 127.0.0.1 -p $PORT --protocol=redis -t 4 -c 16 \
  --pipeline=16 --command="MGET $MM_K8" --command-ratio=9 --command-key-pattern=R \
  --command="MSET $MM_M8" --command-ratio=1 --command-key-pattern=R -d 64 \
  --key-minimum=1 --key-maximum=200000 --test-time=20 --hide-histogram >/dev/null 2>&1 &
MMPID=$!
sleep 8
MM_C0=$(redis-cli -p $PORT info stats 2>/dev/null | tr -d '\r' | sed -n 's/^total_commands_processed://p')
sleep 6
MM_C1=$(redis-cli -p $PORT info stats 2>/dev/null | tr -d '\r' | sed -n 's/^total_commands_processed://p')
kill -9 $MMPID 2>/dev/null; wait $MMPID 2>/dev/null; MMPID=0
MM_RATE=$(( (${MM_C1:-0} - ${MM_C0:-0}) / 6 ))
[ "$MM_RATE" -ge 120000 ] \
    && ok "atomic MGET/MSET floor (${MM_RATE}/s >= 120k)" \
    || bad "atomic MGET/MSET floor" "measured ${MM_RATE}/s < 120000/s"
# Same boot: the explicit arm surface answers OK both ways (observation itself is priced by the
# floor row above -- if arming ever becomes the boot default again, that row fails, not this one).
row_begin "tripwire arm/disarm round-trip"
TWARM=$(redis-cli -p $PORT debug tripwire arm 2>&1)
TWDIS=$(redis-cli -p $PORT debug tripwire disarm 2>&1)
{ [ "$TWARM" = "OK" ] && [ "$TWDIS" = "OK" ]; } \
    && ok "tripwire arm/disarm round-trip" \
    || bad "tripwire arm/disarm round-trip" "arm='$TWARM' disarm='$TWDIS'"
# Same boot: pipelined same-connection program order (the seed-19 divergence). Pre-fix this
# answered stale in ~74% of iterations, so 400 iterations are a decisive non-vacuous roll.
row_begin "pipelined same-conn program order (400 rolls)"
python3 tests/pipeorder.py $PORT 400 >$TMPDIR/gate-pipeorder.txt 2>&1 \
    && ok "pipelined same-conn program order (400 rolls)" \
    || bad "pipelined same-conn program order" "see $TMPDIR/gate-pipeorder.txt"
stop
}

job_aof(){
# ---- AOF boot/replay + non-vacuous DEBUG LOADAOF ---------------------------------------------
local NET_IO=${1##*-}
for AOF_ATOMIC in 0 1; do
AOF_DIR=$(mktemp -d "$TMPDIR/gate-aof-${NET_IO}-atomic${AOF_ATOMIC}.XXXXXX")
AOF_STATE=$AOF_DIR/state.json
boot "$CANDIDATE_BINARY" --protected-mode no --atomic "$AOF_ATOMIC" \
    --appendonly yes --appendfsync no \
    --net-io "$NET_IO" --enable-debug-command yes --dir "$AOF_DIR" \
    || bad "AOF purpose boot ($NET_IO, atomic $AOF_ATOMIC)"
row_begin "configuration reduction + actual geometry ($NET_IO, atomic $AOF_ATOMIC)"
py tests/knobs.py 127.0.0.1 "$PORT" "$NET_IO" "$AOF_ATOMIC" \
    >"$TMPDIR/gate-knobs-${NET_IO}-${AOF_ATOMIC}.txt" 2>&1 \
    && ok "configuration reduction + actual geometry ($NET_IO, atomic $AOF_ATOMIC)" \
    || bad "configuration reduction + actual geometry ($NET_IO, atomic $AOF_ATOMIC)"
row_begin "AOF byte-exact + script groups + DEBUG LOADAOF ($NET_IO, atomic $AOF_ATOMIC)"
py tests/aof.py 127.0.0.1 $PORT populate "$AOF_STATE" >$TMPDIR/gate-aof-$NET_IO-$AOF_ATOMIC.txt 2>&1 \
    && py tests/aof.py 127.0.0.1 $PORT loadaof "$AOF_STATE" >>$TMPDIR/gate-aof-$NET_IO-$AOF_ATOMIC.txt 2>&1 \
    && ok "AOF byte-exact + script groups + DEBUG LOADAOF ($NET_IO, atomic $AOF_ATOMIC)" \
    || bad "AOF byte-exact + script groups + DEBUG LOADAOF ($NET_IO, atomic $AOF_ATOMIC)" \
           "see $TMPDIR/gate-aof-$NET_IO-$AOF_ATOMIC.txt"
row_begin "AOF writer fired (records=N)"
AOF_PRE_MODEL=$(py tests/aof.py 127.0.0.1 $PORT snapshot "$AOF_DIR/dump.tomo" 2>>$TMPDIR/gate-aof-$NET_IO-$AOF_ATOMIC.txt)
AOF_WRITTEN=$(redis-cli -h 127.0.0.1 -p $PORT INFO Persistence 2>/dev/null \
    | tr -d '\r' | sed -n 's/^aof_records_written://p')
[ -n "$AOF_WRITTEN" ] && [ "$AOF_WRITTEN" -gt 0 ] \
    && ok "AOF writer fired (records=$AOF_WRITTEN)" || bad "AOF writer fired"
kill -KILL $SRV 2>/dev/null
wait $SRV 2>/dev/null
settle
boot "$CANDIDATE_BINARY" --protected-mode no --appendonly yes --appendfsync no \
    --atomic "$AOF_ATOMIC" --net-io "$NET_IO" \
    --enable-debug-command yes --dir "$AOF_DIR" \
    || bad "AOF replay boot ($NET_IO, atomic $AOF_ATOMIC)"
row_begin "AOF process-restart script replay ($NET_IO, atomic $AOF_ATOMIC)"
py tests/aof.py 127.0.0.1 $PORT verify "$AOF_STATE" >>$TMPDIR/gate-aof-$NET_IO-$AOF_ATOMIC.txt 2>&1 \
    && ok "AOF process-restart script replay ($NET_IO, atomic $AOF_ATOMIC)" \
    || bad "AOF process-restart script replay ($NET_IO, atomic $AOF_ATOMIC)" \
           "see $TMPDIR/gate-aof-$NET_IO-$AOF_ATOMIC.txt"
row_begin "AOF native snapshot streams byte-exact"
AOF_POST_MODEL=$(py tests/aof.py 127.0.0.1 $PORT snapshot "$AOF_DIR/dump.tomo" 2>>$TMPDIR/gate-aof-$NET_IO-$AOF_ATOMIC.txt)
[ -n "$AOF_PRE_MODEL" ] && [ "$AOF_PRE_MODEL" = "$AOF_POST_MODEL" ] \
    && ok "AOF native snapshot streams byte-exact" || bad "AOF native snapshot streams byte-exact"
row_begin "AOF replay fired (records=N skipped=N)"
AOF_REPLAYED=$(redis-cli -h 127.0.0.1 -p $PORT INFO Persistence 2>/dev/null \
    | tr -d '\r' | sed -n 's/^aof_replayed_records://p')
AOF_SKIPPED=$(redis-cli -h 127.0.0.1 -p $PORT INFO Persistence 2>/dev/null \
    | tr -d '\r' | sed -n 's/^aof_groups_skipped_on_replay://p')
[ -n "$AOF_REPLAYED" ] && [ "$AOF_REPLAYED" -gt 0 ] && [ -n "$AOF_SKIPPED" ] \
    && ok "AOF replay fired (records=$AOF_REPLAYED skipped=$AOF_SKIPPED)" || bad "AOF replay fired"
stop
done

# ---- AOF atomic-group bracketing + directed interrupted-process recovery ---------------------
AOF_GROUP_DIR=$(mktemp -d "$TMPDIR/gate-aof-group-${NET_IO}.XXXXXX")
AOF_GROUP_STATE=$AOF_GROUP_DIR/state.json
boot "$CANDIDATE_BINARY" --protected-mode no --atomic 1 --appendonly yes --appendfsync no \
    --net-io "$NET_IO" --enable-debug-command yes --dir "$AOF_GROUP_DIR" \
    || bad "AOF group purpose boot ($NET_IO)"
row_begin "AOF directed group interruption fired"
py tests/aof_torn_group.py 127.0.0.1 $PORT prepare "$AOF_GROUP_STATE" \
    >$TMPDIR/gate-aof-group.txt 2>&1 \
    && ok "AOF directed group interruption fired" \
    || bad "AOF directed group interruption" "see $TMPDIR/gate-aof-group.txt"
wait $SRV 2>/dev/null
settle
boot "$CANDIDATE_BINARY" --protected-mode no --atomic 1 --appendonly yes --appendfsync no \
    --net-io "$NET_IO" --enable-debug-command yes --dir "$AOF_GROUP_DIR" \
    || bad "AOF group recovery boot ($NET_IO)"
row_begin "AOF atomic-group recovery + writer order"
py tests/aof_torn_group.py 127.0.0.1 $PORT verify "$AOF_GROUP_STATE" \
    >>$TMPDIR/gate-aof-group.txt 2>&1 \
    && py tests/aof_torn_group.py 127.0.0.1 $PORT scan \
       "$AOF_GROUP_DIR/appendonlydir/appendonly.aof.1.incr.tomo" \
       >>$TMPDIR/gate-aof-group.txt 2>&1 \
    && ok "AOF atomic-group recovery + writer order" \
    || bad "AOF atomic-group recovery + writer order" "see $TMPDIR/gate-aof-group.txt"
stop
row_begin "AOF group shutdown invariants"
shutdown_clean \
    && ok "AOF group shutdown invariants" || bad "AOF group shutdown invariants"

# ---- AOF sync policies, reply gate, idle sync, and durability-window recovery ----------------
AOF_ALWAYS_DIR=$(mktemp -d "$TMPDIR/gate-aof-always-${NET_IO}.XXXXXX")
AOF_ALWAYS_STATE=$AOF_ALWAYS_DIR/state.json
boot "$CANDIDATE_BINARY" --protected-mode no --atomic 1 --appendonly yes --appendfsync always \
    --net-io "$NET_IO" --dir "$AOF_ALWAYS_DIR" \
    || bad "AOF always purpose boot ($NET_IO)"
row_begin "AOF always sync + reply gate fired"
py tests/aof_fsync.py 127.0.0.1 $PORT populate "$AOF_ALWAYS_STATE" always 512 \
    >$TMPDIR/gate-aof-always.txt 2>&1 \
    && ok "AOF always sync + reply gate fired" \
    || bad "AOF always sync + reply gate" "see $TMPDIR/gate-aof-always.txt"
kill -KILL $SRV 2>/dev/null
wait $SRV 2>/dev/null
settle
boot "$CANDIDATE_BINARY" --protected-mode no --atomic 1 --appendonly yes --appendfsync always \
    --net-io "$NET_IO" --dir "$AOF_ALWAYS_DIR" \
    || bad "AOF always recovery boot ($NET_IO)"
row_begin "AOF always recovery after quiescent SIGKILL"
py tests/aof_fsync.py 127.0.0.1 $PORT verify "$AOF_ALWAYS_STATE" always 512 \
    >>$TMPDIR/gate-aof-always.txt 2>&1 \
    && ok "AOF always recovery after quiescent SIGKILL" \
    || bad "AOF always recovery after quiescent SIGKILL" "see $TMPDIR/gate-aof-always.txt"
stop

# Four rows per engine, eight total; this job is collected BEFORE the quick exit.
# stop above reaps the gate-owned server before handing its allocated PORT to the
# driver. The everysec boot below takes ownership back after all four runs exit.
# Each script owns fresh data, both boots and its exact child PID. No existing data
# or server is reused, including by the deliberately broken mainline control arms.
for PERSIST_MODE in 2s 1s; do
  for PERSIST_CASE in kill term; do
    row_begin "AOF in-window $PERSIST_CASE recovery ($PERSIST_MODE, $NET_IO)"
    quiet_wait
    if python3 tests/persistfix.py --binary "$CANDIDATE_BINARY" --mode "$PERSIST_MODE" \
        --case "$PERSIST_CASE" --net-io "$NET_IO" --cores "$CORES" --ratio "$GATE_RATIO" \
        --port "$PORT" --artifacts "$TMPDIR/persistfix" \
        >"$TMPDIR/persistfix-$PERSIST_MODE-$PERSIST_CASE.log" 2>&1; then
      ok "AOF in-window $PERSIST_CASE recovery ($PERSIST_MODE, $NET_IO)"
    else
      bad "AOF in-window $PERSIST_CASE recovery ($PERSIST_MODE, $NET_IO)" \
          "see $TMPDIR/persistfix-$PERSIST_MODE-$PERSIST_CASE.log"
    fi
  done
done

# persistfix rows above own and reap their processes. This row owns the same
# now-free port, including its recovery boot; the following boot takes it back.
for SAVEFIX_MODE in 1s 2s; do
  for SAVEFIX_ATOMIC in 0 1; do
    row_begin "shutdown cancels AOF rewrite capture ($SAVEFIX_MODE, atomic $SAVEFIX_ATOMIC, $NET_IO)"
    py tests/savefix.py --binary "$CANDIDATE_BINARY" --cores "$CORES" --port "$PORT" \
        --case rewrite --mode "$SAVEFIX_MODE" --atomic "$SAVEFIX_ATOMIC" \
        --net-io "$NET_IO" --ratio "$GATE_RATIO" \
        --output "$TMPDIR/savefix-rewrite-$SAVEFIX_MODE-$SAVEFIX_ATOMIC" \
        >"$TMPDIR/savefix-rewrite-$SAVEFIX_MODE-$SAVEFIX_ATOMIC.log" 2>&1 \
        && ok "shutdown cancels AOF rewrite capture ($SAVEFIX_MODE, atomic $SAVEFIX_ATOMIC, $NET_IO)" \
        || bad "shutdown cancels AOF rewrite capture ($SAVEFIX_MODE, atomic $SAVEFIX_ATOMIC, $NET_IO)" \
               "see $TMPDIR/savefix-rewrite-$SAVEFIX_MODE-$SAVEFIX_ATOMIC.log"
  done
done

AOF_EVERY_DIR=$(mktemp -d "$TMPDIR/gate-aof-everysec-${NET_IO}.XXXXXX")
AOF_EVERY_STATE=$AOF_EVERY_DIR/state.json
AOF_EVERY_FILE=$AOF_EVERY_DIR/appendonlydir/appendonly.aof.1.incr.tomo
boot "$CANDIDATE_BINARY" --protected-mode no --atomic 1 --appendonly yes --appendfsync everysec \
    --net-io "$NET_IO" --dir "$AOF_EVERY_DIR" \
    || bad "AOF everysec purpose boot ($NET_IO)"
row_begin "AOF everysec write gate + idle sync fired"
py tests/aof_fsync.py 127.0.0.1 $PORT populate "$AOF_EVERY_STATE" everysec 512 \
    >$TMPDIR/gate-aof-everysec.txt 2>&1 \
    && ok "AOF everysec write gate + idle sync fired" \
    || bad "AOF everysec write gate + idle sync" "see $TMPDIR/gate-aof-everysec.txt"
kill -KILL $SRV 2>/dev/null
wait $SRV 2>/dev/null
AOF_EVERY_SIZE=$(stat -c %s "$AOF_EVERY_FILE" 2>/dev/null || echo 0)
case "$AOF_EVERY_FILE" in
  "$AOF_EVERY_DIR"/appendonlydir/*)
    [ "$AOF_EVERY_SIZE" -gt 7 ] && truncate -s $((AOF_EVERY_SIZE-7)) "$AOF_EVERY_FILE" ;;
  *) bad "AOF everysec tail target" ;;
esac
settle
boot "$CANDIDATE_BINARY" --protected-mode no --atomic 1 --appendonly yes --appendfsync everysec \
    --net-io "$NET_IO" --dir "$AOF_EVERY_DIR" \
    || bad "AOF everysec recovery boot ($NET_IO)"
row_begin "AOF everysec durability window + tail warning"
py tests/aof_fsync.py 127.0.0.1 $PORT verify "$AOF_EVERY_STATE" everysec 512 \
    >>$TMPDIR/gate-aof-everysec.txt 2>&1 \
    && grep -q "AOF warning: truncated AOF tail" "$SRVLOG" \
    && ok "AOF everysec durability window + tail warning" \
    || bad "AOF everysec durability window + tail warning" "see $TMPDIR/gate-aof-everysec.txt"
stop

AOF_NO_DIR=$(mktemp -d "$TMPDIR/gate-aof-no-sync-${NET_IO}.XXXXXX")
boot "$CANDIDATE_BINARY" --protected-mode no --atomic 0 --appendonly yes --appendfsync no \
    --net-io "$NET_IO" --dir "$AOF_NO_DIR" \
    || bad "AOF no-sync purpose boot ($NET_IO)"
row_begin "AOF no-sync bypassed sync + reply gate"
py tests/aof_fsync.py 127.0.0.1 $PORT populate "$AOF_NO_DIR/state.json" no 128 \
    >$TMPDIR/gate-aof-no-sync.txt 2>&1 \
    && ok "AOF no-sync bypassed sync + reply gate" \
    || bad "AOF no-sync bypass" "see $TMPDIR/gate-aof-no-sync.txt"
stop

quiet_wait
row_begin "AOF rewrite atomic/stage/corruption matrix"
NET_IO=$NET_IO GATE_PORT=$PORT GATE_CORES=$CORES tests/aof_rewrite_matrix.sh \
    >$TMPDIR/gate-aof-rewrite.txt 2>&1 \
    && ok "AOF rewrite atomic/stage/corruption matrix" \
    || bad "AOF rewrite matrix" "see $TMPDIR/gate-aof-rewrite.txt"

quiet_wait
row_begin "AOF rewrite triggers + observability matrix"
NET_IO=$NET_IO GATE_PORT=$PORT GATE_CORES=$CORES tests/aof_rewrite_trigger_matrix.sh \
    >$TMPDIR/gate-aof-rewrite-trigger.txt 2>&1 \
    && ok "AOF rewrite triggers + observability matrix" \
    || bad "AOF rewrite triggers" "see $TMPDIR/gate-aof-rewrite-trigger.txt"

AOF_OFF_DIR=$(mktemp -d "$TMPDIR/gate-aof-off-${NET_IO}.XXXXXX")
boot "$CANDIDATE_BINARY" --protected-mode no --net-io "$NET_IO" \
    --appendonly no --dir "$AOF_OFF_DIR" \
    || bad "AOF-off negative-control boot"
row_begin "AOF-off negative-control seed landed"
AOF_OFF_SEED=$(redis-cli -h 127.0.0.1 -p $PORT SET aof-negative-control must-disappear 2>&1 |
    tr -d '\r')
AOF_OFF_PRE_SIZE=$(redis-cli -h 127.0.0.1 -p $PORT DBSIZE 2>/dev/null | tr -d '\r')
[ "$AOF_OFF_SEED" = OK ] && [ "$AOF_OFF_PRE_SIZE" = 1 ] \
    && ok "AOF-off negative-control seed landed" \
    || bad "AOF-off negative-control seed" "SET=$AOF_OFF_SEED DBSIZE=$AOF_OFF_PRE_SIZE"
kill -KILL $SRV 2>/dev/null
wait $SRV 2>/dev/null
settle
boot "$CANDIDATE_BINARY" --protected-mode no --net-io "$NET_IO" \
    --appendonly no --dir "$AOF_OFF_DIR" \
    || bad "AOF-off negative-control reboot"
row_begin "AOF-off negative control lost data"
AOF_OFF_SIZE=$(redis-cli -h 127.0.0.1 -p $PORT DBSIZE 2>/dev/null | tr -d '\r')
[ "$AOF_OFF_SIZE" = 0 ] && [ ! -e "$AOF_OFF_DIR/appendonlydir" ] \
    && ok "AOF-off negative control lost data" || bad "AOF-off negative control"
stop

# All child boots below own the job's PORT only after the historical AOF server
# is reaped. Keeping these in job_aof also serializes its persistence row timings.
for AOFFIX_MODE in 1s 2s; do
  for AOFFIX_CASE in snapshot filename error tickets exec_tickets resurrection rewrite_fail2 manifest_missing; do
    row_begin "aoffix2 $AOFFIX_CASE ($AOFFIX_MODE, $NET_IO)"
    quiet_wait
    if python3 tests/aoffix2.py "$AOFFIX_CASE" --binary "$CANDIDATE_BINARY" \
        --mode "$AOFFIX_MODE" --engine "$NET_IO" --cores "$CORES" --ratio "$GATE_RATIO" \
        --port "$PORT" --artifacts "$TMPDIR/aoffix2-$AOFFIX_CASE-$AOFFIX_MODE-$NET_IO" \
        >"$TMPDIR/aoffix2-$AOFFIX_CASE-$AOFFIX_MODE-$NET_IO.log" 2>&1; then
      ok "aoffix2 $AOFFIX_CASE ($AOFFIX_MODE, $NET_IO)"
    else
      bad "aoffix2 $AOFFIX_CASE ($AOFFIX_MODE, $NET_IO)" \
          "see $TMPDIR/aoffix2-$AOFFIX_CASE-$AOFFIX_MODE-$NET_IO.log"
    fi
  done
  for AOFFIX_POLICY in everysec always; do
    row_begin "aoffix2 off-writer acknowledgement $AOFFIX_POLICY ($AOFFIX_MODE, $NET_IO)"
    quiet_wait
    if python3 tests/aoffix2.py latency --binary "$CANDIDATE_BINARY" \
        --mode "$AOFFIX_MODE" --engine "$NET_IO" --policy "$AOFFIX_POLICY" \
        --cores "$CORES" --ratio "$GATE_RATIO" --port "$PORT" \
        --artifacts "$TMPDIR/aoffix2-latency-$AOFFIX_POLICY-$AOFFIX_MODE-$NET_IO" \
        >"$TMPDIR/aoffix2-latency-$AOFFIX_POLICY-$AOFFIX_MODE-$NET_IO.log" 2>&1; then
      ok "aoffix2 off-writer acknowledgement $AOFFIX_POLICY ($AOFFIX_MODE, $NET_IO)"
    else
      bad "aoffix2 off-writer acknowledgement $AOFFIX_POLICY ($AOFFIX_MODE, $NET_IO)" \
          "see $TMPDIR/aoffix2-latency-$AOFFIX_POLICY-$AOFFIX_MODE-$NET_IO.log"
    fi
  done
done
for AOFFIX_LARGE_CASE in large large_placed; do
row_begin "aoffix2 $AOFFIX_LARGE_CASE (1s, $NET_IO)"
quiet_wait
if python3 tests/aoffix2.py "$AOFFIX_LARGE_CASE" --binary "$CANDIDATE_BINARY" \
    --mode 1s --engine "$NET_IO" --cores "$CORES" --port "$PORT" \
    --artifacts "$TMPDIR/aoffix2-$AOFFIX_LARGE_CASE-$NET_IO" \
    >"$TMPDIR/aoffix2-$AOFFIX_LARGE_CASE-$NET_IO.log" 2>&1; then
  ok "aoffix2 $AOFFIX_LARGE_CASE (1s, $NET_IO)"
else
  bad "aoffix2 $AOFFIX_LARGE_CASE (1s, $NET_IO)" \
      "see $TMPDIR/aoffix2-$AOFFIX_LARGE_CASE-$NET_IO.log"
fi
done
}

job_aof_frame(){
# ---- AOF physical framing: a control frame must never land inside a large record --------------
# A gate run's AOF replay boot exited with "AOF control record interleaves a large record": the
# writer flushed a ready GCMT at the top of a writer pass without checking that a large record
# still held the physical stream. Recovery truncates the file from that large record's first byte,
# so a control frame inside it is discardable -- and the loader refuses to start on the whole file.
# Syscall persistence under epoll is where the defect was demonstrated. The existing rewrite
# pause now queues a complete group before LargeBegin on the last producer; the record exceeds
# both writer budgets. Stable owners and connection placement keep that schedule deterministic.
for AOF_FRAME_ATOMIC in 0 1; do
AOF_FRAME_DIR=$(mktemp -d "$TMPDIR/gate-aof-frameorder-atomic${AOF_FRAME_ATOMIC}.XXXXXX")
boot "$CANDIDATE_BINARY" --protected-mode no --atomic "$AOF_FRAME_ATOMIC" --appendonly yes \
    --appendfsync no --net-io epoll --auto-aof-rewrite-percentage 0 \
    --aof-timestamp-enabled no --key-lb 0 --client-lb 0 --flip-auto 0 \
    --enable-debug-command yes --dir "$AOF_FRAME_DIR" \
    || bad "AOF frame-order purpose boot (atomic $AOF_FRAME_ATOMIC)"
row_begin "AOF control frame never inside a large record (atomic $AOF_FRAME_ATOMIC)"
unit_ready persistfix-units \
    && taskset -c "$CORES" ./build/persistfix-unit frameorder \
    >$TMPDIR/gate-aof-frameorder-$AOF_FRAME_ATOMIC.txt 2>&1 \
    && py tests/aof_frame_order_test.py >>$TMPDIR/gate-aof-frameorder-$AOF_FRAME_ATOMIC.txt 2>&1 \
    && py tests/aof_frame_order.py 127.0.0.1 $PORT "$AOF_FRAME_DIR/appendonlydir" \
    >>$TMPDIR/gate-aof-frameorder-$AOF_FRAME_ATOMIC.txt 2>&1 \
    && ok "AOF control frame never inside a large record (atomic $AOF_FRAME_ATOMIC)" \
    || bad "AOF control frame never inside a large record (atomic $AOF_FRAME_ATOMIC)" \
           "see $TMPDIR/gate-aof-frameorder-$AOF_FRAME_ATOMIC.txt"
stop
done
}

job_tls(){
# ---- TLS: independent listener, auth matrix, KeyUpdate, parser/teardown fences ----------------
TLS_PORT=$((PORT+1))
TLS_DIR=$(mktemp -d $TMPDIR/gate-tls.XXXXXX)
row_begin "TLS ephemeral CA/server/client certificates"
py tests/tls.py --generate "$TLS_DIR" >$TMPDIR/gate-tls-generate.txt 2>&1 \
    && ok "TLS ephemeral CA/server/client certificates" \
    || bad "TLS certificate generation" "see $TMPDIR/gate-tls-generate.txt"

row_begin "NET2 serverless RX policy and KeyUpdate controls"
if [ -f "$RUN_DIR/unit-ready/ktls-keyupdate-unit" ] && (
  for arm in rx-policy tls12 userspace tx-rekey tx-failure; do
    taskset -c "$CORES" build/ktls-keyupdate-unit "$TLS_DIR" "$arm" || exit 1
  done
) >$TMPDIR/gate-ktls-unit.txt 2>&1; then
  ok "NET2 serverless RX policy and KeyUpdate controls"
else
  bad "NET2 serverless RX policy and KeyUpdate controls" "see $TMPDIR/gate-ktls-unit.txt"
fi

row_begin "reject TLS listener without certificate"
reject_boot --port 0 --tls-port "$TLS_PORT" --tls-key-file "$TLS_DIR/server.key" \
    --tls-auth-clients no 2>&1 | grep -q "tls-port requires tls-cert-file" \
    && ok "reject TLS listener without certificate" || bad "reject missing TLS certificate"
row_begin "reject invalid tls-protocols"
reject_boot --port 0 --tls-port "$TLS_PORT" --tls-cert-file "$TLS_DIR/server.crt" \
    --tls-key-file "$TLS_DIR/server.key" --tls-auth-clients no --tls-protocols SSLv3 \
    2>&1 | grep -q "Invalid tls-protocols" \
    && ok "reject invalid tls-protocols" || bad "reject invalid tls-protocols"
row_begin "reject invalid tls-ciphers"
reject_boot --port 0 --tls-port "$TLS_PORT" --tls-cert-file "$TLS_DIR/server.crt" \
    --tls-key-file "$TLS_DIR/server.key" --tls-auth-clients no --tls-ciphers NOT-A-CIPHER \
    2>&1 | grep -q "Failed to configure tls-ciphers" \
    && ok "reject invalid tls-ciphers" || bad "reject invalid tls-ciphers"

tlsboot(){ # auth-mode [extra TLS knobs]
  local auth=$1; shift
  quiet_wait
  SRV=0; SRVLOG=/dev/null
  guard_port "$PORT"
  guard_port "$TLS_PORT"
  SRVLOG=$(mktemp $TMPDIR/gate-tls-srv.XXXXXX)
  taskset -c $CORES "$CANDIDATE_BINARY" --port "$PORT" --tls-port "$TLS_PORT" \
      --bind 127.0.0.1 --shards 16 --ratio "$GATE_RATIO" --protected-mode no --dir "$TLS_DIR" --save '' \
      --tls-cert-file "$TLS_DIR/server.crt" --tls-key-file "$TLS_DIR/server.key" \
      --tls-ca-cert-file "$TLS_DIR/ca.crt" --tls-auth-clients "$auth" "$@" \
      >"$SRVLOG" 2>&1 &
  SRV=$!
  for _ in $(seq 50); do
    if ! kill -0 "$SRV" 2>/dev/null; then wait "$SRV" 2>/dev/null; return 1; fi
    if (exec 3<>/dev/tcp/127.0.0.1/$PORT) 2>/dev/null && \
       (exec 4<>/dev/tcp/127.0.0.1/$TLS_PORT) 2>/dev/null; then return 0; fi
    sleep 0.2
  done
  return 1
}

tlsboot yes || bad "TLS client-auth yes purpose boot"
row_begin "TLS client-auth yes matrix"
py tests/tls.py 127.0.0.1 "$TLS_PORT" "$TLS_DIR" yes --plain-port "$PORT" \
    >$TMPDIR/gate-tls-yes.txt 2>&1 \
    && ok "TLS client-auth yes matrix" || bad "TLS client-auth yes matrix" "see $TMPDIR/gate-tls-yes.txt"
stop
row_begin "TLS yes shutdown invariants"
shutdown_clean \
    && ok "TLS yes shutdown invariants" || bad "TLS yes shutdown invariants"
# (tls_ktls_active is a GAUGE — 0 at clean shutdown by design — so kTLS engagement is asserted
# live below, on the optional-mode boot, not from this shutdown dump.)

tlsboot optional || bad "TLS client-auth optional purpose boot"
row_begin "TLS client-auth optional matrix"
py tests/tls.py 127.0.0.1 "$TLS_PORT" "$TLS_DIR" optional --plain-port "$PORT" \
    >$TMPDIR/gate-tls-optional.txt 2>&1 \
    && ok "TLS client-auth optional matrix" \
    || bad "TLS client-auth optional matrix" "see $TMPDIR/gate-tls-optional.txt"
# Live TLS 1.2 kTLS engagement proof on the default boot: a TLS 1.2 client connects and
# must see itself counted in the active gauge. Client-auth 'optional' permits a cert-less client.
row_begin "kTLS TLS 1.2 engaged live (default boot)"
python3 - "$TLS_PORT" "$TLS_DIR" <<'PYEOF' >$TMPDIR/gate-ktls-live.txt 2>&1 \
    && ok "kTLS TLS 1.2 engaged live (default boot)" || bad "kTLS engaged live" "see $TMPDIR/gate-ktls-live.txt"
import socket, ssl, sys
port, certdir = int(sys.argv[1]), sys.argv[2]
ctx = ssl.create_default_context(cafile=f"{certdir}/ca.crt")
ctx.check_hostname = False
ctx.minimum_version = ctx.maximum_version = ssl.TLSVersion.TLSv1_2
s = ctx.wrap_socket(socket.create_connection(("127.0.0.1", port), timeout=5))
s.sendall(b"INFO STATS\r\n")
with s.makefile("rb") as wire:
    header = wire.readline()
    assert header.startswith(b"$") and header.endswith(b"\r\n"), header
    size = int(header[1:-2])
    assert size >= 0, header
    body = wire.read(size)
    assert len(body) == size and wire.read(2) == b"\r\n", "truncated INFO bulk reply"
    d = body.decode(errors="replace")
line = [l for l in d.split("\r\n") if l.startswith("tls_ktls_active:")]
assert line, "no tls_ktls_active in INFO STATS: " + d[:200]
assert int(line[0].split(":")[1]) >= 1, "kTLS did not engage: " + line[0]
print("KTLS_LIVE_OK", line[0])
s.close()
PYEOF
row_begin "TLS 1.3 KeyUpdate survives (NET2)"
[ -f "$RUN_DIR/unit-ready/ktls-keyupdate" ] && \
  taskset -c "$CORES" build/ktls-keyupdate 127.0.0.1 "$TLS_PORT" tx \
    >$TMPDIR/gate-ktls-keyupdate.txt 2>&1 \
    && ok "TLS 1.3 KeyUpdate survives (NET2)" \
    || bad "TLS 1.3 KeyUpdate survives (NET2)" "see $TMPDIR/gate-ktls-keyupdate.txt"
row_begin "TLS 1.3 userspace KeyUpdate survives (NET2)"
[ -f "$RUN_DIR/unit-ready/ktls-keyupdate" ] && \
  taskset -c "$CORES" build/ktls-keyupdate 127.0.0.1 "$TLS_PORT" userspace \
    >$TMPDIR/gate-ktls-keyupdate-userspace.txt 2>&1 \
    && ok "TLS 1.3 userspace KeyUpdate survives (NET2)" \
    || bad "TLS 1.3 userspace KeyUpdate survives (NET2)" "see $TMPDIR/gate-ktls-keyupdate-userspace.txt"
stop
row_begin "TLS optional shutdown invariants"
shutdown_clean \
    && ok "TLS optional shutdown invariants" || bad "TLS optional shutdown invariants"

# Exercise userspace fallback through the retained cipher grammar. TLS 1.2 uses CBC; TLS 1.3
# retains OpenSSL RX for every cipher. Counters must fire.
tlsboot no --tls-protocols "TLSv1.2 TLSv1.3" --tls-ciphers ECDHE-RSA-AES256-SHA384 \
    --tls-ciphersuites TLS_AES_256_GCM_SHA384 --tls-prefer-server-ciphers yes \
    || bad "TLS coexistence purpose boot"
row_begin "TLS pipeline/torn-record/coexistence battery"
py tests/tls.py 127.0.0.1 "$TLS_PORT" "$TLS_DIR" no --plain-port "$PORT" --full \
    --expect-ktls no >$TMPDIR/gate-tls-full.txt 2>&1 \
    && ok "TLS pipeline/torn-record/coexistence battery" \
    || bad "TLS correctness battery" "see $TMPDIR/gate-tls-full.txt"
stop
row_begin "TLS shutdown invariants"
shutdown_clean \
    && ok "TLS shutdown invariants" || bad "TLS shutdown invariants"
row_begin "TLS application send path error-free"
[ "$(shutdown_value wb.send_errors)" = 0 ] \
    && ok "TLS application send path error-free" || bad "TLS send errors"
row_begin "TLS connection slots all freed (N/N)"
TLS_ACCEPTS=$(shutdown_value tls.accepts)
TLS_FREED=$(shutdown_value tls.connections_freed)
TLS_ZC=$(shutdown_value tls.zc_suppressed)
[ -n "$TLS_ACCEPTS" ] && [ "$TLS_ACCEPTS" -gt 0 ] && [ "$TLS_ACCEPTS" = "$TLS_FREED" ] \
    && ok "TLS connection slots all freed ($TLS_FREED/$TLS_ACCEPTS)" \
    || bad "TLS connection-slot cleanup" "$TLS_FREED/$TLS_ACCEPTS"
row_begin "TLS zc borrow gates fired (suppressed=$TLS_ZC)"
[ -n "$TLS_ZC" ] && [ "$TLS_ZC" -gt 0 ] \
    && ok "TLS zc borrow gates fired (suppressed=$TLS_ZC)" || bad "TLS zc borrow gates fired"
}

job_feature_cell(){
  local FEATURE_CELL=${1#feature-cell-}
  row_begin "feature $FEATURE_CELL"
  py tests/feature_gate.py --cell "$FEATURE_CELL" --binary "$CANDIDATE_BINARY" \
        --server-cpus "$CORES" --load-cpus "${GATE_LOAD_CORES:-96-127}" --ratio "$GATE_RATIO" \
        --port "$PORT" --output "$FEATURE_OUTPUT" \
        >"$FEATURE_OUTPUT/$FEATURE_CELL.log" 2>&1 \
        && ok "feature $FEATURE_CELL" \
        || bad "feature $FEATURE_CELL" "see $FEATURE_OUTPUT/$FEATURE_CELL.log"
}

job_abba_selftest(){
# The ABBA tier's own decision logic, saturation rules and rejection paths, exercised serverless so
# a broken comparator is caught on any machine and before any measurement is trusted.
# The suite rejects live candidate probes even in a warm worktree; executable fixtures and an
# explicit missing-candidate control keep this row independent of the concurrent release build.
# Owned-server teardown must retain its drain/identity witnesses too: a success followed by
# unfinished connection cleanup is failed evidence, including in the parallel feature cells.
# Calibrated inputs must also reject changed shapes and forged completion evidence before
# ABBA consumes a floor; keep those controls inside this existing instrument row.
# Quiet controls prove selected-core activity and occupied intended ports can refuse a
# run, while activity outside the allocation cannot invalidate its measurement receipt.
# The actual scheduler controls also run on every gate: a premature performance start,
# partial completion publication or leaked child invalidates every later measurement.
# This expanded row has its own timing context; pre-scheduler samples measured less work.
row_begin "ABBA comparison + saturation negative controls" "with-scheduler-controls"
py tests/abbagate.py --self-test > $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && py tests/gate_quiet.py --self-test >> $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && py tests/gate_measurements.py --self-test >> $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && py tests/gate_receipt.py --self-test >> $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && py tests/abba_instrument.py --self-test >> $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && py tests/background_environment_test.py >> $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && py tests/gate_history.py self-test >> $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && py tests/gate_process_test.py >> $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && py tests/gates_test.py >> $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && py tests/gate_subset_test.py >> $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && py tests/wb_policy.py --self-test >> $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && py tests/lb_stationary.py --self-test >> $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && py tests/netio.py --self-test >> $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && py tests/gateprod.py --self-test >> $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && py tests/tailgen_stall.py --self-test >> $TMPDIR/gate-abbagate-unit.txt 2>&1 \
    && ok "ABBA comparison + saturation negative controls" \
    || bad "ABBA comparison + saturation negative controls" "see $TMPDIR/gate-abbagate-unit.txt"
}

job_asan_batteries(){
# ---- 4. full tier: torture under ASAN ---------------------------------------------------------
boot $ASAN --atomic 1 --enable-debug-command yes || bad "ASAN boot"
row_begin "torture under ASAN"
py tests/torture.py 127.0.0.1 $PORT >$TMPDIR/gate-tort-asan.txt 2>&1 \
    && ok "torture under ASAN" || bad "torture under ASAN"
row_begin "RYOW under ASAN"
py tests/ryow.py 127.0.0.1 $PORT >$TMPDIR/gate-ryow-asan.txt 2>&1 \
    && ok "RYOW under ASAN" || bad "RYOW under ASAN"
# Deliberately omit --release-build: coverage/safety checks remain mandatory, including the
# derived-window witnesses; promotion timing prints without scoring its release budget.
row_begin "atomic torn/window under ASAN"
py tests/atomic_torn.py 127.0.0.1 $PORT >$TMPDIR/gate-atomic-torn-asan.txt 2>&1 \
    && ok "atomic torn/window under ASAN" || bad "atomic torn/window under ASAN"
# --no-rate-assertions: the battery's overlap section makes one claim about SPEED (pipelining 24
# atomic groups beats 24 serial round trips by >10%). ASAN does not slow the two arms by the same
# factor, so that ratio inverts here on a correct build -- measured pipe 21,005/s vs serial
# 24,202/s in a full-gate run whose every correctness check passed, on a build that passed 4 of 4
# standalone. The mechanism half of the same section (all 24 admitted, multiple groups observed in flight,
# so a younger cross-key group WAS in flight while an older one decided) still runs on this tier,
# and the measured rates are still printed in the log.
row_begin "atomic RYOW under ASAN"
py tests/atomic_ryow.py 127.0.0.1 $PORT --no-rate-assertions \
    >$TMPDIR/gate-atomic-ryow-asan.txt 2>&1 \
    && ok "atomic RYOW under ASAN" || bad "atomic RYOW under ASAN"
stop
# "No ASAN report" is a finding only if the ASAN server actually ran to its shutdown dump; an
# empty log (boot failed) has no ASAN text either and used to pass this row vacuously.
row_begin "ASAN clean"
if grep -q "ERROR: AddressSanitizer" "$SRVLOG"; then bad "ASAN clean" "see $SRVLOG"
elif shutdown_present; then ok "ASAN clean"
else bad "ASAN clean" "ASAN server never reached its shutdown dump; see $SRVLOG"; fi
}

job_replyoff(){
# ---- CLIENT REPLY OFF/SKIP + cross-shard MGET on a zero-copy boot: suppressed replies leave nothing on the
# wire and release their borrows (regression for the partial-array leak fixed on the netwb lane) ------------
for RA in 0 1; do
  boot "$CANDIDATE_BINARY" --shards 64 --zc-min 64 --atomic $RA --enable-debug-command yes || bad "replyoff boot (atomic $RA)"
  row_begin "CLIENT REPLY OFF/SKIP cross-shard MGET wire silence (atomic $RA)"
  py tests/replyoff_xshard.py 127.0.0.1 $PORT >$TMPDIR/gate-replyoff-$RA.txt 2>&1 \
      && ok "CLIENT REPLY OFF/SKIP cross-shard MGET wire silence (atomic $RA)" \
      || bad "CLIENT REPLY OFF/SKIP cross-shard MGET wire silence (atomic $RA)" "see $TMPDIR/gate-replyoff-$RA.txt"
  stop
done
}

job_zc(){
# ---- 4b. full tier: zero-copy borrow lifetime (release+ASAN) ----------------------------------
zcboot(){
  quiet_wait
  tools/quietcheck.sh "${GATE_CORES:-192-199}" "$PORT" 2>$TMPDIR/gate-quiet.err || {
    sleep 3
    tools/quietcheck.sh "${GATE_CORES:-192-199}" "$PORT" 2>>$TMPDIR/gate-quiet.err || {
      echo "boot preflight: cores/port not quiet: $(tail -1 $TMPDIR/gate-quiet.err)"; return 1; }
  }
  SRV=0; SRVLOG=/dev/null
  guard_port "$PORT"
  SRVLOG=$(mktemp $TMPDIR/gate-srv-zc.XXXXXX)
  taskset -c $CORES "$1" --port $PORT --bind 127.0.0.1 --shards 16 --ratio $GATE_RATIO \
      --dir "$(mktemp -d "$TMPDIR/zc-data.XXXXXX")" --save '' --zc-min 16384 > "$SRVLOG" 2>&1 &
  SRV=$!
  for _ in $(seq 50); do
    if ! kill -0 "$SRV" 2>/dev/null; then wait "$SRV" 2>/dev/null; return 1; fi
    (exec 3<>/dev/tcp/127.0.0.1/$PORT) 2>/dev/null && return 0; sleep 0.2; done
  return 1
}
zcboot "$CANDIDATE_BINARY" || bad "zc boot"
row_begin "zc borrow battery"
py tests/zc.py 127.0.0.1 $PORT >$TMPDIR/gate-zc.txt 2>&1     && ok "zc borrow battery" || bad "zc borrow battery" "see $TMPDIR/gate-zc.txt"
stop
row_begin "zc fired (zc_sends=N)"
ZS=$(shutdown_value wb.zc_sends)
[ -n "$ZS" ] && [ "$ZS" -gt 0 ] && ok "zc fired (zc_sends=$ZS)" || bad "zc fired"
zcboot $ASAN || bad "zc ASAN boot"
row_begin "zc borrow battery under ASAN"
py tests/zc.py 127.0.0.1 $PORT >$TMPDIR/gate-zc-asan.txt 2>&1     && ok "zc borrow battery under ASAN" || bad "zc borrow battery under ASAN"
stop
row_begin "zc ASAN clean"
if grep -q "ERROR: AddressSanitizer" "$SRVLOG"; then bad "zc ASAN clean" "see $SRVLOG"
elif shutdown_present; then ok "zc ASAN clean"
else bad "zc ASAN clean" "ASAN server never reached its shutdown dump; see $SRVLOG"; fi
}

job_rldbg(){
# ---- 4b-bis. full tier: the armed-write block cache's ownership laws ---------------------------
# THE ROW THAT WOULD HAVE CAUGHT THE P0 (DESIGN-P0REPLY.md). A shard's read-local retire sink names
# two structures belonging to ONE thread and protected by nothing else: the owner's single-producer
# QSBR retire ring and the owner's unlocked block-cache free list. When a shard changed owner the
# sink was rebound lazily, on the destination's own later executor pass, so for a window the new
# owner wrote through the old owner's ring and free list -- and the damage surfaced far away, as
# either KvBlockCache::put's abort or a wild free-list head in an unrelated SET.
#
# Nothing in the gate could see it. The differential matrix compares REPLIES; it never rewrites one
# key often enough to cycle a block through put -> grace -> take, and its key distribution is flat
# enough that the load balancer moves no shards at all. So this row supplies both missing halves:
# a debug build that states the ownership laws as assertions, and traffic that forces shard moves.
row_begin "read-local ownership-invariant build"
pausable taskset -c "$BUILD_CORES" tests/parbuild.sh $RLDBG "$PWD/build/gate-cache/obj-rlcachedbg" \
    "-std=c++20 -O2 -g -march=native -pthread -DTOMO_JEMALLOC -DTOMO_RL_CACHE_DEBUG -I." \
    "-ljemalloc -luring -pthread -lssl -lcrypto -lm" \
    src/main.cc src/net/tls.cc src/core/*.cc src/cmd/*.cc src/snapshot/*.cc src/persist/*.cc 2>$TMPDIR/gate-rlcachedbg-build.txt \
    && ok "read-local ownership-invariant build" \
    || bad "read-local ownership-invariant build" "see $TMPDIR/gate-rlcachedbg-build.txt"
}

job_rlcache(){
quiet_wait
# More shards than workers permit ownership movement. The automatic balancer must move shards;
# the battery's existing positive-movement assertion remains mandatory under the derived policy.
if boot_fused $RLDBG --shards 64 --atomic 1 --read-local 1 --enable-debug-command yes; then
  # The battery carries its own three non-vacuity checks: the armed lane served reads, the block
  # cache actually held blocks, and -- the precondition for this whole class of defect -- the load
  # balancer MOVED shards during the run.
  row_begin "armed block-cache churn battery"
  py tests/rlcache_churn.py 127.0.0.1 $PORT "${GATE_RLCACHE_SECONDS:-25}" 48 \
      >$TMPDIR/gate-rlcache-churn.txt 2>&1 \
      && ok "armed block-cache churn battery" \
      || bad "armed block-cache churn battery" "see $TMPDIR/gate-rlcache-churn.txt"
  stop
  row_begin "read-local ownership invariants"
  if grep -q 'RLSINK-VIOLATION\|RLCACHE-VIOLATION\|RLRING-VIOLATION' "$SRVLOG"; then
    bad "read-local ownership invariants" "see $SRVLOG"
  elif shutdown_present; then
    ok "read-local ownership invariants"
  else
    bad "read-local ownership invariants" "server never reached its shutdown dump; see $SRVLOG"
  fi
else
  bad "armed block-cache churn battery" "boot failed; see $SRVLOG"
  bad "read-local ownership invariants" "boot failed"
fi
}

job_globcase(){
# ---- 4d. full tier: glob / scan-cursor grammar parity -----------------------------------------
# The differential matrix above generates COMMANDS, so it only reaches the glob patterns its
# generators happen to emit. This row drives the specific patterns where the five former glob copies
# disagreed with redis -- case sensitivity, [!x], reversed and high-bit ranges, unterminated classes
# -- plus the cursor and ACL LOG count grammars. It carries its own negative control: the ACL rows
# are permission-WIDENING checks, which every allow-path test passes by construction.
GLOBCASE_ORACLE_PORT=${GATE_GLOBCASE_ORACLE_PORT:-$((PORT+2))}
if boot "$CANDIDATE_BINARY"; then
  taskset -c ${GATE_DIFFER_ORACLE_CORES:-$CORES} \
      "${GATE_DIFFER_ORACLE_BIN:-$REDIS74_ROOT/src/redis-server}" \
      --port "$GLOBCASE_ORACLE_PORT" --bind 127.0.0.1 --save '' --appendonly no --dir "$(mktemp -d "$TMPDIR/glob-data.XXXXXX")" \
      >$TMPDIR/gate-globcase-oracle.txt 2>&1 &
  GLOBCASE_ORACLE=$!
  for _ in $(seq 60); do
    (exec 3<>/dev/tcp/127.0.0.1/$GLOBCASE_ORACLE_PORT) 2>/dev/null && break; sleep 0.25
  done
  row_begin "glob/scan grammar parity vs Redis 7.4"
  py tests/globcase.py 127.0.0.1 "$PORT" 127.0.0.1 "$GLOBCASE_ORACLE_PORT" \
      >$TMPDIR/gate-globcase.txt 2>&1 \
      && ok "glob/scan grammar parity vs Redis 7.4" \
      || bad "glob/scan grammar parity vs Redis 7.4" "see $TMPDIR/gate-globcase.txt"
  kill -TERM $GLOBCASE_ORACLE 2>/dev/null; wait $GLOBCASE_ORACLE 2>/dev/null; GLOBCASE_ORACLE=0
  stop
else
  bad "glob/scan grammar parity vs Redis 7.4" "target boot failed"
fi
}

# TSan complements the existing ASAN/UBSAN controls; neither replaces the other's assertions.
# All core dependencies are instrumented in an isolated cache. Linking release objects here
# would leave command/owner accesses invisible, while sharing the ASAN cache would mix runtimes.
# One compile mode across every TU also gives inline test hooks identical definitions everywhere.
# These builds own no ledger row: the existing seven core rows and waits row require both runs.
job_core_tsan_build(){
  # Match the core unit's Makefile dependencies: reorder's fused boot selector
  # references run_fused_server in genthread.cc even in this serverless binary.
  local source sources=()
  for source in src/net/tls.cc src/core/*.cc src/cmd/*.cc src/snapshot/*.cc src/persist/*.cc; do
    # Match Makefile's SERVER_ONLY_SRC exclusion; this binary has its own main.
    [ "$source" = src/core/version.cc ] || sources+=("$source")
  done
  mkdir -p "$RUN_DIR/unit-ready"
  pausable taskset -c "$BUILD_CORES" tests/parbuild.sh "$CORE_TSAN" \
      "$PWD/build/gate-cache/obj-core-tsan" \
      '-std=c++20 -O1 -g -march=native -pthread -fsanitize=thread -fno-omit-frame-pointer -no-pie -DTOMO_CORE_CONCURRENCY_TEST -I.' \
      '-luring -pthread -lssl -lcrypto -lm' tests/core_concurrency_unit.cc "${sources[@]}" \
      >"$TMPDIR/build.log" 2>&1 && : > "$RUN_DIR/unit-ready/core-concurrency-tsan"
}
job_waits_tsan_build(){
  mkdir -p "$RUN_DIR/unit-ready"
  pausable taskset -c "$BUILD_CORES" tests/parbuild.sh "$WAITS_TSAN" \
      "$PWD/build/gate-cache/obj-waits-tsan" \
      '-std=c++20 -O1 -g -march=native -pthread -fsanitize=thread -fno-omit-frame-pointer -no-pie -I.' \
      '-pthread' tests/waits_unit.cc >"$TMPDIR/build.log" 2>&1 \
      && : > "$RUN_DIR/unit-ready/waits-unit-tsan"
}
tsan_unit(){
  local binary=$1 ready=$2 witness=$3 rc log
  shift 3
  log="$TMPDIR/tsan-$ready${1:+-$1}.log"
  [ -f "$RUN_DIR/unit-ready/$ready" ] || {
    echo "TSAN FAIL: $ready build did not complete; see $RUN_DIR/jobs/*tsan_build/build.log" >&2
    return 1
  }
  # Match the existing storage-TSAN address-map workaround, and keep all runtime reports fatal.
  # Do not inherit caller suppression options. A platform/runtime failure is a red row, never skip.
  # Existing fixture arming assertions, waits alarm and core interleaving bounds are unchanged.
  TSAN_OPTIONS=halt_on_error=1:exitcode=66 timeout --foreground 60 \
      setarch x86_64 -R taskset -c "$CORES" "$binary" "$@" >"$log" 2>&1
  rc=$?
  if [ "$rc" -ne 0 ] || grep -q 'ThreadSanitizer' "$log" || ! grep -Fxq "$witness" "$log"; then
    echo "TSAN FAIL: $ready ${*:-} exit=$rc; runtime report, unavailable runtime, or missing state witness; see $log" >&2
    return 1
  fi
}

# SV4.9 uses a fully instrumented server, with its own object cache and readiness
# marker, just like core_tsan_build/waits_tsan_build. Build failure is a red row.
job_racefix_tsan_build(){
  mkdir -p "$RUN_DIR/unit-ready"
  pausable taskset -c "$BUILD_CORES" make -j"$BUILD_JOBS" tsan \
      >"$TMPDIR/build.log" 2>&1 && : > "$RUN_DIR/unit-ready/racefix-tsan"
}
job_racefix_counters(){
  local mode failed=0
  row_begin "INFO command/socket counters (TSan, both modes)"
  if unit_ready racefix-tsan; then
    for mode in 2s 1s; do
      py tests/racefix.py counters --binary build/tomokv-tsan --mode "$mode" \
          --cores "$CORES" --port "$PORT" --output "$TMPDIR/counters-$mode" \
          >"$TMPDIR/counters-$mode.log" 2>&1 || failed=1
    done
  else failed=1; fi
  if [ "$failed" = 0 ]; then ok "INFO command/socket counters (TSan, both modes)"
  else bad "INFO command/socket counters (TSan, both modes)" "see $TMPDIR/counters-*.log"; fi
}
job_racefix_climon(){
  local mode control failed=0
  row_begin "Climon armed refresh + stale-store suppression control"
  if unit_ready racefix-climon; then
    for mode in 2s 1s; do
      for control in store suppress; do
        local args=()
        [ "$control" != suppress ] || args+=(--suppress-stale)
        py tests/racefix.py climon --binary build/racefix-climon --mode "$mode" \
            --cores "$CORES" --port "$PORT" --output "$TMPDIR/climon-$mode-$control" \
            "${args[@]}" >"$TMPDIR/climon-$mode-$control.log" 2>&1 || failed=1
      done
    done
  else failed=1; fi
  if [ "$failed" = 0 ]; then ok "Climon armed refresh + stale-store suppression control"
  else bad "Climon armed refresh + stale-store suppression control" "see $TMPDIR/climon-*.log"; fi
}

job_tailgen_build(){
  mkdir -p "$RUN_DIR/unit-ready"
  pausable taskset -c "$BUILD_CORES" make -j"$BUILD_JOBS" build/tailgen \
      >"$TMPDIR/build.log" 2>&1 && : > "$RUN_DIR/unit-ready/tailgen"
}

job_production_units(){
  local target
  mkdir -p "$RUN_DIR/unit-ready"
  pausable taskset -c "$BUILD_CORES" make -k -j"$BUILD_JOBS" \
      build/at15-unit build/at15-db0-unit build/execabort-watch-unit build/execabort-watch-db0-unit build/core-concurrency-unit build/atomic-survivors-unit build/netcmd-unit build/encodingfix-unit build/netcap-unit \
      build/waits-unit build/rehash-waits-unit build/multidb-unit build/multidb-boundary-unit build/storesize-unit \
      build/exbatch-unit build/exbatch-db0-unit build/wb-rule-units build/wbland-units build/rltopo-unit build/lbplanner-units build/shutdown-unit build/persistfix-units build/ktls-keyupdate build/ktls-keyupdate-unit build/flushfix-units build/splitlocal-unit build/reorder-engagement-unit build/reorder-engagement-unit-db0 build/racefix-climon >"$TMPDIR/build.log" 2>&1
  # -q verifies prerequisites as well as output existence: a failed compile cannot reuse a stale
  # executable. Each dependent historical row owns the failure; this helper adds no gate row.
  for target in at15-unit at15-db0-unit execabort-watch-unit execabort-watch-db0-unit core-concurrency-unit atomic-survivors-unit netcmd-unit encodingfix-unit netcap-unit waits-unit rehash-waits-unit multidb-unit multidb-boundary-unit storesize-unit wb-rule-units wbland-units rltopo-unit lbplanner-units shutdown-unit persistfix-units exbatch-unit exbatch-db0-unit ktls-keyupdate ktls-keyupdate-unit flushfix-units splitlocal-unit reorder-engagement-unit reorder-engagement-unit-db0 racefix-climon; do
    make -q "build/$target" && : > "$RUN_DIR/unit-ready/$target"
  done
  pausable taskset -c "$BUILD_CORES" make -j"$BUILD_JOBS" mdbqsbr-live-arms \
      >"$TMPDIR/mdbqsbr-live-build.log" 2>&1 && : > "$RUN_DIR/unit-ready/mdbqsbr-live-arms"
  return 0
}
job_multidb(){
  local prefix mode read_local atomic label booted=0 live_ok=0
  IFS=- read -r prefix mode read_local atomic <<< "$1"
  label="multidb ($mode, read-local $read_local, atomic $atomic)"
  row_begin "$label"
  # This existing row now includes fresh parked/load/BLPOP boots and their wake
  # controls before the historical busy + serial-order pair. No new ledger row.
  if unit_ready mdbqsbr-live-arms && py tests/mdbqsbr_live.py \
      --binary "$CANDIDATE_BINARY" --parked-binary build/mdbqsbr2-park/tomokv \
      --no-wake-binary build/mdbqsbr2-no-wake/tomokv --mode "$mode" \
      --read-local "$read_local" --atomic "$atomic" --cores "$CORES" --port "$PORT" \
      --output "$TMPDIR/mdbqsbr-live" >"$TMPDIR/mdbqsbr-live.log" 2>&1; then live_ok=1; fi
  local boot_fn=boot
  [ "$mode" != 1s ] || boot_fn=boot_fused
  if "$boot_fn" "$CANDIDATE_BINARY" --atomic "$atomic" --read-local "$read_local" \
        --databases 16 --enable-debug-command yes --appendonly yes --appendfsync no --save '' && booted=1 &&
      py tests/multidb.py 127.0.0.1 "$PORT" --read-local "$read_local" --persistence \
        >"$TMPDIR/multidb.log" 2>&1 && [ "$live_ok" = 1 ]; then
    ok "$label"
  else
    bad "$label" "see $TMPDIR/mdbqsbr-live.log, $TMPDIR/multidb.log and $SRVLOG"
  fi
  row_begin "$label SWAPDB serial order"
  if [ "$booted" = 1 ] && py tests/multidb_serial.py 127.0.0.1 "$PORT" \
        --output "$TMPDIR/multidb-serial-epochs.json" >"$TMPDIR/multidb-serial.log" 2>&1; then
    ok "$label SWAPDB serial order"
  else
    bad "$label SWAPDB serial order" "see $TMPDIR/multidb-serial.log and $SRVLOG"
  fi
  stop
  row_begin "$label XREAD wake after SWAPDB"
  # Fresh map: the sole swap must leave logical DB 0 on physical namespace 1.
  if "$boot_fn" "$CANDIDATE_BINARY" --atomic "$atomic" --read-local "$read_local" \
        --databases 16 --save '' &&
      py tests/aclkeys_wake_state.py 127.0.0.1 "$PORT" \
        >"$TMPDIR/aclkeys-wake-state.log" 2>&1; then
    ok "$label XREAD wake after SWAPDB"
  else
    bad "$label XREAD wake after SWAPDB" "see $TMPDIR/aclkeys-wake-state.log and $SRVLOG"
  fi
  stop
}
unit_ready(){
  [ -f "$RUN_DIR/unit-ready/$1" ] || {
    echo "unit $1 did not build; see $RUN_DIR/jobs/production_units/build.log" >&2
    return 1
  }
}

job_dependencies(){
  local dependency
  case "$1" in
    atomic_batteries)
      # A measured 3 ms scheduling pause alone flips atomic_ryow's unchanged 24-command
      # rate assertion. Preserve the entire boot/battery chain and every assertion, but
      # finish all other gate-owned correctness work before this performance check boots.
      # JOB_NAMES is complete before dispatch and no other family depends on this one.
      if [ "${GATE_PARTIAL:-0}" = 1 ]; then echo release; return; fi
      for dependency in "${JOB_NAMES[@]}"; do
        [ "$dependency" = atomic_batteries ] || printf '%s\n' "$dependency"
      done;;
    release|asan|rldbg|core_tsan_build|waits_tsan_build|racefix_tsan_build|tailgen_build|config_unit|flip_unit|filter_unit|ring_unit|storage_units|acl_metadata|cmd_metadata|abba_selftest|reorder_sync) ;;
    core_units|flipfix_units) echo 'production_units core_tsan_build';;
    racefix_counters) echo racefix_tsan_build;;
    racefix_climon) echo production_units;;
    tls) echo 'release production_units';;
    wait_units) echo 'production_units waits_tsan_build';;
    debug-*|aof_frame) echo 'release production_units';;
    lbplanner_units|climonfix|persistfix_units|exbatch_units|wb_rule_units|wbland_units|splitlocal_units|atomic_units|netcmd_units|multidb-*|wb_policy|reorder_engagement) echo production_units;;
    asan_batteries) echo asan;;
    zc) echo 'release asan';;
    rlcache) echo rldbg;;
    *) echo release;;
  esac
}
job_ready(){
  local dependency
  for dependency in $(job_dependencies "$1"); do
    [ -f "$RUN_DIR/jobs/$dependency/done" ] || return 1
  done
  return 0
}


trap stop_workers EXIT

job_body(){
  local current=$1 dependency affinity=
  if [ "$current" = "$FAILED_JOB" ] && [ "$FAILURE_BEHAVIOR" = before-affinity ]; then
    echo 'deliberate fixture failure before affinity witness' >&2
    return 17
  fi

  local affinity_pid=$BASHPID affinity_reply affinity_prefix
  if ! affinity_reply=$(LC_ALL=C taskset -pc "$affinity_pid"); then
    echo 'fixture affinity query failed' >&2
    exit 22
  fi
  affinity_prefix="pid $affinity_pid's current affinity list: "
  if [[ "$affinity_reply" != "$affinity_prefix"* ]]; then
    printf 'fixture affinity query malformed: %s\n' "$affinity_reply" >&2
    exit 22
  fi
  affinity=${affinity_reply#"$affinity_prefix"}
  [ "$affinity" = "$LOAD_CORES" ] || {
    echo "fixture slot affinity differs: $affinity/$LOAD_CORES" >&2
    exit 22
  }

  printf '%s	%s
' "$slot" "$affinity" > "$TMPDIR/fixture-affinity"
  : > "$RUN_DIR/started/$current"
  if ! job_ready "$current"; then echo "started $current before dependency completed" >&2; exit 18; fi
  if [ "$current" = atomic_batteries ]; then
    # This is the first operation of the unchanged production family: before its boot,
    # every other family must have published completion AFTER its owned-process cleanup.
    for dependency in "${JOB_NAMES[@]}"; do
      [ "$dependency" != "$current" ] || continue
      if [ ! -f "$RUN_DIR/jobs/$dependency/done" ] ||
          [ ! -f "$RUN_DIR/jobs/$dependency/cleaned" ]; then
        printf 'atomic boot preceded completion of %s
' "$dependency" > "$RUN_DIR/exclusivity-failure"
        cat "$RUN_DIR/exclusivity-failure" >&2
        exit 19
      fi
    done
    : > "$RUN_DIR/atomic-boot-reached"
  fi
  case "$current" in
    production_units|core_tsan_build|waits_tsan_build|racefix_tsan_build|tailgen_build)
      : > "$RUN_DIR/completed/$current"
      return 0;;
  esac
  if [ "$DEPENDENCY_PROBE" = 1 ]; then
    if [ "$current" = release ]; then
      while [ ! -f "$RUN_DIR/started/asan" ]; do pause; done
    elif [ "$current" = asan ]; then
      # The old fixture released ASAN at correctness START, then asserted correctness
      # COMPLETION preceded ASAN. Both legitimate completion orders were possible.
      # Hold ASAN until the post-verdict token, and prove the production readiness
      # predicate admits release correctness while this ASAN job is still unfinished.
      while [ ! -f "$RUN_DIR/jobs/release/done" ]; do pause; done
      : > "$RUN_DIR/dependency-probe-reached"
      if ! job_ready release_batteries; then
        printf 'release correctness blocked by unfinished ASAN\n' > "$RUN_DIR/dependency-failure"
        cat "$RUN_DIR/dependency-failure" >&2
        exit 23
      fi
      while [ ! -f "$RUN_DIR/completed/release_batteries" ]; do pause; done
      [ ! -f "$TMPDIR/done" ] || exit 24
      : > "$RUN_DIR/dependency-handshake"
    fi
  fi
  if [ "$GATE_SLOTS" != 1 ] && [ "$FORCE_ORDER" = 1 ]; then
    for dependency in "${CANONICAL[@]}"; do
      [ "$dependency" != atomic_batteries ] || continue
      while [ ! -f "$RUN_DIR/started/$dependency" ]; do pause; done
    done
  fi
  if [ "$GATE_SLOTS" != 1 ] && [ "$FORCE_ORDER" = 1 ] && [ "$current" != atomic_batteries ]; then
    # A single predecessor token enforces the same total order transitively. Polling
    # every unfinished predecessor from 97 shells consumed the fixture's 45s budget
    # on one CPU (retained controls reached 92--94 families before timeout).
    if [ "$current" != "${COMPLETION_ORDER[0]}" ]; then
      read -r dependency < "$RUN_DIR/order/$current" || exit 20
      [ "$dependency" = completed ] || exit 21
    fi
  fi
  row_begin "$(job_label "$current")"
  if [ "$current" = "$FAILED_JOB" ] && [ "$FAILURE_BEHAVIOR" = crash ]; then exit 17; fi
  if [ "$current" = "$FAILED_JOB" ] && [ "$FAILURE_BEHAVIOR" = red ]; then
    bad "$(job_label "$current")" 'deliberately broken mechanism'
  elif [ "$current" != "$FAILED_JOB" ] || [ "$FAILURE_BEHAVIOR" != empty ]; then
    ok "$(job_label "$current")"
  fi
  printf '%s\n' "$current" >> "$RUN_DIR/completion-order"
  : > "$RUN_DIR/completed/$current"
  if [ "$GATE_SLOTS" != 1 ] && [ "$FORCE_ORDER" = 1 ] && [ "$current" != atomic_batteries ]; then
    local found=0
    for dependency in "${COMPLETION_ORDER[@]}"; do
      [ "$dependency" != atomic_batteries ] || break
      if [ "$found" = 1 ]; then
        printf 'completed\n' > "$RUN_DIR/order/$dependency"
        break
      fi
      [ "$dependency" != "$current" ] || found=1
    done
  fi
  if [ "$current" = "$FAILED_JOB" ] && [ "$FAILURE_BEHAVIOR" = return ]; then return 17; fi
  return 0
}
# Completion-order probes remove ordinary dependency edges but retain real atomic exclusivity.
# The separate two-slot probe exercises the complete graph. A negative control removes ONLY
# the new edge, proving the pre-boot assertion catches a dispatch overlap on the actual queue.
if [ "$FORCE_ORDER" = 1 ] || [ "$REMOVE_ATOMIC_DEPENDENCY" = 1 ]; then
  original_dependencies=$(declare -f job_dependencies)
  eval "${original_dependencies/job_dependencies/real_job_dependencies}"
  job_dependencies(){
    if [ "$1" = atomic_batteries ]; then
      if [ "$REMOVE_ATOMIC_DEPENDENCY" = 1 ]; then echo release
      else real_job_dependencies "$1"; fi
    elif [ "$FORCE_ORDER" != 1 ]; then real_job_dependencies "$1"
    fi
  }
fi
# Poison only the release-correctness edge. The held ASAN job calls the real
# readiness predicate above, emits an explicit failed row, then finalizes so
# the queue can drain. The negative control never depends on a sleep or deadlock.
if [ "$ADD_ASAN_DEPENDENCY" = 1 ]; then
  original_dependencies=$(declare -f job_dependencies)
  eval "${original_dependencies/job_dependencies/unpoisoned_job_dependencies}"
  job_dependencies(){
    unpoisoned_job_dependencies "$1"
    [ "$1" != release_batteries ] || echo asan
  }
fi
mkdir "$RUN_DIR/order"
for requested in "${CANONICAL[@]}"; do mkfifo "$RUN_DIR/order/$requested"; done
start_workers
for requested in "${CANONICAL[@]}"; do collect_job "$requested"; done
join_workers
printf '%s %s\n' "$PASS" "$FAIL" > "$RUN_DIR/counts"
