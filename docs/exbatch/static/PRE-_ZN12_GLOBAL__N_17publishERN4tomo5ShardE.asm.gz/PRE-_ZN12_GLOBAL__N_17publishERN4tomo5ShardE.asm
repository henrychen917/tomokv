
build/exbatch/PRE/unit:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

000000000002d210 <_ZN12_GLOBAL__N_17publishERN4tomo5ShardE>:
   2d210:	8b 87 8c 01 00 00    	mov    0x18c(%rdi),%eax
   2d216:	03 87 88 01 00 00    	add    0x188(%rdi),%eax
   2d21c:	89 47 1c             	mov    %eax,0x1c(%rdi)
   2d21f:	48 8b 47 38          	mov    0x38(%rdi),%rax
   2d223:	48 03 87 a0 01 00 00 	add    0x1a0(%rdi),%rax
   2d22a:	48 89 47 20          	mov    %rax,0x20(%rdi)
   2d22e:	8b 87 54 02 00 00    	mov    0x254(%rdi),%eax
   2d234:	03 87 50 02 00 00    	add    0x250(%rdi),%eax
   2d23a:	89 47 28             	mov    %eax,0x28(%rdi)
   2d23d:	48 8b 87 08 04 00 00 	mov    0x408(%rdi),%rax
   2d244:	48 89 47 30          	mov    %rax,0x30(%rdi)
   2d248:	c3                   	ret

Disassembly of section .rlfence:

Disassembly of section .fini:
