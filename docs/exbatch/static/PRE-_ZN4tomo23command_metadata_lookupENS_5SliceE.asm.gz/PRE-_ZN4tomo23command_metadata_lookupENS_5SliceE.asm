
build/exbatch/PRE/unit:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

000000000033ea30 <_ZN4tomo23command_metadata_lookupENS_5SliceE>:
  33ea30:	f3 0f 1e fa          	endbr64
  33ea34:	41 55                	push   %r13
  33ea36:	41 54                	push   %r12
  33ea38:	55                   	push   %rbp
  33ea39:	49 89 fc             	mov    %rdi,%r12
  33ea3c:	53                   	push   %rbx
  33ea3d:	48 8d 1d 9c 50 0c 00 	lea    0xc509c(%rip),%rbx        # 403ae0 <_ZN4tomo12_GLOBAL__N_1L18kGeneratedMetadataE>
  33ea44:	89 f5                	mov    %esi,%ebp
  33ea46:	48 83 ec 08          	sub    $0x8,%rsp
  33ea4a:	4c 8d ab 20 46 00 00 	lea    0x4620(%rbx),%r13
  33ea51:	eb 16                	jmp    33ea69 <_ZN4tomo23command_metadata_lookupENS_5SliceE+0x39>
  33ea53:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  33ea5e:	66 90                	xchg   %ax,%ax
  33ea60:	48 83 c3 30          	add    $0x30,%rbx
  33ea64:	4c 39 eb             	cmp    %r13,%rbx
  33ea67:	74 1f                	je     33ea88 <_ZN4tomo23command_metadata_lookupENS_5SliceE+0x58>
  33ea69:	48 8b 13             	mov    (%rbx),%rdx
  33ea6c:	89 ee                	mov    %ebp,%esi
  33ea6e:	4c 89 e7             	mov    %r12,%rdi
  33ea71:	e8 da f7 ff ff       	call   33e250 <_ZN4tomo12_GLOBAL__N_117ascii_equal_icaseENS_5SliceEPKc.isra.0>
  33ea76:	84 c0                	test   %al,%al
  33ea78:	74 e6                	je     33ea60 <_ZN4tomo23command_metadata_lookupENS_5SliceE+0x30>
  33ea7a:	48 83 c4 08          	add    $0x8,%rsp
  33ea7e:	48 89 d8             	mov    %rbx,%rax
  33ea81:	5b                   	pop    %rbx
  33ea82:	5d                   	pop    %rbp
  33ea83:	41 5c                	pop    %r12
  33ea85:	41 5d                	pop    %r13
  33ea87:	c3                   	ret
  33ea88:	48 83 c4 08          	add    $0x8,%rsp
  33ea8c:	31 db                	xor    %ebx,%ebx
  33ea8e:	48 89 d8             	mov    %rbx,%rax
  33ea91:	5b                   	pop    %rbx
  33ea92:	5d                   	pop    %rbp
  33ea93:	41 5c                	pop    %r12
  33ea95:	41 5d                	pop    %r13
  33ea97:	c3                   	ret

Disassembly of section .rlfence:

Disassembly of section .fini:
