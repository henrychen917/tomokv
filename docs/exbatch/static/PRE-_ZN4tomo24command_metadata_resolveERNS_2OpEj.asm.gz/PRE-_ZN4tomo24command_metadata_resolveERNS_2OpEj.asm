
build/exbatch/PRE/unit:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

0000000000340490 <_ZN4tomo24command_metadata_resolveERNS_2OpEj>:
  340490:	f3 0f 1e fa          	endbr64
  340494:	41 57                	push   %r15
  340496:	41 56                	push   %r14
  340498:	41 55                	push   %r13
  34049a:	41 54                	push   %r12
  34049c:	55                   	push   %rbp
  34049d:	53                   	push   %rbx
  34049e:	48 83 ec 58          	sub    $0x58,%rsp
  3404a2:	89 74 24 0c          	mov    %esi,0xc(%rsp)
  3404a6:	64 48 8b 04 25 28 00 00 00 	mov    %fs:0x28,%rax
  3404af:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  3404b4:	8b 87 cc 00 00 00    	mov    0xcc(%rdi),%eax
  3404ba:	89 04 24             	mov    %eax,(%rsp)
  3404bd:	39 c6                	cmp    %eax,%esi
  3404bf:	0f 83 4b 02 00 00    	jae    340710 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x280>
  3404c5:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
  3404cc:	49 89 ff             	mov    %rdi,%r15
  3404cf:	89 f2                	mov    %esi,%edx
  3404d1:	48 85 c0             	test   %rax,%rax
  3404d4:	0f 84 e6 01 00 00    	je     3406c0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x230>
  3404da:	48 c1 e2 04          	shl    $0x4,%rdx
  3404de:	48 01 d0             	add    %rdx,%rax
  3404e1:	48 8d 2d f8 35 0c 00 	lea    0xc35f8(%rip),%rbp        # 403ae0 <_ZN4tomo12_GLOBAL__N_1L18kGeneratedMetadataE>
  3404e8:	4c 8b 30             	mov    (%rax),%r14
  3404eb:	44 8b 68 08          	mov    0x8(%rax),%r13d
  3404ef:	4c 8d a5 20 46 00 00 	lea    0x4620(%rbp),%r12
  3404f6:	48 89 eb             	mov    %rbp,%rbx
  3404f9:	eb 12                	jmp    34050d <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x7d>
  3404fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  340500:	48 83 c3 30          	add    $0x30,%rbx
  340504:	4c 39 e3             	cmp    %r12,%rbx
  340507:	0f 84 0a 02 00 00    	je     340717 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x287>
  34050d:	48 8b 13             	mov    (%rbx),%rdx
  340510:	44 89 ee             	mov    %r13d,%esi
  340513:	4c 89 f7             	mov    %r14,%rdi
  340516:	e8 35 dd ff ff       	call   33e250 <_ZN4tomo12_GLOBAL__N_117ascii_equal_icaseENS_5SliceEPKc.isra.0>
  34051b:	84 c0                	test   %al,%al
  34051d:	74 e1                	je     340500 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x70>
  34051f:	8b 44 24 0c          	mov    0xc(%rsp),%eax
  340523:	8b 0c 24             	mov    (%rsp),%ecx
  340526:	ff c0                	inc    %eax
  340528:	89 44 24 0c          	mov    %eax,0xc(%rsp)
  34052c:	39 c8                	cmp    %ecx,%eax
  34052e:	72 30                	jb     340560 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0xd0>
  340530:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  340535:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  34053e:	0f 85 7e 03 00 00    	jne    3408c2 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x432>
  340544:	48 83 c4 58          	add    $0x58,%rsp
  340548:	48 89 d8             	mov    %rbx,%rax
  34054b:	5b                   	pop    %rbx
  34054c:	5d                   	pop    %rbp
  34054d:	41 5c                	pop    %r12
  34054f:	41 5d                	pop    %r13
  340551:	41 5e                	pop    %r14
  340553:	41 5f                	pop    %r15
  340555:	c3                   	ret
  340556:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
  340560:	44 89 ea             	mov    %r13d,%edx
  340563:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
  340568:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  34056d:	4d 85 f6             	test   %r14,%r14
  340570:	75 09                	jne    34057b <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0xeb>
  340572:	48 85 d2             	test   %rdx,%rdx
  340575:	0f 85 4c 03 00 00    	jne    3408c7 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x437>
  34057b:	48 83 fa 0f          	cmp    $0xf,%rdx
  34057f:	0f 87 4c 01 00 00    	ja     3406d1 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x241>
  340585:	48 83 fa 01          	cmp    $0x1,%rdx
  340589:	0f 84 c3 01 00 00    	je     340752 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x2c2>
  34058f:	48 85 d2             	test   %rdx,%rdx
  340592:	0f 85 22 03 00 00    	jne    3408ba <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x42a>
  340598:	4c 89 e8             	mov    %r13,%rax
  34059b:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  3405a0:	c6 04 10 00          	movb   $0x0,(%rax,%rdx,1)
  3405a4:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  3405a9:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  3405ae:	4c 8d 70 01          	lea    0x1(%rax),%r14
  3405b2:	48 89 04 24          	mov    %rax,(%rsp)
  3405b6:	4c 39 e9             	cmp    %r13,%rcx
  3405b9:	0f 84 4d 02 00 00    	je     34080c <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x37c>
  3405bf:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  3405c4:	4c 39 f0             	cmp    %r14,%rax
  3405c7:	0f 82 c0 01 00 00    	jb     34078d <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x2fd>
  3405cd:	48 8b 04 24          	mov    (%rsp),%rax
  3405d1:	c6 04 01 7c          	movb   $0x7c,(%rcx,%rax,1)
  3405d5:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  3405da:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  3405df:	42 c6 04 30 00       	movb   $0x0,(%rax,%r14,1)
  3405e4:	49 8b 97 c0 00 00 00 	mov    0xc0(%r15),%rdx
  3405eb:	8b 44 24 0c          	mov    0xc(%rsp),%eax
  3405ef:	48 85 d2             	test   %rdx,%rdx
  3405f2:	0f 84 85 01 00 00    	je     34077d <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x2ed>
  3405f8:	48 c1 e0 04          	shl    $0x4,%rax
  3405fc:	4c 8d 3c 02          	lea    (%rdx,%rax,1),%r15
  340600:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  340605:	45 8b 47 08          	mov    0x8(%r15),%r8d
  340609:	48 b8 ff ff ff ff ff ff ff 7f 	movabs $0x7fffffffffffffff,%rax
  340613:	49 8b 0f             	mov    (%r15),%rcx
  340616:	48 29 f0             	sub    %rsi,%rax
  340619:	4c 39 c0             	cmp    %r8,%rax
  34061c:	0f 82 c1 02 00 00    	jb     3408e3 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x453>
  340622:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  340627:	4d 8d 34 30          	lea    (%r8,%rsi,1),%r14
  34062b:	4c 39 e8             	cmp    %r13,%rax
  34062e:	0f 84 5b 02 00 00    	je     34088f <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x3ff>
  340634:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  340639:	4c 39 f2             	cmp    %r14,%rdx
  34063c:	0f 82 1d 01 00 00    	jb     34075f <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x2cf>
  340642:	4d 85 c0             	test   %r8,%r8
  340645:	74 1e                	je     340665 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x1d5>
  340647:	48 8d 3c 30          	lea    (%rax,%rsi,1),%rdi
  34064b:	49 83 f8 01          	cmp    $0x1,%r8
  34064f:	0f 84 4b 02 00 00    	je     3408a0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x410>
  340655:	4c 89 c2             	mov    %r8,%rdx
  340658:	48 89 ce             	mov    %rcx,%rsi
  34065b:	e8 00 2d cd ff       	call   13360 <memcpy@plt>
  340660:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  340665:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  34066a:	42 c6 04 30 00       	movb   $0x0,(%rax,%r14,1)
  34066f:	44 8b 7c 24 28       	mov    0x28(%rsp),%r15d
  340674:	4c 8b 74 24 20       	mov    0x20(%rsp),%r14
  340679:	eb 12                	jmp    34068d <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x1fd>
  34067b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  340680:	48 83 c5 30          	add    $0x30,%rbp
  340684:	4c 39 e5             	cmp    %r12,%rbp
  340687:	0f 84 91 00 00 00    	je     34071e <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x28e>
  34068d:	48 8b 55 00          	mov    0x0(%rbp),%rdx
  340691:	44 89 fe             	mov    %r15d,%esi
  340694:	4c 89 f7             	mov    %r14,%rdi
  340697:	e8 b4 db ff ff       	call   33e250 <_ZN4tomo12_GLOBAL__N_117ascii_equal_icaseENS_5SliceEPKc.isra.0>
  34069c:	84 c0                	test   %al,%al
  34069e:	74 e0                	je     340680 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x1f0>
  3406a0:	4d 39 ee             	cmp    %r13,%r14
  3406a3:	74 11                	je     3406b6 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x226>
  3406a5:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  3406aa:	4c 89 f7             	mov    %r14,%rdi
  3406ad:	48 8d 70 01          	lea    0x1(%rax),%rsi
  3406b1:	e8 da de ce ff       	call   2e590 <_ZdlPvm>
  3406b6:	48 89 eb             	mov    %rbp,%rbx
  3406b9:	e9 72 fe ff ff       	jmp    340530 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0xa0>
  3406be:	66 90                	xchg   %ax,%ax
  3406c0:	48 83 c2 0d          	add    $0xd,%rdx
  3406c4:	48 c1 e2 04          	shl    $0x4,%rdx
  3406c8:	48 8d 04 17          	lea    (%rdi,%rdx,1),%rax
  3406cc:	e9 10 fe ff ff       	jmp    3404e1 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x51>
  3406d1:	48 8d 7a 01          	lea    0x1(%rdx),%rdi
  3406d5:	48 89 14 24          	mov    %rdx,(%rsp)
  3406d9:	e8 22 dd ce ff       	call   2e400 <_Znwm>
  3406de:	48 8b 14 24          	mov    (%rsp),%rdx
  3406e2:	48 89 c7             	mov    %rax,%rdi
  3406e5:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  3406ea:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  3406ef:	4c 89 f6             	mov    %r14,%rsi
  3406f2:	48 89 14 24          	mov    %rdx,(%rsp)
  3406f6:	e8 65 2c cd ff       	call   13360 <memcpy@plt>
  3406fb:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  340700:	48 8b 14 24          	mov    (%rsp),%rdx
  340704:	e9 92 fe ff ff       	jmp    34059b <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x10b>
  340709:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  340710:	31 db                	xor    %ebx,%ebx
  340712:	e9 19 fe ff ff       	jmp    340530 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0xa0>
  340717:	31 db                	xor    %ebx,%ebx
  340719:	e9 01 fe ff ff       	jmp    34051f <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x8f>
  34071e:	48 85 db             	test   %rbx,%rbx
  340721:	74 10                	je     340733 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x2a3>
  340723:	48 89 df             	mov    %rbx,%rdi
  340726:	e8 a5 db ff ff       	call   33e2d0 <_ZN4tomo12_GLOBAL__N_111child_countERKNS_15CommandMetadataE>
  34072b:	85 c0                	test   %eax,%eax
  34072d:	0f 85 66 01 00 00    	jne    340899 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x409>
  340733:	4d 39 ee             	cmp    %r13,%r14
  340736:	0f 84 f4 fd ff ff    	je     340530 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0xa0>
  34073c:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  340741:	4c 89 f7             	mov    %r14,%rdi
  340744:	48 8d 70 01          	lea    0x1(%rax),%rsi
  340748:	e8 43 de ce ff       	call   2e590 <_ZdlPvm>
  34074d:	e9 de fd ff ff       	jmp    340530 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0xa0>
  340752:	41 0f b6 06          	movzbl (%r14),%eax
  340756:	88 44 24 30          	mov    %al,0x30(%rsp)
  34075a:	e9 39 fe ff ff       	jmp    340598 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x108>
  34075f:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
  340764:	31 d2                	xor    %edx,%edx
  340766:	48 89 c7             	mov    %rax,%rdi
  340769:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  34076e:	e8 5d 97 cf ff       	call   39ed0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm>
  340773:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  340778:	e9 e8 fe ff ff       	jmp    340665 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x1d5>
  34077d:	48 83 c0 0d          	add    $0xd,%rax
  340781:	48 c1 e0 04          	shl    $0x4,%rax
  340785:	49 01 c7             	add    %rax,%r15
  340788:	e9 73 fe ff ff       	jmp    340600 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x170>
  34078d:	4d 85 f6             	test   %r14,%r14
  340790:	0f 88 73 01 00 00    	js     340909 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x479>
  340796:	48 01 c0             	add    %rax,%rax
  340799:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  34079e:	49 39 c6             	cmp    %rax,%r14
  3407a1:	0f 82 bc 00 00 00    	jb     340863 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x3d3>
  3407a7:	48 8b 3c 24          	mov    (%rsp),%rdi
  3407ab:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
  3407b0:	48 83 c7 02          	add    $0x2,%rdi
  3407b4:	0f 88 b6 00 00 00    	js     340870 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x3e0>
  3407ba:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
  3407bf:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  3407c4:	e8 37 dc ce ff       	call   2e400 <_Znwm>
  3407c9:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
  3407ce:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
  3407d3:	48 89 c1             	mov    %rax,%rcx
  3407d6:	75 63                	jne    34083b <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x3ab>
  3407d8:	4d 39 e8             	cmp    %r13,%r8
  3407db:	74 1b                	je     3407f8 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x368>
  3407dd:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  3407e2:	4c 89 c7             	mov    %r8,%rdi
  3407e5:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  3407ea:	48 8d 70 01          	lea    0x1(%rax),%rsi
  3407ee:	e8 9d dd ce ff       	call   2e590 <_ZdlPvm>
  3407f3:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  3407f8:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  3407fd:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  340802:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  340807:	e9 c1 fd ff ff       	jmp    3405cd <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x13d>
  34080c:	49 83 fe 10          	cmp    $0x10,%r14
  340810:	0f 85 b7 fd ff ff    	jne    3405cd <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x13d>
  340816:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
  34081b:	bf 1f 00 00 00       	mov    $0x1f,%edi
  340820:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  340825:	e8 d6 db ce ff       	call   2e400 <_Znwm>
  34082a:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
  34082f:	48 89 c1             	mov    %rax,%rcx
  340832:	48 c7 44 24 18 1e 00 00 00 	movq   $0x1e,0x18(%rsp)
  34083b:	48 83 3c 24 01       	cmpq   $0x1,(%rsp)
  340840:	74 6d                	je     3408af <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x41f>
  340842:	48 8b 14 24          	mov    (%rsp),%rdx
  340846:	4c 89 c6             	mov    %r8,%rsi
  340849:	48 89 cf             	mov    %rcx,%rdi
  34084c:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
  340851:	e8 0a 2b cd ff       	call   13360 <memcpy@plt>
  340856:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  34085b:	48 89 c1             	mov    %rax,%rcx
  34085e:	e9 75 ff ff ff       	jmp    3407d8 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x348>
  340863:	48 8d 78 01          	lea    0x1(%rax),%rdi
  340867:	48 85 c0             	test   %rax,%rax
  34086a:	0f 89 4a ff ff ff    	jns    3407ba <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x32a>
  340870:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  340875:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  34087e:	75 42                	jne    3408c2 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x432>
  340880:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
  340885:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  34088a:	e8 11 2b cd ff       	call   133a0 <_ZSt17__throw_bad_allocv@plt>
  34088f:	ba 0f 00 00 00       	mov    $0xf,%edx
  340894:	e9 a0 fd ff ff       	jmp    340639 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x1a9>
  340899:	31 ed                	xor    %ebp,%ebp
  34089b:	e9 00 fe ff ff       	jmp    3406a0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x210>
  3408a0:	0f b6 01             	movzbl (%rcx),%eax
  3408a3:	88 07                	mov    %al,(%rdi)
  3408a5:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  3408aa:	e9 b6 fd ff ff       	jmp    340665 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x1d5>
  3408af:	41 0f b6 00          	movzbl (%r8),%eax
  3408b3:	88 01                	mov    %al,(%rcx)
  3408b5:	e9 1e ff ff ff       	jmp    3407d8 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x348>
  3408ba:	4c 89 ef             	mov    %r13,%rdi
  3408bd:	e9 2d fe ff ff       	jmp    3406ef <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x25f>
  3408c2:	e8 d9 2d cd ff       	call   136a0 <__stack_chk_fail@plt>
  3408c7:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  3408cc:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  3408d5:	75 eb                	jne    3408c2 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x432>
  3408d7:	48 8d 3d fa 1d 05 00 	lea    0x51dfa(%rip),%rdi        # 3926d8 <_IO_stdin_used+0x56d8>
  3408de:	e8 0d 2a cd ff       	call   132f0 <_ZSt19__throw_logic_errorPKc@plt>
  3408e3:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  3408e8:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  3408f1:	75 cf                	jne    3408c2 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x432>
  3408f3:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
  3408f8:	48 8d 3d d1 c7 04 00 	lea    0x4c7d1(%rip),%rdi        # 38d0d0 <_IO_stdin_used+0xd0>
  3408ff:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  340904:	e8 97 32 cd ff       	call   13ba0 <_ZSt20__throw_length_errorPKc@plt>
  340909:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  34090e:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  340917:	75 a9                	jne    3408c2 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x432>
  340919:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
  34091e:	48 8d 3d 7f c7 04 00 	lea    0x4c77f(%rip),%rdi        # 38d0a4 <_IO_stdin_used+0xa4>
  340925:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  34092a:	e8 71 32 cd ff       	call   13ba0 <_ZSt20__throw_length_errorPKc@plt>
  34092f:	f3 0f 1e fa          	endbr64
  340933:	48 89 c3             	mov    %rax,%rbx
  340936:	e9 86 64 ce ff       	jmp    26dc1 <_ZN4tomo24command_metadata_resolveERNS_2OpEj.cold>

Disassembly of section .rlfence:

Disassembly of section .fini:
