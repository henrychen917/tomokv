
build/exbatch/PRE/unit:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

00000000002733a0 <_ZN4tomo5Shard12publish_sizeEv>:
  2733a0:	f3 0f 1e fa          	endbr64
  2733a4:	8b 87 8c 01 00 00    	mov    0x18c(%rdi),%eax
  2733aa:	03 87 88 01 00 00    	add    0x188(%rdi),%eax
  2733b0:	89 47 1c             	mov    %eax,0x1c(%rdi)
  2733b3:	48 8b 47 38          	mov    0x38(%rdi),%rax
  2733b7:	48 03 87 a0 01 00 00 	add    0x1a0(%rdi),%rax
  2733be:	48 89 47 20          	mov    %rax,0x20(%rdi)
  2733c2:	8b 87 54 02 00 00    	mov    0x254(%rdi),%eax
  2733c8:	03 87 50 02 00 00    	add    0x250(%rdi),%eax
  2733ce:	89 47 28             	mov    %eax,0x28(%rdi)
  2733d1:	48 8b 87 08 04 00 00 	mov    0x408(%rdi),%rax
  2733d8:	48 89 47 30          	mov    %rax,0x30(%rdi)
  2733dc:	c3                   	ret

Disassembly of section .rlfence:

Disassembly of section .fini:
