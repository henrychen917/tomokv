
/home/user/Projects/cx-exbatch/build/exbatch/POST/tomokv:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

0000000000430080 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE>:
  430080:	f3 0f 1e fa          	endbr64
  430084:	55                   	push   %rbp
  430085:	48 89 e5             	mov    %rsp,%rbp
  430088:	41 57                	push   %r15
  43008a:	41 56                	push   %r14
  43008c:	41 55                	push   %r13
  43008e:	41 54                	push   %r12
  430090:	53                   	push   %rbx
  430091:	49 89 f4             	mov    %rsi,%r12
  430094:	48 89 fb             	mov    %rdi,%rbx
  430097:	48 83 ec 68          	sub    $0x68,%rsp
  43009b:	64 48 8b 04 25 28 00 00 00 	mov    %fs:0x28,%rax
  4300a4:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  4300a9:	48 8b 47 08          	mov    0x8(%rdi),%rax
  4300ad:	c6 44 24 20 00       	movb   $0x0,0x20(%rsp)
  4300b2:	48 c7 44 24 18 00 00 00 00 	movq   $0x0,0x18(%rsp)
  4300bb:	8b 00                	mov    (%rax),%eax
  4300bd:	48 05 ee 05 00 00    	add    $0x5ee,%rax
  4300c3:	48 c1 e0 06          	shl    $0x6,%rax
  4300c7:	48 03 07             	add    (%rdi),%rax
  4300ca:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  4300cf:	48 8b 10             	mov    (%rax),%rdx
  4300d2:	48 89 d1             	mov    %rdx,%rcx
  4300d5:	83 e1 01             	and    $0x1,%ecx
  4300d8:	48 89 ce             	mov    %rcx,%rsi
  4300db:	48 83 f6 01          	xor    $0x1,%rsi
  4300df:	40 88 74 24 20       	mov    %sil,0x20(%rsp)
  4300e4:	80 64 24 20 01       	andb   $0x1,0x20(%rsp)
  4300e9:	48 85 c9             	test   %rcx,%rcx
  4300ec:	0f 84 1e 02 00 00    	je     430310 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x290>
  4300f2:	49 63 44 24 10       	movslq 0x10(%r12),%rax
  4300f7:	85 c0                	test   %eax,%eax
  4300f9:	79 34                	jns    43012f <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xaf>
  4300fb:	49 8b 0c 24          	mov    (%r12),%rcx
  4300ff:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  430104:	48 85 c9             	test   %rcx,%rcx
  430107:	0f 84 83 00 00 00    	je     430190 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x110>
  43010d:	89 c2                	mov    %eax,%edx
  43010f:	83 e0 07             	and    $0x7,%eax
  430112:	c1 ea 03             	shr    $0x3,%edx
  430115:	83 e2 07             	and    $0x7,%edx
  430118:	48 69 c0 50 01 00 00 	imul   $0x150,%rax,%rax
  43011f:	48 03 84 d1 80 00 00 00 	add    0x80(%rcx,%rdx,8),%rax
  430127:	48 63 40 08          	movslq 0x8(%rax),%rax
  43012b:	85 c0                	test   %eax,%eax
  43012d:	78 61                	js     430190 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x110>
  43012f:	48 8b 13             	mov    (%rbx),%rdx
  430132:	48 05 6e 44 00 00    	add    $0x446e,%rax
  430138:	8b 14 82             	mov    (%rdx,%rax,4),%edx
  43013b:	48 8b 43 08          	mov    0x8(%rbx),%rax
  43013f:	3b 10                	cmp    (%rax),%edx
  430141:	74 4d                	je     430190 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x110>
  430143:	4c 89 e6             	mov    %r12,%rsi
  430146:	48 89 df             	mov    %rbx,%rdi
  430149:	e8 f2 52 ff ff       	call   425440 <_ZN4tomo7ExLoopTILb0EE19post_forwarded_taskILb0EEEbRKNS_4TaskEj>
  43014e:	84 c0                	test   %al,%al
  430150:	0f 84 1a 04 00 00    	je     430570 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4f0>
  430156:	41 be 01 00 00 00    	mov    $0x1,%r14d
  43015c:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
  430161:	0f 85 c9 01 00 00    	jne    430330 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x2b0>
  430167:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  43016c:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  430175:	0f 85 d9 0b 00 00    	jne    430d54 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xcd4>
  43017b:	48 83 c4 68          	add    $0x68,%rsp
  43017f:	44 89 f0             	mov    %r14d,%eax
  430182:	5b                   	pop    %rbx
  430183:	41 5c                	pop    %r12
  430185:	41 5d                	pop    %r13
  430187:	41 5e                	pop    %r14
  430189:	41 5f                	pop    %r15
  43018b:	5d                   	pop    %rbp
  43018c:	c3                   	ret
  43018d:	0f 1f 00             	nopl   (%rax)
  430190:	4c 89 e7             	mov    %r12,%rdi
  430193:	e8 48 49 07 00       	call   4a4ae0 <_ZN4tomo17multi_task_taggedERKNS_4TaskE>
  430198:	48 8b 0b             	mov    (%rbx),%rcx
  43019b:	89 c6                	mov    %eax,%esi
  43019d:	4d 63 74 24 10       	movslq 0x10(%r12),%r14
  4301a2:	0f b6 93 8a 01 00 00 	movzbl 0x18a(%rbx),%edx
  4301a9:	48 8b 83 58 01 00 00 	mov    0x158(%rbx),%rax
  4301b0:	48 8b 89 c8 03 01 00 	mov    0x103c8(%rcx),%rcx
  4301b7:	40 84 f6             	test   %sil,%sil
  4301ba:	0f 84 90 01 00 00    	je     430350 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x2d0>
  4301c0:	4e 8b 2c f1          	mov    (%rcx,%r14,8),%r13
  4301c4:	49 89 45 10          	mov    %rax,0x10(%r13)
  4301c8:	49 89 85 c0 01 00 00 	mov    %rax,0x1c0(%r13)
  4301cf:	41 88 95 c8 01 00 00 	mov    %dl,0x1c8(%r13)
  4301d6:	49 8b 04 24          	mov    (%r12),%rax
  4301da:	48 85 c0             	test   %rax,%rax
  4301dd:	0f 84 ad 03 00 00    	je     430590 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x510>
  4301e3:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
  4301e8:	48 8b bb 40 02 00 00 	mov    0x240(%rbx),%rdi
  4301ef:	45 8b 74 24 10       	mov    0x10(%r12),%r14d
  4301f4:	89 ca                	mov    %ecx,%edx
  4301f6:	c1 ea 03             	shr    $0x3,%edx
  4301f9:	83 e2 07             	and    $0x7,%edx
  4301fc:	48 8b 84 d0 80 00 00 00 	mov    0x80(%rax,%rdx,8),%rax
  430204:	48 39 bb 60 02 00 00 	cmp    %rdi,0x260(%rbx)
  43020b:	0f 85 5f 07 00 00    	jne    430970 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x8f0>
  430211:	48 8b bb e0 02 00 00 	mov    0x2e0(%rbx),%rdi
  430218:	48 39 bb 00 03 00 00 	cmp    %rdi,0x300(%rbx)
  43021f:	0f 85 4b 07 00 00    	jne    430970 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x8f0>
  430225:	49 8b 85 00 01 00 00 	mov    0x100(%r13),%rax
  43022c:	48 85 c0             	test   %rax,%rax
  43022f:	0f 84 4b 04 00 00    	je     430680 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x600>
  430235:	48 83 b8 10 02 00 00 00 	cmpq   $0x0,0x210(%rax)
  43023d:	0f 84 3d 04 00 00    	je     430680 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x600>
  430243:	49 8b 14 24          	mov    (%r12),%rdx
  430247:	8b 88 10 02 00 00    	mov    0x210(%rax),%ecx
  43024d:	4c 8b ba a8 07 00 00 	mov    0x7a8(%rdx),%r15
  430254:	85 c9                	test   %ecx,%ecx
  430256:	0f 84 e4 07 00 00    	je     430a40 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x9c0>
  43025c:	4c 89 fa             	mov    %r15,%rdx
  43025f:	48 b9 cd 8c 55 ed d7 af 51 ff 	movabs $0xff51afd7ed558ccd,%rcx
  430269:	48 c1 ea 21          	shr    $0x21,%rdx
  43026d:	4c 31 fa             	xor    %r15,%rdx
  430270:	48 0f af d1          	imul   %rcx,%rdx
  430274:	48 89 d1             	mov    %rdx,%rcx
  430277:	48 c1 e9 21          	shr    $0x21,%rcx
  43027b:	48 31 ca             	xor    %rcx,%rdx
  43027e:	48 b9 53 ec 85 1a fe b9 ce c4 	movabs $0xc4ceb9fe1a85ec53,%rcx
  430288:	48 0f af d1          	imul   %rcx,%rdx
  43028c:	48 89 d1             	mov    %rdx,%rcx
  43028f:	48 c1 e9 21          	shr    $0x21,%rcx
  430293:	48 31 ca             	xor    %rcx,%rdx
  430296:	83 e2 3f             	and    $0x3f,%edx
  430299:	4c 8b 74 d0 10       	mov    0x10(%rax,%rdx,8),%r14
  43029e:	4d 85 f6             	test   %r14,%r14
  4302a1:	75 1a                	jne    4302bd <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x23d>
  4302a3:	e9 d8 03 00 00       	jmp    430680 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x600>
  4302a8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  4302b0:	4d 8b 76 10          	mov    0x10(%r14),%r14
  4302b4:	4d 85 f6             	test   %r14,%r14
  4302b7:	0f 84 c3 03 00 00    	je     430680 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x600>
  4302bd:	49 8b 76 30          	mov    0x30(%r14),%rsi
  4302c1:	48 85 f6             	test   %rsi,%rsi
  4302c4:	74 ea                	je     4302b0 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x230>
  4302c6:	4d 3b 7e 50          	cmp    0x50(%r14),%r15
  4302ca:	75 e4                	jne    4302b0 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x230>
  4302cc:	4c 89 e7             	mov    %r12,%rdi
  4302cf:	e8 1c 48 07 00       	call   4a4af0 <_ZN4tomo21multi_task_owns_epochERKNS_4TaskEPKv>
  4302d4:	84 c0                	test   %al,%al
  4302d6:	75 d8                	jne    4302b0 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x230>
  4302d8:	49 8b 46 30          	mov    0x30(%r14),%rax
  4302dc:	48 8b 00             	mov    (%rax),%rax
  4302df:	48 85 c0             	test   %rax,%rax
  4302e2:	75 cc                	jne    4302b0 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x230>
  4302e4:	49 8b 46 40          	mov    0x40(%r14),%rax
  4302e8:	48 85 c0             	test   %rax,%rax
  4302eb:	74 07                	je     4302f4 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x274>
  4302ed:	0f b6 00             	movzbl (%rax),%eax
  4302f0:	84 c0                	test   %al,%al
  4302f2:	75 bc                	jne    4302b0 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x230>
  4302f4:	48 8d bb 30 02 00 00 	lea    0x230(%rbx),%rdi
  4302fb:	4c 89 e6             	mov    %r12,%rsi
  4302fe:	49 ff 85 58 04 00 00 	incq   0x458(%r13)
  430305:	e8 76 f7 ff ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  43030a:	e9 47 fe ff ff       	jmp    430156 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  43030f:	90                   	nop
  430310:	48 8d 4a 02          	lea    0x2(%rdx),%rcx
  430314:	48 ff c2             	inc    %rdx
  430317:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  43031c:	48 89 10             	mov    %rdx,(%rax)
  43031f:	e9 ce fd ff ff       	jmp    4300f2 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x72>
  430324:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  43032f:	90                   	nop
  430330:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  430335:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  43033a:	48 89 10             	mov    %rdx,(%rax)
  43033d:	e9 25 fe ff ff       	jmp    430167 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xe7>
  430342:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  43034d:	0f 1f 00             	nopl   (%rax)
  430350:	49 8b 3c 24          	mov    (%r12),%rdi
  430354:	48 85 ff             	test   %rdi,%rdi
  430357:	0f 84 63 04 00 00    	je     4307c0 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x740>
  43035d:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
  430362:	44 89 ee             	mov    %r13d,%esi
  430365:	41 83 e5 07          	and    $0x7,%r13d
  430369:	c1 ee 03             	shr    $0x3,%esi
  43036c:	83 e6 07             	and    $0x7,%esi
  43036f:	4d 69 ed 50 01 00 00 	imul   $0x150,%r13,%r13
  430376:	4c 03 ac f7 80 00 00 00 	add    0x80(%rdi,%rsi,8),%r13
  43037e:	45 85 f6             	test   %r14d,%r14d
  430381:	0f 88 e9 02 00 00    	js     430670 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x5f0>
  430387:	49 63 f6             	movslq %r14d,%rsi
  43038a:	4c 8b 3c f1          	mov    (%rcx,%rsi,8),%r15
  43038e:	41 88 97 c8 01 00 00 	mov    %dl,0x1c8(%r15)
  430395:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  43039c:	49 89 47 10          	mov    %rax,0x10(%r15)
  4303a0:	49 89 87 c0 01 00 00 	mov    %rax,0x1c0(%r15)
  4303a7:	0f 85 33 03 00 00    	jne    4306e0 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x660>
  4303ad:	49 83 bd a8 00 00 00 00 	cmpq   $0x0,0xa8(%r13)
  4303b5:	74 0e                	je     4303c5 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x345>
  4303b7:	41 83 bd b4 00 00 00 fc 	cmpl   $0xfffffffc,0xb4(%r13)
  4303bf:	0f 84 8b 03 00 00    	je     430750 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x6d0>
  4303c5:	0f b6 05 cd 99 4c 00 	movzbl 0x4c99cd(%rip),%eax        # 8f9d99 <_ZN4tomo22atomic_tripwire_detail5armedE>
  4303cc:	84 c0                	test   %al,%al
  4303ce:	74 18                	je     4303e8 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x368>
  4303d0:	48 83 3d c8 99 4c 00 00 	cmpq   $0x0,0x4c99c8(%rip)        # 8f9da0 <_ZN4tomo22atomic_tripwire_detail5stateE>
  4303d8:	74 0e                	je     4303e8 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x368>
  4303da:	4c 89 ea             	mov    %r13,%rdx
  4303dd:	4c 89 fe             	mov    %r15,%rsi
  4303e0:	4c 89 e7             	mov    %r12,%rdi
  4303e3:	e8 a8 19 0a 00       	call   4d1d90 <_ZN4tomo30xshard_tripwire_fragment_beginERKNS_4TaskERNS_5ShardERNS_2OpE>
  4303e8:	48 8b 83 40 02 00 00 	mov    0x240(%rbx),%rax
  4303ef:	48 39 83 60 02 00 00 	cmp    %rax,0x260(%rbx)
  4303f6:	0f 85 24 05 00 00    	jne    430920 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x8a0>
  4303fc:	48 8b 83 e0 02 00 00 	mov    0x2e0(%rbx),%rax
  430403:	48 39 83 00 03 00 00 	cmp    %rax,0x300(%rbx)
  43040a:	0f 85 10 05 00 00    	jne    430920 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x8a0>
  430410:	48 8b 3b             	mov    (%rbx),%rdi
  430413:	4c 89 e9             	mov    %r13,%rcx
  430416:	4c 89 e2             	mov    %r12,%rdx
  430419:	4c 89 fe             	mov    %r15,%rsi
  43041c:	e8 4f 91 07 00       	call   4a9570 <_ZN4tomo24xshard_task_should_deferERNS_6ServerERNS_5ShardERKNS_4TaskERNS_2OpE>
  430421:	41 89 c6             	mov    %eax,%r14d
  430424:	84 c0                	test   %al,%al
  430426:	0f 85 e4 03 00 00    	jne    430810 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x790>
  43042c:	49 8b 44 24 18       	mov    0x18(%r12),%rax
  430431:	48 85 c0             	test   %rax,%rax
  430434:	0f 84 d6 02 00 00    	je     430710 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x690>
  43043a:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
  43043e:	41 8b 57 18          	mov    0x18(%r15),%edx
  430442:	8b 4f 44             	mov    0x44(%rdi),%ecx
  430445:	49 ff 87 e8 03 00 00 	incq   0x3e8(%r15)
  43044c:	83 fa ff             	cmp    $0xffffffff,%edx
  43044f:	0f 84 db 05 00 00    	je     430a30 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x9b0>
  430455:	39 ca                	cmp    %ecx,%edx
  430457:	74 07                	je     430460 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x3e0>
  430459:	49 ff 87 10 04 00 00 	incq   0x410(%r15)
  430460:	48 85 c0             	test   %rax,%rax
  430463:	0f 84 e7 03 00 00    	je     430850 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x7d0>
  430469:	8b 0f                	mov    (%rdi),%ecx
  43046b:	4c 89 ea             	mov    %r13,%rdx
  43046e:	4c 89 fe             	mov    %r15,%rsi
  430471:	4c 89 e7             	mov    %r12,%rdi
  430474:	e8 17 95 0a 00       	call   4d9990 <_ZN4tomo14xshard_executeERKNS_4TaskERNS_5ShardERNS_2OpEj>
  430479:	89 c1                	mov    %eax,%ecx
  43047b:	4c 89 ea             	mov    %r13,%rdx
  43047e:	4c 89 fe             	mov    %r15,%rsi
  430481:	4c 89 e7             	mov    %r12,%rdi
  430484:	88 44 24 08          	mov    %al,0x8(%rsp)
  430488:	e8 23 7c 0a 00       	call   4d80b0 <_ZN4tomo19xshard_watch_finishERKNS_4TaskERNS_5ShardERNS_2OpENS_17ScatterTaskResultE>
  43048d:	80 7c 24 08 02       	cmpb   $0x2,0x8(%rsp)
  430492:	0f 84 a3 02 00 00    	je     43073b <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x6bb>
  430498:	80 7c 24 08 01       	cmpb   $0x1,0x8(%rsp)
  43049d:	0f 84 b9 fc ff ff    	je     43015c <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xdc>
  4304a3:	8b 83 8c 01 00 00    	mov    0x18c(%rbx),%eax
  4304a9:	85 c0                	test   %eax,%eax
  4304ab:	74 25                	je     4304d2 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x452>
  4304ad:	c4 e1 f9 6e cb       	vmovq  %rbx,%xmm1
  4304b2:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
  4304b7:	48 8d 15 82 d6 fb ff 	lea    -0x4297e(%rip),%rdx        # 3edb40 <_ZZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskEENUlPvmE0_4_FUNES6_m>
  4304be:	4c 89 e7             	mov    %r12,%rdi
  4304c1:	c4 c3 f1 22 c7 01    	vpinsrq $0x1,%r15,%xmm1,%xmm0
  4304c7:	c5 f9 7f 44 24 30    	vmovdqa %xmm0,0x30(%rsp)
  4304cd:	e8 ee 1f 07 00       	call   4a24c0 <_ZN4tomo24xshard_visit_task_hashesERKNS_4TaskEPvPFvS3_mE>
  4304d2:	49 8b 87 b0 04 00 00 	mov    0x4b0(%r15),%rax
  4304d9:	48 85 c0             	test   %rax,%rax
  4304dc:	0f 85 3b 07 00 00    	jne    430c1d <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xb9d>
  4304e2:	48 83 bb 80 01 00 00 00 	cmpq   $0x0,0x180(%rbx)
  4304ea:	48 8d 43 10          	lea    0x10(%rbx),%rax
  4304ee:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  4304f3:	0f 85 ea 06 00 00    	jne    430be3 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xb63>
  4304f9:	4c 89 ff             	mov    %r15,%rdi
  4304fc:	e8 2f 93 fc ff       	call   3f9830 <_ZN4tomo5Shard12publish_sizeEv>
  430501:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  430505:	48 8b 3b             	mov    (%rbx),%rdi
  430508:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  43050d:	4d 89 e8             	mov    %r13,%r8
  430510:	4c 89 e1             	mov    %r12,%rcx
  430513:	e8 d8 0a 0b 00       	call   4e0ff0 <_ZN4tomo15xshard_completeERNS_6ServerERNS_9ThreadCtxERNS_4RingERKNS_4TaskERNS_2OpE>
  430518:	84 c0                	test   %al,%al
  43051a:	0f 84 36 fc ff ff    	je     430156 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  430520:	3c 01                	cmp    $0x1,%al
  430522:	0f 84 34 fc ff ff    	je     43015c <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xdc>
  430528:	3c 02                	cmp    $0x2,%al
  43052a:	0f 84 6d 07 00 00    	je     430c9d <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xc1d>
  430530:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
  430536:	0f 84 46 05 00 00    	je     430a82 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa02>
  43053c:	48 8b bb 80 01 00 00 	mov    0x180(%rbx),%rdi
  430543:	48 85 ff             	test   %rdi,%rdi
  430546:	0f 84 ff 00 00 00    	je     43064b <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x5cb>
  43054c:	48 8b 43 08          	mov    0x8(%rbx),%rax
  430550:	49 8b 0c 24          	mov    (%r12),%rcx
  430554:	4c 89 ea             	mov    %r13,%rdx
  430557:	8b 30                	mov    (%rax),%esi
  430559:	e8 b2 c6 20 00       	call   63cc10 <_ZN4tomo10AofManager16defer_completionEjRNS_2OpEPNS_6ClientE>
  43055e:	e9 e0 00 00 00       	jmp    430643 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x5c3>
  430563:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  43056e:	66 90                	xchg   %ax,%ax
  430570:	48 8d bb 70 03 00 00 	lea    0x370(%rbx),%rdi
  430577:	4c 89 e6             	mov    %r12,%rsi
  43057a:	e8 01 f5 ff ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  43057f:	e9 d2 fb ff ff       	jmp    430156 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  430584:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  43058f:	90                   	nop
  430590:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  430597:	0f 85 6e 05 00 00    	jne    430b0b <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa8b>
  43059d:	48 8b 3b             	mov    (%rbx),%rdi
  4305a0:	48 8b 43 08          	mov    0x8(%rbx),%rax
  4305a4:	48 8d 73 10          	lea    0x10(%rbx),%rsi
  4305a8:	4c 8d 4c 24 30       	lea    0x30(%rsp),%r9
  4305ad:	c4 e1 f9 6e c6       	vmovq  %rsi,%xmm0
  4305b2:	4c 89 e6             	mov    %r12,%rsi
  4305b5:	8b 08                	mov    (%rax),%ecx
  4305b7:	48 8d 90 c0 03 00 00 	lea    0x3c0(%rax),%rdx
  4305be:	c4 e3 f9 22 c2 01    	vpinsrq $0x1,%rdx,%xmm0,%xmm0
  4305c4:	48 8b 93 80 01 00 00 	mov    0x180(%rbx),%rdx
  4305cb:	c5 fa 7f 44 24 38    	vmovdqu %xmm0,0x38(%rsp)
  4305d1:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
  4305d5:	44 8b 40 44          	mov    0x44(%rax),%r8d
  4305d9:	48 85 d2             	test   %rdx,%rdx
  4305dc:	4c 0f 44 ca          	cmove  %rdx,%r9
  4305e0:	4c 89 ea             	mov    %r13,%rdx
  4305e3:	e8 18 0d 0b 00       	call   4e1300 <_ZN4tomo18multi_execute_taskERNS_6ServerERKNS_4TaskERNS_5ShardEjjPNS_15AofOwnerContextE>
  4305e8:	41 89 c6             	mov    %eax,%r14d
  4305eb:	4c 89 ef             	mov    %r13,%rdi
  4305ee:	e8 3d 92 fc ff       	call   3f9830 <_ZN4tomo5Shard12publish_sizeEv>
  4305f3:	45 84 f6             	test   %r14b,%r14b
  4305f6:	0f 84 34 02 00 00    	je     430830 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x7b0>
  4305fc:	41 80 fe 02          	cmp    $0x2,%r14b
  430600:	0f 85 50 fb ff ff    	jne    430156 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  430606:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  43060b:	49 8b 0c 24          	mov    (%r12),%rcx
  43060f:	48 8b bb 80 01 00 00 	mov    0x180(%rbx),%rdi
  430616:	89 c2                	mov    %eax,%edx
  430618:	83 e0 07             	and    $0x7,%eax
  43061b:	c1 ea 03             	shr    $0x3,%edx
  43061e:	83 e2 07             	and    $0x7,%edx
  430621:	4c 69 e8 50 01 00 00 	imul   $0x150,%rax,%r13
  430628:	4c 03 ac d1 80 00 00 00 	add    0x80(%rcx,%rdx,8),%r13
  430630:	48 85 ff             	test   %rdi,%rdi
  430633:	74 16                	je     43064b <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x5cb>
  430635:	48 8b 43 08          	mov    0x8(%rbx),%rax
  430639:	4c 89 ea             	mov    %r13,%rdx
  43063c:	8b 30                	mov    (%rax),%esi
  43063e:	e8 cd c5 20 00       	call   63cc10 <_ZN4tomo10AofManager16defer_completionEjRNS_2OpEPNS_6ClientE>
  430643:	84 c0                	test   %al,%al
  430645:	0f 85 0b fb ff ff    	jne    430156 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  43064b:	41 c6 85 b8 00 00 00 02 	movb   $0x2,0xb8(%r13)
  430653:	49 8b 34 24          	mov    (%r12),%rsi
  430657:	48 89 df             	mov    %rbx,%rdi
  43065a:	e8 31 f8 ff ff       	call   42fe90 <_ZN4tomo7ExLoopTILb0EE13notify_senderEPNS_6ClientE>
  43065f:	e9 f2 fa ff ff       	jmp    430156 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  430664:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  43066f:	90                   	nop
  430670:	45 8b 75 08          	mov    0x8(%r13),%r14d
  430674:	e9 0e fd ff ff       	jmp    430387 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x307>
  430679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  430680:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  430687:	0f 84 10 ff ff ff    	je     43059d <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x51d>
  43068d:	49 8b 14 24          	mov    (%r12),%rdx
  430691:	48 85 d2             	test   %rdx,%rdx
  430694:	0f 84 71 04 00 00    	je     430b0b <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa8b>
  43069a:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  43069f:	48 8b 3b             	mov    (%rbx),%rdi
  4306a2:	89 c1                	mov    %eax,%ecx
  4306a4:	83 e0 07             	and    $0x7,%eax
  4306a7:	c1 e9 03             	shr    $0x3,%ecx
  4306aa:	83 e1 07             	and    $0x7,%ecx
  4306ad:	48 69 c0 50 01 00 00 	imul   $0x150,%rax,%rax
  4306b4:	48 03 84 ca 80 00 00 00 	add    0x80(%rdx,%rcx,8),%rax
  4306bc:	f6 40 1c 10          	testb  $0x10,0x1c(%rax)
  4306c0:	0f 85 4d 04 00 00    	jne    430b13 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa93>
  4306c6:	41 c6 85 c9 01 00 00 00 	movb   $0x0,0x1c9(%r13)
  4306ce:	e9 cd fe ff ff       	jmp    4305a0 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x520>
  4306d3:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4306de:	66 90                	xchg   %ax,%ax
  4306e0:	41 0f b6 45 1c       	movzbl 0x1c(%r13),%eax
  4306e5:	83 e0 10             	and    $0x10,%eax
  4306e8:	84 c0                	test   %al,%al
  4306ea:	41 0f 95 87 c9 01 00 00 	setne  0x1c9(%r15)
  4306f2:	0f 84 b5 fc ff ff    	je     4303ad <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x32d>
  4306f8:	48 8b 03             	mov    (%rbx),%rax
  4306fb:	f0 48 ff 80 80 4c 01 00 	lock incq 0x14c80(%rax)
  430703:	e9 a5 fc ff ff       	jmp    4303ad <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x32d>
  430708:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  430710:	49 8b 55 00          	mov    0x0(%r13),%rdx
  430714:	f7 42 10 01 04 00 00 	testl  $0x401,0x10(%rdx)
  43071b:	0f 84 19 fd ff ff    	je     43043a <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x3ba>
  430721:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  430726:	41 80 7f 08 00       	cmpb   $0x0,0x8(%r15)
  43072b:	0f 85 3d 04 00 00    	jne    430b6e <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xaee>
  430731:	49 8b 44 24 18       	mov    0x18(%r12),%rax
  430736:	e9 ff fc ff ff       	jmp    43043a <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x3ba>
  43073b:	48 8d bb 30 02 00 00 	lea    0x230(%rbx),%rdi
  430742:	4c 89 e6             	mov    %r12,%rsi
  430745:	e8 36 f3 ff ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  43074a:	e9 07 fa ff ff       	jmp    430156 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  43074f:	90                   	nop
  430750:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  430754:	41 8b 47 18          	mov    0x18(%r15),%eax
  430758:	8b 56 44             	mov    0x44(%rsi),%edx
  43075b:	49 ff 87 e8 03 00 00 	incq   0x3e8(%r15)
  430762:	83 f8 ff             	cmp    $0xffffffff,%eax
  430765:	0f 84 e7 02 00 00    	je     430a52 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x9d2>
  43076b:	39 d0                	cmp    %edx,%eax
  43076d:	74 07                	je     430776 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x6f6>
  43076f:	49 ff 87 10 04 00 00 	incq   0x410(%r15)
  430776:	8b 93 8c 01 00 00    	mov    0x18c(%rbx),%edx
  43077c:	49 8b 4d 10          	mov    0x10(%r13),%rcx
  430780:	85 d2                	test   %edx,%edx
  430782:	74 14                	je     430798 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x718>
  430784:	8b 83 90 01 00 00    	mov    0x190(%rbx),%eax
  43078a:	ff c8                	dec    %eax
  43078c:	0f 84 4e 02 00 00    	je     4309e0 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x960>
  430792:	89 83 90 01 00 00    	mov    %eax,0x190(%rbx)
  430798:	48 8b 3b             	mov    (%rbx),%rdi
  43079b:	48 8d 53 10          	lea    0x10(%rbx),%rdx
  43079f:	4d 89 e9             	mov    %r13,%r9
  4307a2:	4d 89 f8             	mov    %r15,%r8
  4307a5:	4c 89 e1             	mov    %r12,%rcx
  4307a8:	e8 83 ca 09 00       	call   4cd230 <_ZN4tomo16blocking_executeERNS_6ServerERNS_9ThreadCtxERNS_4RingERKNS_4TaskERNS_5ShardERNS_2OpE>
  4307ad:	41 89 c6             	mov    %eax,%r14d
  4307b0:	e9 a7 f9 ff ff       	jmp    43015c <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xdc>
  4307b5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4307c0:	4e 8b 24 f1          	mov    (%rcx,%r14,8),%r12
  4307c4:	41 88 94 24 c8 01 00 00 	mov    %dl,0x1c8(%r12)
  4307cc:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  4307d3:	49 89 44 24 10       	mov    %rax,0x10(%r12)
  4307d8:	49 89 84 24 c0 01 00 00 	mov    %rax,0x1c0(%r12)
  4307e0:	0f 85 42 03 00 00    	jne    430b28 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xaa8>
  4307e6:	48 8b 3b             	mov    (%rbx),%rdi
  4307e9:	ba 20 00 00 00       	mov    $0x20,%edx
  4307ee:	4c 89 e6             	mov    %r12,%rsi
  4307f1:	e8 0a 86 09 00       	call   4c8e00 <_ZN4tomo20xshard_cleanup_shardERNS_6ServerERNS_5ShardEj>
  4307f6:	4c 89 e7             	mov    %r12,%rdi
  4307f9:	e8 32 90 fc ff       	call   3f9830 <_ZN4tomo5Shard12publish_sizeEv>
  4307fe:	e9 53 f9 ff ff       	jmp    430156 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  430803:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  43080e:	66 90                	xchg   %ax,%ax
  430810:	48 8d 83 30 02 00 00 	lea    0x230(%rbx),%rax
  430817:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  43081c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  430821:	4c 89 e6             	mov    %r12,%rsi
  430824:	e8 57 f2 ff ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  430829:	e9 28 f9 ff ff       	jmp    430156 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  43082e:	66 90                	xchg   %ax,%ax
  430830:	48 8d bb 80 02 00 00 	lea    0x280(%rbx),%rdi
  430837:	4c 89 e6             	mov    %r12,%rsi
  43083a:	e8 41 f2 ff ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  43083f:	e9 12 f9 ff ff       	jmp    430156 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  430844:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  43084f:	90                   	nop
  430850:	4d 8b 75 00          	mov    0x0(%r13),%r14
  430854:	41 0f b7 76 26       	movzwl 0x26(%r14),%esi
  430859:	e8 52 95 fc ff       	call   3f9db0 <_ZN4tomo9ThreadCtx12note_commandEt>
  43085e:	41 f6 46 11 01       	testb  $0x1,0x11(%r14)
  430863:	0f 85 27 03 00 00    	jne    430b90 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xb10>
  430869:	49 8b 87 00 01 00 00 	mov    0x100(%r15),%rax
  430870:	48 85 c0             	test   %rax,%rax
  430873:	0f 84 47 01 00 00    	je     4309c0 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x940>
  430879:	48 83 b8 10 02 00 00 00 	cmpq   $0x0,0x210(%rax)
  430881:	0f 84 39 01 00 00    	je     4309c0 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x940>
  430887:	49 8b 04 24          	mov    (%r12),%rax
  43088b:	48 8b 3b             	mov    (%rbx),%rdi
  43088e:	4c 8d 44 24 30       	lea    0x30(%rsp),%r8
  430893:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
  430897:	4c 89 ea             	mov    %r13,%rdx
  43089a:	62 f1 7f 28 7f 84 24 30 00 00 00 	vmovdqu8 %ymm0,0x30(%rsp)
  4308a5:	4c 89 fe             	mov    %r15,%rsi
  4308a8:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  4308ad:	48 8b 88 a8 07 00 00 	mov    0x7a8(%rax),%rcx
  4308b4:	c5 f8 77             	vzeroupper
  4308b7:	e8 54 8f 09 00       	call   4c9810 <_ZN4tomo20xshard_plain_prepareERNS_6ServerERNS_5ShardERNS_2OpEmRNS_21PlainForeignReadScopeE>
  4308bc:	88 44 24 07          	mov    %al,0x7(%rsp)
  4308c0:	4d 8b b7 b0 04 00 00 	mov    0x4b0(%r15),%r14
  4308c7:	4d 85 f6             	test   %r14,%r14
  4308ca:	0f 85 f8 03 00 00    	jne    430cc8 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xc48>
  4308d0:	84 c0                	test   %al,%al
  4308d2:	0f 84 f9 02 00 00    	je     430bd1 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xb51>
  4308d8:	49 8b 45 00          	mov    0x0(%r13),%rax
  4308dc:	4c 89 ee             	mov    %r13,%rsi
  4308df:	4c 89 ff             	mov    %r15,%rdi
  4308e2:	ff 50 18             	call   *0x18(%rax)
  4308e5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  4308ea:	4c 89 ff             	mov    %r15,%rdi
  4308ed:	e8 fe 39 07 00       	call   4a42f0 <_ZN4tomo19xshard_plain_finishERNS_5ShardERNS_21PlainForeignReadScopeE>
  4308f2:	4d 85 f6             	test   %r14,%r14
  4308f5:	0f 85 0b 04 00 00    	jne    430d06 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xc86>
  4308fb:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  430900:	48 85 ff             	test   %rdi,%rdi
  430903:	0f 84 27 fc ff ff    	je     430530 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4b0>
  430909:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  43090e:	48 29 fe             	sub    %rdi,%rsi
  430911:	e8 8a c2 be ff       	call   1cba0 <_ZdlPvm@plt>
  430916:	e9 15 fc ff ff       	jmp    430530 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4b0>
  43091b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  430920:	48 8d 83 30 02 00 00 	lea    0x230(%rbx),%rax
  430927:	45 89 f0             	mov    %r14d,%r8d
  43092a:	4c 89 e9             	mov    %r13,%rcx
  43092d:	4c 89 e2             	mov    %r12,%rdx
  430930:	48 89 c6             	mov    %rax,%rsi
  430933:	48 89 df             	mov    %rbx,%rdi
  430936:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  43093b:	e8 80 f1 ff ff       	call   42fac0 <_ZN4tomo7ExLoopTILb0EE21parked_predecessor_inERKSt5dequeINS_4TaskESaIS3_EERKS3_RNS_2OpEi>
  430940:	84 c0                	test   %al,%al
  430942:	0f 85 d4 fe ff ff    	jne    43081c <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x79c>
  430948:	48 8d b3 d0 02 00 00 	lea    0x2d0(%rbx),%rsi
  43094f:	45 89 f0             	mov    %r14d,%r8d
  430952:	4c 89 e9             	mov    %r13,%rcx
  430955:	4c 89 e2             	mov    %r12,%rdx
  430958:	48 89 df             	mov    %rbx,%rdi
  43095b:	e8 60 f1 ff ff       	call   42fac0 <_ZN4tomo7ExLoopTILb0EE21parked_predecessor_inERKSt5dequeINS_4TaskESaIS3_EERKS3_RNS_2OpEi>
  430960:	84 c0                	test   %al,%al
  430962:	0f 85 b4 fe ff ff    	jne    43081c <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x79c>
  430968:	e9 a3 fa ff ff       	jmp    430410 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x390>
  43096d:	0f 1f 00             	nopl   (%rax)
  430970:	83 e1 07             	and    $0x7,%ecx
  430973:	4c 8d bb 30 02 00 00 	lea    0x230(%rbx),%r15
  43097a:	45 89 f0             	mov    %r14d,%r8d
  43097d:	4c 89 e2             	mov    %r12,%rdx
  430980:	48 69 c9 50 01 00 00 	imul   $0x150,%rcx,%rcx
  430987:	4c 89 fe             	mov    %r15,%rsi
  43098a:	48 89 df             	mov    %rbx,%rdi
  43098d:	48 01 c8             	add    %rcx,%rax
  430990:	48 89 c1             	mov    %rax,%rcx
  430993:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  430998:	e8 23 f1 ff ff       	call   42fac0 <_ZN4tomo7ExLoopTILb0EE21parked_predecessor_inERKSt5dequeINS_4TaskESaIS3_EERKS3_RNS_2OpEi>
  43099d:	84 c0                	test   %al,%al
  43099f:	0f 84 b6 00 00 00    	je     430a5b <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x9db>
  4309a5:	4c 89 e6             	mov    %r12,%rsi
  4309a8:	4c 89 ff             	mov    %r15,%rdi
  4309ab:	e8 d0 f0 ff ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  4309b0:	e9 a1 f7 ff ff       	jmp    430156 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  4309b5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4309c0:	49 8b 45 00          	mov    0x0(%r13),%rax
  4309c4:	4c 89 ee             	mov    %r13,%rsi
  4309c7:	4c 89 ff             	mov    %r15,%rdi
  4309ca:	ff 50 18             	call   *0x18(%rax)
  4309cd:	e9 5e fb ff ff       	jmp    430530 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4b0>
  4309d2:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4309dd:	0f 1f 00             	nopl   (%rax)
  4309e0:	49 8b 87 78 05 00 00 	mov    0x578(%r15),%rax
  4309e7:	81 e1 ff 3f 00 00    	and    $0x3fff,%ecx
  4309ed:	89 93 90 01 00 00    	mov    %edx,0x190(%rbx)
  4309f3:	48 85 c0             	test   %rax,%rax
  4309f6:	0f 84 9c fd ff ff    	je     430798 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x718>
  4309fc:	41 0f b7 7f 04       	movzwl 0x4(%r15),%edi
  430a01:	39 f9                	cmp    %edi,%ecx
  430a03:	0f 82 8f fd ff ff    	jb     430798 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x718>
  430a09:	45 0f b7 47 06       	movzwl 0x6(%r15),%r8d
  430a0e:	44 39 c1             	cmp    %r8d,%ecx
  430a11:	0f 83 81 fd ff ff    	jae    430798 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x718>
  430a17:	29 f9                	sub    %edi,%ecx
  430a19:	01 14 88             	add    %edx,(%rax,%rcx,4)
  430a1c:	e9 77 fd ff ff       	jmp    430798 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x718>
  430a21:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  430a2c:	0f 1f 40 00          	nopl   0x0(%rax)
  430a30:	41 89 4f 18          	mov    %ecx,0x18(%r15)
  430a34:	e9 27 fa ff ff       	jmp    430460 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x3e0>
  430a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  430a40:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  430a47:	0f 84 50 fb ff ff    	je     43059d <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x51d>
  430a4d:	e9 48 fc ff ff       	jmp    43069a <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x61a>
  430a52:	41 89 57 18          	mov    %edx,0x18(%r15)
  430a56:	e9 1b fd ff ff       	jmp    430776 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x6f6>
  430a5b:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  430a60:	48 8d b3 d0 02 00 00 	lea    0x2d0(%rbx),%rsi
  430a67:	45 89 f0             	mov    %r14d,%r8d
  430a6a:	4c 89 e2             	mov    %r12,%rdx
  430a6d:	48 89 df             	mov    %rbx,%rdi
  430a70:	e8 4b f0 ff ff       	call   42fac0 <_ZN4tomo7ExLoopTILb0EE21parked_predecessor_inERKSt5dequeINS_4TaskESaIS3_EERKS3_RNS_2OpEi>
  430a75:	84 c0                	test   %al,%al
  430a77:	0f 85 28 ff ff ff    	jne    4309a5 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x925>
  430a7d:	e9 a3 f7 ff ff       	jmp    430225 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x1a5>
  430a82:	8b 8b 8c 01 00 00    	mov    0x18c(%rbx),%ecx
  430a88:	49 8b 55 10          	mov    0x10(%r13),%rdx
  430a8c:	85 c9                	test   %ecx,%ecx
  430a8e:	74 14                	je     430aa4 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa24>
  430a90:	8b 83 90 01 00 00    	mov    0x190(%rbx),%eax
  430a96:	ff c8                	dec    %eax
  430a98:	0f 84 92 01 00 00    	je     430c30 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xbb0>
  430a9e:	89 83 90 01 00 00    	mov    %eax,0x190(%rbx)
  430aa4:	49 8b 45 00          	mov    0x0(%r13),%rax
  430aa8:	f7 40 10 01 04 00 00 	testl  $0x401,0x10(%rax)
  430aaf:	0f 85 81 00 00 00    	jne    430b36 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xab6>
  430ab5:	48 83 bb 80 01 00 00 00 	cmpq   $0x0,0x180(%rbx)
  430abd:	0f 84 88 fb ff ff    	je     43064b <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x5cb>
  430ac3:	48 8b 43 08          	mov    0x8(%rbx),%rax
  430ac7:	48 8d 7b 10          	lea    0x10(%rbx),%rdi
  430acb:	4c 89 ee             	mov    %r13,%rsi
  430ace:	c4 e1 f9 6e c7       	vmovq  %rdi,%xmm0
  430ad3:	4c 89 ff             	mov    %r15,%rdi
  430ad6:	8b 10                	mov    (%rax),%edx
  430ad8:	48 05 c0 03 00 00    	add    $0x3c0,%rax
  430ade:	c4 e3 f9 22 c0 01    	vpinsrq $0x1,%rax,%xmm0,%xmm0
  430ae4:	c5 fa 7f 44 24 38    	vmovdqu %xmm0,0x38(%rsp)
  430aea:	89 54 24 30          	mov    %edx,0x30(%rsp)
  430aee:	41 83 bd b4 00 00 00 fd 	cmpl   $0xfffffffd,0xb4(%r13)
  430af6:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
  430afb:	0f 84 58 02 00 00    	je     430d59 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xcd9>
  430b01:	e8 aa 45 21 00       	call   6450b0 <_ZN4tomo19aof_record_local_opERNS_5ShardERNS_2OpERNS_15AofOwnerContextE>
  430b06:	e9 31 fa ff ff       	jmp    43053c <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4bc>
  430b0b:	48 8b 3b             	mov    (%rbx),%rdi
  430b0e:	e9 b3 fb ff ff       	jmp    4306c6 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x646>
  430b13:	41 c6 85 c9 01 00 00 01 	movb   $0x1,0x1c9(%r13)
  430b1b:	f0 48 ff 87 80 4c 01 00 	lock incq 0x14c80(%rdi)
  430b23:	e9 75 fa ff ff       	jmp    43059d <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x51d>
  430b28:	41 c6 84 24 c9 01 00 00 00 	movb   $0x0,0x1c9(%r12)
  430b31:	e9 b0 fc ff ff       	jmp    4307e6 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x766>
  430b36:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  430b3b:	41 80 7f 08 00       	cmpb   $0x0,0x8(%r15)
  430b40:	0f 85 34 01 00 00    	jne    430c7a <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xbfa>
  430b46:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
  430b4c:	0f 84 63 ff ff ff    	je     430ab5 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa35>
  430b52:	e9 e5 f9 ff ff       	jmp    43053c <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4bc>
  430b57:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
  430b60:	49 83 bf d8 04 00 00 00 	cmpq   $0x0,0x4d8(%r15)
  430b68:	0f 84 1c 01 00 00    	je     430c8a <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xc0a>
  430b6e:	4c 89 ee             	mov    %r13,%rsi
  430b71:	4c 89 ff             	mov    %r15,%rdi
  430b74:	e8 b7 6a 0a 00       	call   4d7630 <_ZN4tomo23multi_plain_write_readyERNS_5ShardERNS_2OpE>
  430b79:	84 c0                	test   %al,%al
  430b7b:	0f 85 b0 fb ff ff    	jne    430731 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x6b1>
  430b81:	e9 d6 f5 ff ff       	jmp    43015c <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xdc>
  430b86:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
  430b90:	49 8b 95 c0 00 00 00 	mov    0xc0(%r13),%rdx
  430b97:	41 0f bf 46 20       	movswl 0x20(%r14),%eax
  430b9c:	49 8d 7f 38          	lea    0x38(%r15),%rdi
  430ba0:	48 85 d2             	test   %rdx,%rdx
  430ba3:	0f 84 4d 01 00 00    	je     430cf6 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xc76>
  430ba9:	48 c1 e0 04          	shl    $0x4,%rax
  430bad:	48 01 d0             	add    %rdx,%rax
  430bb0:	48 8b 30             	mov    (%rax),%rsi
  430bb3:	48 8b 50 08          	mov    0x8(%rax),%rdx
  430bb7:	e8 64 99 fd ff       	call   40a520 <_ZN4tomo9FlatStore12budget_admitENS_5SliceE>
  430bbc:	84 c0                	test   %al,%al
  430bbe:	0f 85 a5 fc ff ff    	jne    430869 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x7e9>
  430bc4:	4c 89 ef             	mov    %r13,%rdi
  430bc7:	e8 a4 ea 10 00       	call   53f670 <_ZN4tomo19reply_maxmemory_oomERNS_2OpE>
  430bcc:	e9 5f f9 ff ff       	jmp    430530 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4b0>
  430bd1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  430bd6:	4c 89 ff             	mov    %r15,%rdi
  430bd9:	e8 12 37 07 00       	call   4a42f0 <_ZN4tomo19xshard_plain_finishERNS_5ShardERNS_21PlainForeignReadScopeE>
  430bde:	e9 18 fd ff ff       	jmp    4308fb <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x87b>
  430be3:	48 8b 43 08          	mov    0x8(%rbx),%rax
  430be7:	c5 fa 7e 54 24 08    	vmovq  0x8(%rsp),%xmm2
  430bed:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
  430bf2:	4c 89 fe             	mov    %r15,%rsi
  430bf5:	4c 89 e7             	mov    %r12,%rdi
  430bf8:	8b 10                	mov    (%rax),%edx
  430bfa:	48 05 c0 03 00 00    	add    $0x3c0,%rax
  430c00:	c4 e3 e9 22 c0 01    	vpinsrq $0x1,%rax,%xmm2,%xmm0
  430c06:	c5 fa 7f 44 24 38    	vmovdqu %xmm0,0x38(%rsp)
  430c0c:	89 54 24 30          	mov    %edx,0x30(%rsp)
  430c10:	4c 89 ea             	mov    %r13,%rdx
  430c13:	e8 08 15 07 00       	call   4a2120 <_ZN4tomo15xshard_aof_emitERKNS_4TaskERNS_5ShardERNS_2OpERNS_15AofOwnerContextE>
  430c18:	e9 dc f8 ff ff       	jmp    4304f9 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x479>
  430c1d:	4c 89 ea             	mov    %r13,%rdx
  430c20:	4c 89 fe             	mov    %r15,%rsi
  430c23:	4c 89 e7             	mov    %r12,%rdi
  430c26:	e8 c5 c2 09 00       	call   4ccef0 <_ZN4tomo35blocking_scatter_mutation_publishedERKNS_4TaskERNS_5ShardERNS_2OpE>
  430c2b:	e9 b2 f8 ff ff       	jmp    4304e2 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x462>
  430c30:	49 8b 87 78 05 00 00 	mov    0x578(%r15),%rax
  430c37:	81 e2 ff 3f 00 00    	and    $0x3fff,%edx
  430c3d:	89 8b 90 01 00 00    	mov    %ecx,0x190(%rbx)
  430c43:	48 85 c0             	test   %rax,%rax
  430c46:	0f 84 58 fe ff ff    	je     430aa4 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa24>
  430c4c:	41 0f b7 77 04       	movzwl 0x4(%r15),%esi
  430c51:	39 f2                	cmp    %esi,%edx
  430c53:	0f 82 4b fe ff ff    	jb     430aa4 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa24>
  430c59:	41 0f b7 7f 06       	movzwl 0x6(%r15),%edi
  430c5e:	39 fa                	cmp    %edi,%edx
  430c60:	0f 83 3e fe ff ff    	jae    430aa4 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa24>
  430c66:	29 f2                	sub    %esi,%edx
  430c68:	01 0c 90             	add    %ecx,(%rax,%rdx,4)
  430c6b:	e9 34 fe ff ff       	jmp    430aa4 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa24>
  430c70:	49 83 bf d8 04 00 00 00 	cmpq   $0x0,0x4d8(%r15)
  430c78:	74 3e                	je     430cb8 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xc38>
  430c7a:	4c 89 ee             	mov    %r13,%rsi
  430c7d:	4c 89 ff             	mov    %r15,%rdi
  430c80:	e8 7b 72 0a 00       	call   4d7f00 <_ZN4tomo27multi_plain_write_committedERNS_5ShardERNS_2OpE>
  430c85:	e9 bc fe ff ff       	jmp    430b46 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xac6>
  430c8a:	49 83 bf 10 05 00 00 00 	cmpq   $0x0,0x510(%r15)
  430c92:	0f 84 99 fa ff ff    	je     430731 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x6b1>
  430c98:	e9 d1 fe ff ff       	jmp    430b6e <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xaee>
  430c9d:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  430ca1:	48 8b 3b             	mov    (%rbx),%rdi
  430ca4:	4c 89 e2             	mov    %r12,%rdx
  430ca7:	e8 34 19 07 00       	call   4a25e0 <_ZN4tomo19xshard_queue_commitERNS_6ServerERNS_9ThreadCtxERKNS_4TaskE>
  430cac:	c6 83 da 15 00 00 01 	movb   $0x1,0x15da(%rbx)
  430cb3:	e9 9e f4 ff ff       	jmp    430156 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  430cb8:	49 83 bf 10 05 00 00 00 	cmpq   $0x0,0x510(%r15)
  430cc0:	0f 84 80 fe ff ff    	je     430b46 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xac6>
  430cc6:	eb b2                	jmp    430c7a <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xbfa>
  430cc8:	bf 01 00 00 00       	mov    $0x1,%edi
  430ccd:	e8 ae 39 07 00       	call   4a4680 <_ZN4tomo32blocking_defer_plain_publicationEb>
  430cd2:	80 7c 24 07 00       	cmpb   $0x0,0x7(%rsp)
  430cd7:	0f 85 fb fb ff ff    	jne    4308d8 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x858>
  430cdd:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  430ce2:	4c 89 ff             	mov    %r15,%rdi
  430ce5:	e8 06 36 07 00       	call   4a42f0 <_ZN4tomo19xshard_plain_finishERNS_5ShardERNS_21PlainForeignReadScopeE>
  430cea:	31 ff                	xor    %edi,%edi
  430cec:	e8 8f 39 07 00       	call   4a4680 <_ZN4tomo32blocking_defer_plain_publicationEb>
  430cf1:	e9 05 fc ff ff       	jmp    4308fb <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x87b>
  430cf6:	48 83 c0 0d          	add    $0xd,%rax
  430cfa:	48 c1 e0 04          	shl    $0x4,%rax
  430cfe:	4c 01 e8             	add    %r13,%rax
  430d01:	e9 aa fe ff ff       	jmp    430bb0 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xb30>
  430d06:	31 ff                	xor    %edi,%edi
  430d08:	e8 73 39 07 00       	call   4a4680 <_ZN4tomo32blocking_defer_plain_publicationEb>
  430d0d:	4c 89 ee             	mov    %r13,%rsi
  430d10:	4c 89 ff             	mov    %r15,%rdi
  430d13:	e8 18 c0 09 00       	call   4ccd30 <_ZN4tomo33blocking_plain_mutation_publishedERNS_5ShardERNS_2OpE>
  430d18:	e9 de fb ff ff       	jmp    4308fb <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x87b>
  430d1d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  430d22:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  430d27:	48 29 fe             	sub    %rdi,%rsi
  430d2a:	48 85 ff             	test   %rdi,%rdi
  430d2d:	74 08                	je     430d37 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xcb7>
  430d2f:	c5 f8 77             	vzeroupper
  430d32:	e8 69 be be ff       	call   1cba0 <_ZdlPvm@plt>
  430d37:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  430d3c:	c5 f8 77             	vzeroupper
  430d3f:	e8 8c aa fc ff       	call   3fb7d0 <_ZN4tomo6Server15ClientWorkScopeD1Ev>
  430d44:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  430d49:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  430d52:	74 21                	je     430d75 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xcf5>
  430d54:	e8 47 ba be ff       	call   1c7a0 <__stack_chk_fail@plt>
  430d59:	e8 92 96 07 00       	call   4aa3f0 <_ZN4tomo21xshard_aof_emit_localERNS_5ShardERNS_2OpERNS_15AofOwnerContextE>
  430d5e:	e9 d9 f7 ff ff       	jmp    43053c <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4bc>
  430d63:	f3 0f 1e fa          	endbr64
  430d67:	48 89 c3             	mov    %rax,%rbx
  430d6a:	eb cb                	jmp    430d37 <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xcb7>
  430d6c:	f3 0f 1e fa          	endbr64
  430d70:	48 89 c3             	mov    %rax,%rbx
  430d73:	eb a8                	jmp    430d1d <_ZN4tomo7ExLoopTILb0EE7executeILb0ELb0EEEbRKNS_4TaskE+0xc9d>
  430d75:	48 89 df             	mov    %rbx,%rdi
  430d78:	e8 f3 bf be ff       	call   1cd70 <_Unwind_Resume@plt>

Disassembly of section .rlfence:

Disassembly of section .fini:
