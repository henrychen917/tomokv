
build/exbatch-unit:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

000000000033e750 <_ZN4tomo23command_metadata_lookupENS_5SliceE>:
  33e750:	f3 0f 1e fa          	endbr64
  33e754:	41 56                	push   %r14
  33e756:	41 55                	push   %r13
  33e758:	41 54                	push   %r12
  33e75a:	55                   	push   %rbp
  33e75b:	48 89 fd             	mov    %rdi,%rbp
  33e75e:	53                   	push   %rbx
  33e75f:	89 f3                	mov    %esi,%ebx
  33e761:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  33e766:	83 fe 1d             	cmp    $0x1d,%esi
  33e769:	0f 87 e8 00 00 00    	ja     33e857 <_ZN4tomo23command_metadata_lookupENS_5SliceE+0x107>
  33e76f:	41 ba 05 00 00 00    	mov    $0x5,%r10d
  33e775:	41 bc 76 01 00 00    	mov    $0x176,%r12d
  33e77b:	45 31 db             	xor    %r11d,%r11d
  33e77e:	4c 8d 2d 5b 53 0c 00 	lea    0xc535b(%rip),%r13        # 403ae0 <_ZN4tomo12_GLOBAL__N_1L18kGeneratedMetadataE>
  33e785:	4c 8d 35 34 8d 06 00 	lea    0x68d34(%rip),%r14        # 3a74c0 <_ZN4tomo12_GLOBAL__N_1L14kMetadataIndexE>
  33e78c:	0f 1f 40 00          	nopl   0x0(%rax)
  33e790:	4d 89 e1             	mov    %r12,%r9
  33e793:	89 df                	mov    %ebx,%edi
  33e795:	4d 29 d9             	sub    %r11,%r9
  33e798:	49 d1 e9             	shr    $1,%r9
  33e79b:	4d 01 d9             	add    %r11,%r9
  33e79e:	41 39 da             	cmp    %ebx,%r10d
  33e7a1:	41 0f 46 fa          	cmovbe %r10d,%edi
  33e7a5:	85 ff                	test   %edi,%edi
  33e7a7:	0f 84 c3 00 00 00    	je     33e870 <_ZN4tomo23command_metadata_lookupENS_5SliceE+0x120>
  33e7ad:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
  33e7b1:	89 ff                	mov    %edi,%edi
  33e7b3:	31 d2                	xor    %edx,%edx
  33e7b5:	48 c1 e0 04          	shl    $0x4,%rax
  33e7b9:	4d 8b 44 05 00       	mov    0x0(%r13,%rax,1),%r8
  33e7be:	eb 0c                	jmp    33e7cc <_ZN4tomo23command_metadata_lookupENS_5SliceE+0x7c>
  33e7c0:	48 ff c2             	inc    %rdx
  33e7c3:	48 39 d7             	cmp    %rdx,%rdi
  33e7c6:	0f 84 a4 00 00 00    	je     33e870 <_ZN4tomo23command_metadata_lookupENS_5SliceE+0x120>
  33e7cc:	0f b6 44 15 00       	movzbl 0x0(%rbp,%rdx,1),%eax
  33e7d1:	8d 70 bf             	lea    -0x41(%rax),%esi
  33e7d4:	8d 48 20             	lea    0x20(%rax),%ecx
  33e7d7:	40 80 fe 1a          	cmp    $0x1a,%sil
  33e7db:	0f 42 c1             	cmovb  %ecx,%eax
  33e7de:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
  33e7e3:	0f b6 c0             	movzbl %al,%eax
  33e7e6:	29 c8                	sub    %ecx,%eax
  33e7e8:	74 d6                	je     33e7c0 <_ZN4tomo23command_metadata_lookupENS_5SliceE+0x70>
  33e7ea:	85 c0                	test   %eax,%eax
  33e7ec:	0f 88 ae 00 00 00    	js     33e8a0 <_ZN4tomo23command_metadata_lookupENS_5SliceE+0x150>
  33e7f2:	4d 8d 59 01          	lea    0x1(%r9),%r11
  33e7f6:	4d 39 e3             	cmp    %r12,%r11
  33e7f9:	73 5c                	jae    33e857 <_ZN4tomo23command_metadata_lookupENS_5SliceE+0x107>
  33e7fb:	4c 89 e0             	mov    %r12,%rax
  33e7fe:	4c 29 d8             	sub    %r11,%rax
  33e801:	48 d1 e8             	shr    $1,%rax
  33e804:	4c 01 d8             	add    %r11,%rax
  33e807:	45 0f b7 14 86       	movzwl (%r14,%rax,4),%r10d
  33e80c:	eb 82                	jmp    33e790 <_ZN4tomo23command_metadata_lookupENS_5SliceE+0x40>
  33e80e:	66 90                	xchg   %ax,%ax
  33e810:	4c 8d 25 c9 52 0c 00 	lea    0xc52c9(%rip),%r12        # 403ae0 <_ZN4tomo12_GLOBAL__N_1L18kGeneratedMetadataE>
  33e817:	4d 8d ac 24 20 46 00 00 	lea    0x4620(%r12),%r13
  33e81f:	eb 18                	jmp    33e839 <_ZN4tomo23command_metadata_lookupENS_5SliceE+0xe9>
  33e821:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  33e82c:	0f 1f 40 00          	nopl   0x0(%rax)
  33e830:	49 83 c4 30          	add    $0x30,%r12
  33e834:	4d 39 e5             	cmp    %r12,%r13
  33e837:	74 1e                	je     33e857 <_ZN4tomo23command_metadata_lookupENS_5SliceE+0x107>
  33e839:	49 8b 14 24          	mov    (%r12),%rdx
  33e83d:	89 de                	mov    %ebx,%esi
  33e83f:	48 89 ef             	mov    %rbp,%rdi
  33e842:	e8 79 f9 ff ff       	call   33e1c0 <_ZN4tomo12_GLOBAL__N_117ascii_equal_icaseENS_5SliceEPKc.isra.0>
  33e847:	84 c0                	test   %al,%al
  33e849:	74 e5                	je     33e830 <_ZN4tomo23command_metadata_lookupENS_5SliceE+0xe0>
  33e84b:	5b                   	pop    %rbx
  33e84c:	4c 89 e0             	mov    %r12,%rax
  33e84f:	5d                   	pop    %rbp
  33e850:	41 5c                	pop    %r12
  33e852:	41 5d                	pop    %r13
  33e854:	41 5e                	pop    %r14
  33e856:	c3                   	ret
  33e857:	45 31 e4             	xor    %r12d,%r12d
  33e85a:	5b                   	pop    %rbx
  33e85b:	5d                   	pop    %rbp
  33e85c:	4c 89 e0             	mov    %r12,%rax
  33e85f:	41 5c                	pop    %r12
  33e861:	41 5d                	pop    %r13
  33e863:	41 5e                	pop    %r14
  33e865:	c3                   	ret
  33e866:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
  33e870:	89 d8                	mov    %ebx,%eax
  33e872:	44 29 d0             	sub    %r10d,%eax
  33e875:	0f 85 6f ff ff ff    	jne    33e7ea <_ZN4tomo23command_metadata_lookupENS_5SliceE+0x9a>
  33e87b:	4f 8d 24 49          	lea    (%r9,%r9,2),%r12
  33e87f:	48 8d 05 5a 52 0c 00 	lea    0xc525a(%rip),%rax        # 403ae0 <_ZN4tomo12_GLOBAL__N_1L18kGeneratedMetadataE>
  33e886:	5b                   	pop    %rbx
  33e887:	5d                   	pop    %rbp
  33e888:	49 c1 e4 04          	shl    $0x4,%r12
  33e88c:	49 01 c4             	add    %rax,%r12
  33e88f:	4c 89 e0             	mov    %r12,%rax
  33e892:	41 5c                	pop    %r12
  33e894:	41 5d                	pop    %r13
  33e896:	41 5e                	pop    %r14
  33e898:	c3                   	ret
  33e899:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  33e8a0:	4d 89 cc             	mov    %r9,%r12
  33e8a3:	e9 4e ff ff ff       	jmp    33e7f6 <_ZN4tomo23command_metadata_lookupENS_5SliceE+0xa6>

Disassembly of section .rlfence:

Disassembly of section .fini:
