
build/exbatch-unit:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

00000000003404b0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj>:
  3404b0:	f3 0f 1e fa          	endbr64
  3404b4:	41 57                	push   %r15
  3404b6:	41 56                	push   %r14
  3404b8:	41 55                	push   %r13
  3404ba:	41 54                	push   %r12
  3404bc:	55                   	push   %rbp
  3404bd:	53                   	push   %rbx
  3404be:	48 89 fd             	mov    %rdi,%rbp
  3404c1:	48 83 ec 78          	sub    $0x78,%rsp
  3404c5:	89 f3                	mov    %esi,%ebx
  3404c7:	64 48 8b 04 25 28 00 00 00 	mov    %fs:0x28,%rax
  3404d0:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  3404d5:	31 c0                	xor    %eax,%eax
  3404d7:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  3404dc:	8b 87 cc 00 00 00    	mov    0xcc(%rdi),%eax
  3404e2:	39 c3                	cmp    %eax,%ebx
  3404e4:	0f 83 97 02 00 00    	jae    340781 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x2d1>
  3404ea:	85 db                	test   %ebx,%ebx
  3404ec:	0f 85 1e 02 00 00    	jne    340710 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x260>
  3404f2:	48 8b 17             	mov    (%rdi),%rdx
  3404f5:	48 85 d2             	test   %rdx,%rdx
  3404f8:	0f 84 12 02 00 00    	je     340710 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x260>
  3404fe:	0f b7 72 26          	movzwl 0x26(%rdx),%esi
  340502:	48 8b 0d 37 79 15 00 	mov    0x157937(%rip),%rcx        # 497e40 <_ZN4tomo12_GLOBAL__N_116g_metadata_by_idE>
  340509:	48 8b 15 38 79 15 00 	mov    0x157938(%rip),%rdx        # 497e48 <_ZN4tomo12_GLOBAL__N_116g_metadata_by_idE+0x8>
  340510:	48 29 ca             	sub    %rcx,%rdx
  340513:	48 c1 fa 03          	sar    $0x3,%rdx
  340517:	48 39 d6             	cmp    %rdx,%rsi
  34051a:	0f 83 f0 04 00 00    	jae    340a10 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x560>
  340520:	4c 8b 24 f1          	mov    (%rcx,%rsi,8),%r12
  340524:	e9 0b 02 00 00       	jmp    340734 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x284>
  340529:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  340530:	3b 9f cc 00 00 00    	cmp    0xcc(%rdi),%ebx
  340536:	0f 83 45 02 00 00    	jae    340781 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x2d1>
  34053c:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
  340543:	41 89 dd             	mov    %ebx,%r13d
  340546:	48 85 c0             	test   %rax,%rax
  340549:	0f 84 61 02 00 00    	je     3407b0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x300>
  34054f:	4c 89 ea             	mov    %r13,%rdx
  340552:	48 c1 e2 04          	shl    $0x4,%rdx
  340556:	48 01 d0             	add    %rdx,%rax
  340559:	48 8b 38             	mov    (%rax),%rdi
  34055c:	48 8b 70 08          	mov    0x8(%rax),%rsi
  340560:	ff c3                	inc    %ebx
  340562:	e8 e9 e1 ff ff       	call   33e750 <_ZN4tomo23command_metadata_lookupENS_5SliceE>
  340567:	49 89 c4             	mov    %rax,%r12
  34056a:	3b 9d cc 00 00 00    	cmp    0xcc(%rbp),%ebx
  340570:	0f 83 6a 01 00 00    	jae    3406e0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x230>
  340576:	48 8b 85 c0 00 00 00 	mov    0xc0(%rbp),%rax
  34057d:	48 85 c0             	test   %rax,%rax
  340580:	0f 84 1a 02 00 00    	je     3407a0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x2f0>
  340586:	49 c1 e5 04          	shl    $0x4,%r13
  34058a:	49 01 c5             	add    %rax,%r13
  34058d:	4d 8b 7d 00          	mov    0x0(%r13),%r15
  340591:	45 8b 75 08          	mov    0x8(%r13),%r14d
  340595:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
  34059a:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  34059f:	4d 85 ff             	test   %r15,%r15
  3405a2:	75 09                	jne    3405ad <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0xfd>
  3405a4:	4d 85 f6             	test   %r14,%r14
  3405a7:	0f 85 48 05 00 00    	jne    340af5 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x645>
  3405ad:	49 83 fe 0f          	cmp    $0xf,%r14
  3405b1:	0f 87 e9 02 00 00    	ja     3408a0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x3f0>
  3405b7:	49 83 fe 01          	cmp    $0x1,%r14
  3405bb:	0f 84 0f 03 00 00    	je     3408d0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x420>
  3405c1:	4d 85 f6             	test   %r14,%r14
  3405c4:	0f 85 fd 04 00 00    	jne    340ac7 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x617>
  3405ca:	4c 89 e8             	mov    %r13,%rax
  3405cd:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  3405d2:	42 c6 04 30 00       	movb   $0x0,(%rax,%r14,1)
  3405d7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  3405dc:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  3405e1:	4c 8d 70 01          	lea    0x1(%rax),%r14
  3405e5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  3405ea:	4d 39 ef             	cmp    %r13,%r15
  3405ed:	0f 84 2d 04 00 00    	je     340a20 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x570>
  3405f3:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  3405f8:	4c 39 f0             	cmp    %r14,%rax
  3405fb:	0f 82 1f 03 00 00    	jb     340920 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x470>
  340601:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  340606:	41 c6 04 07 7c       	movb   $0x7c,(%r15,%rax,1)
  34060b:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  340610:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  340615:	42 c6 04 30 00       	movb   $0x0,(%rax,%r14,1)
  34061a:	48 8b 85 c0 00 00 00 	mov    0xc0(%rbp),%rax
  340621:	48 85 c0             	test   %rax,%rax
  340624:	0f 84 d6 02 00 00    	je     340900 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x450>
  34062a:	48 c1 e3 04          	shl    $0x4,%rbx
  34062e:	48 01 d8             	add    %rbx,%rax
  340631:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  340636:	44 8b 40 08          	mov    0x8(%rax),%r8d
  34063a:	48 8b 08             	mov    (%rax),%rcx
  34063d:	48 b8 ff ff ff ff ff ff ff 7f 	movabs $0x7fffffffffffffff,%rax
  340647:	48 29 f0             	sub    %rsi,%rax
  34064a:	4c 39 c0             	cmp    %r8,%rax
  34064d:	0f 82 81 04 00 00    	jb     340ad4 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x624>
  340653:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  340658:	49 8d 1c 30          	lea    (%r8,%rsi,1),%rbx
  34065c:	4c 39 ef             	cmp    %r13,%rdi
  34065f:	0f 84 0b 04 00 00    	je     340a70 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x5c0>
  340665:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  34066a:	48 39 d8             	cmp    %rbx,%rax
  34066d:	0f 82 6d 02 00 00    	jb     3408e0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x430>
  340673:	4d 85 c0             	test   %r8,%r8
  340676:	74 1d                	je     340695 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x1e5>
  340678:	48 01 f7             	add    %rsi,%rdi
  34067b:	49 83 f8 01          	cmp    $0x1,%r8
  34067f:	0f 84 4b 03 00 00    	je     3409d0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x520>
  340685:	4c 89 c2             	mov    %r8,%rdx
  340688:	48 89 ce             	mov    %rcx,%rsi
  34068b:	e8 d0 2c cd ff       	call   13360 <memcpy@plt>
  340690:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  340695:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
  34069a:	c6 04 1f 00          	movb   $0x0,(%rdi,%rbx,1)
  34069e:	8b 74 24 28          	mov    0x28(%rsp),%esi
  3406a2:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  3406a7:	e8 a4 e0 ff ff       	call   33e750 <_ZN4tomo23command_metadata_lookupENS_5SliceE>
  3406ac:	48 89 c3             	mov    %rax,%rbx
  3406af:	48 85 c0             	test   %rax,%rax
  3406b2:	0f 84 08 01 00 00    	je     3407c0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x310>
  3406b8:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  3406bd:	4c 39 ef             	cmp    %r13,%rdi
  3406c0:	74 0e                	je     3406d0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x220>
  3406c2:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  3406c7:	48 8d 70 01          	lea    0x1(%rax),%rsi
  3406cb:	e8 c0 de ce ff       	call   2e590 <_ZdlPvm>
  3406d0:	49 89 dc             	mov    %rbx,%r12
  3406d3:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  3406de:	66 90                	xchg   %ax,%ax
  3406e0:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  3406e5:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  3406ee:	0f 85 db 03 00 00    	jne    340acf <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x61f>
  3406f4:	48 83 c4 78          	add    $0x78,%rsp
  3406f8:	4c 89 e0             	mov    %r12,%rax
  3406fb:	5b                   	pop    %rbx
  3406fc:	5d                   	pop    %rbp
  3406fd:	41 5c                	pop    %r12
  3406ff:	41 5d                	pop    %r13
  340701:	41 5e                	pop    %r14
  340703:	41 5f                	pop    %r15
  340705:	c3                   	ret
  340706:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
  340710:	48 8b 85 c0 00 00 00 	mov    0xc0(%rbp),%rax
  340717:	89 da                	mov    %ebx,%edx
  340719:	48 85 c0             	test   %rax,%rax
  34071c:	74 72                	je     340790 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x2e0>
  34071e:	48 c1 e2 04          	shl    $0x4,%rdx
  340722:	48 01 d0             	add    %rdx,%rax
  340725:	48 8b 38             	mov    (%rax),%rdi
  340728:	48 8b 70 08          	mov    0x8(%rax),%rsi
  34072c:	e8 1f e0 ff ff       	call   33e750 <_ZN4tomo23command_metadata_lookupENS_5SliceE>
  340731:	49 89 c4             	mov    %rax,%r12
  340734:	4d 85 e4             	test   %r12,%r12
  340737:	74 0c                	je     340745 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x295>
  340739:	4c 89 e7             	mov    %r12,%rdi
  34073c:	e8 ff da ff ff       	call   33e240 <_ZN4tomo12_GLOBAL__N_111child_countERKNS_15CommandMetadataE>
  340741:	85 c0                	test   %eax,%eax
  340743:	74 9b                	je     3406e0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x230>
  340745:	8b 85 cc 00 00 00    	mov    0xcc(%rbp),%eax
  34074b:	8d 53 01             	lea    0x1(%rbx),%edx
  34074e:	39 c2                	cmp    %eax,%edx
  340750:	73 8e                	jae    3406e0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x230>
  340752:	48 8b 85 c0 00 00 00 	mov    0xc0(%rbp),%rax
  340759:	48 c1 e3 04          	shl    $0x4,%rbx
  34075d:	48 85 c0             	test   %rax,%rax
  340760:	0f 84 3a 02 00 00    	je     3409a0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x4f0>
  340766:	48 01 c3             	add    %rax,%rbx
  340769:	48 8b 0b             	mov    (%rbx),%rcx
  34076c:	8b 5b 08             	mov    0x8(%rbx),%ebx
  34076f:	48 c1 e2 04          	shl    $0x4,%rdx
  340773:	48 01 d0             	add    %rdx,%rax
  340776:	48 8b 30             	mov    (%rax),%rsi
  340779:	8b 68 08             	mov    0x8(%rax),%ebp
  34077c:	83 fb 1c             	cmp    $0x1c,%ebx
  34077f:	76 7f                	jbe    340800 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x350>
  340781:	45 31 e4             	xor    %r12d,%r12d
  340784:	e9 57 ff ff ff       	jmp    3406e0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x230>
  340789:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  340790:	48 83 c2 0d          	add    $0xd,%rdx
  340794:	48 c1 e2 04          	shl    $0x4,%rdx
  340798:	48 8d 44 15 00       	lea    0x0(%rbp,%rdx,1),%rax
  34079d:	eb 86                	jmp    340725 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x275>
  34079f:	90                   	nop
  3407a0:	49 83 c5 0d          	add    $0xd,%r13
  3407a4:	49 c1 e5 04          	shl    $0x4,%r13
  3407a8:	49 01 ed             	add    %rbp,%r13
  3407ab:	e9 dd fd ff ff       	jmp    34058d <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0xdd>
  3407b0:	49 8d 45 0d          	lea    0xd(%r13),%rax
  3407b4:	48 c1 e0 04          	shl    $0x4,%rax
  3407b8:	48 01 f8             	add    %rdi,%rax
  3407bb:	e9 99 fd ff ff       	jmp    340559 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0xa9>
  3407c0:	4d 85 e4             	test   %r12,%r12
  3407c3:	74 10                	je     3407d5 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x325>
  3407c5:	4c 89 e7             	mov    %r12,%rdi
  3407c8:	e8 73 da ff ff       	call   33e240 <_ZN4tomo12_GLOBAL__N_111child_countERKNS_15CommandMetadataE>
  3407cd:	85 c0                	test   %eax,%eax
  3407cf:	0f 85 e3 fe ff ff    	jne    3406b8 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x208>
  3407d5:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  3407da:	4c 39 ef             	cmp    %r13,%rdi
  3407dd:	0f 84 fd fe ff ff    	je     3406e0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x230>
  3407e3:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  3407e8:	48 8d 70 01          	lea    0x1(%rax),%rsi
  3407ec:	e8 9f dd ce ff       	call   2e590 <_ZdlPvm>
  3407f1:	e9 ea fe ff ff       	jmp    3406e0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x230>
  3407f6:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
  340800:	89 da                	mov    %ebx,%edx
  340802:	b8 1d 00 00 00       	mov    $0x1d,%eax
  340807:	41 89 e8             	mov    %ebp,%r8d
  34080a:	48 29 d0             	sub    %rdx,%rax
  34080d:	49 39 c0             	cmp    %rax,%r8
  340810:	0f 83 6b ff ff ff    	jae    340781 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x2d1>
  340816:	4c 8d 64 24 40       	lea    0x40(%rsp),%r12
  34081b:	48 89 c8             	mov    %rcx,%rax
  34081e:	4c 89 e7             	mov    %r12,%rdi
  340821:	83 fb 08             	cmp    $0x8,%ebx
  340824:	0f 83 76 02 00 00    	jae    340aa0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x5f0>
  34082a:	31 c9                	xor    %ecx,%ecx
  34082c:	f6 c3 04             	test   $0x4,%bl
  34082f:	74 09                	je     34083a <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x38a>
  340831:	8b 08                	mov    (%rax),%ecx
  340833:	89 0f                	mov    %ecx,(%rdi)
  340835:	b9 04 00 00 00       	mov    $0x4,%ecx
  34083a:	f6 c3 02             	test   $0x2,%bl
  34083d:	74 0e                	je     34084d <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x39d>
  34083f:	44 0f b7 0c 08       	movzwl (%rax,%rcx,1),%r9d
  340844:	66 44 89 0c 0f       	mov    %r9w,(%rdi,%rcx,1)
  340849:	48 83 c1 02          	add    $0x2,%rcx
  34084d:	f6 c3 01             	test   $0x1,%bl
  340850:	74 07                	je     340859 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x3a9>
  340852:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
  340856:	88 04 0f             	mov    %al,(%rdi,%rcx,1)
  340859:	c6 44 14 40 7c       	movb   $0x7c,0x40(%rsp,%rdx,1)
  34085e:	b9 1d 00 00 00       	mov    $0x1d,%ecx
  340863:	48 ff c2             	inc    %rdx
  340866:	49 8d 3c 14          	lea    (%r12,%rdx,1),%rdi
  34086a:	48 29 d1             	sub    %rdx,%rcx
  34086d:	4c 89 c2             	mov    %r8,%rdx
  340870:	e8 9b 31 cd ff       	call   13a10 <__memcpy_chk@plt>
  340875:	4c 89 e7             	mov    %r12,%rdi
  340878:	8d 74 1d 01          	lea    0x1(%rbp,%rbx,1),%esi
  34087c:	e8 cf de ff ff       	call   33e750 <_ZN4tomo23command_metadata_lookupENS_5SliceE>
  340881:	49 89 c4             	mov    %rax,%r12
  340884:	48 85 c0             	test   %rax,%rax
  340887:	0f 85 53 fe ff ff    	jne    3406e0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x230>
  34088d:	e9 ef fe ff ff       	jmp    340781 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x2d1>
  340892:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  34089d:	0f 1f 00             	nopl   (%rax)
  3408a0:	49 8d 7e 01          	lea    0x1(%r14),%rdi
  3408a4:	e8 57 db ce ff       	call   2e400 <_Znwm>
  3408a9:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
  3408ae:	48 89 c7             	mov    %rax,%rdi
  3408b1:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  3408b6:	4c 89 f2             	mov    %r14,%rdx
  3408b9:	4c 89 fe             	mov    %r15,%rsi
  3408bc:	e8 9f 2a cd ff       	call   13360 <memcpy@plt>
  3408c1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  3408c6:	e9 02 fd ff ff       	jmp    3405cd <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x11d>
  3408cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  3408d0:	41 0f b6 07          	movzbl (%r15),%eax
  3408d4:	88 44 24 30          	mov    %al,0x30(%rsp)
  3408d8:	e9 ed fc ff ff       	jmp    3405ca <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x11a>
  3408dd:	0f 1f 00             	nopl   (%rax)
  3408e0:	4c 8d 7c 24 20       	lea    0x20(%rsp),%r15
  3408e5:	31 d2                	xor    %edx,%edx
  3408e7:	4c 89 ff             	mov    %r15,%rdi
  3408ea:	e8 b1 95 cf ff       	call   39ea0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm>
  3408ef:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  3408f4:	e9 9c fd ff ff       	jmp    340695 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x1e5>
  3408f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  340900:	48 83 c3 0d          	add    $0xd,%rbx
  340904:	48 c1 e3 04          	shl    $0x4,%rbx
  340908:	48 8d 44 1d 00       	lea    0x0(%rbp,%rbx,1),%rax
  34090d:	e9 1f fd ff ff       	jmp    340631 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x181>
  340912:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  34091d:	0f 1f 00             	nopl   (%rax)
  340920:	4d 85 f6             	test   %r14,%r14
  340923:	0f 88 e8 01 00 00    	js     340b11 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x661>
  340929:	48 01 c0             	add    %rax,%rax
  34092c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  340931:	49 39 c6             	cmp    %rax,%r14
  340934:	0f 82 a6 00 00 00    	jb     3409e0 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x530>
  34093a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  34093f:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
  340944:	48 83 c7 02          	add    $0x2,%rdi
  340948:	0f 88 9f 00 00 00    	js     3409ed <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x53d>
  34094e:	4c 8d 7c 24 20       	lea    0x20(%rsp),%r15
  340953:	e8 a8 da ce ff       	call   2e400 <_Znwm>
  340958:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
  34095e:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  340963:	49 89 c7             	mov    %rax,%r15
  340966:	0f 85 14 01 00 00    	jne    340a80 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x5d0>
  34096c:	4c 39 e9             	cmp    %r13,%rcx
  34096f:	74 11                	je     340982 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x4d2>
  340971:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  340976:	48 89 cf             	mov    %rcx,%rdi
  340979:	48 8d 70 01          	lea    0x1(%rax),%rsi
  34097d:	e8 0e dc ce ff       	call   2e590 <_ZdlPvm>
  340982:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  340987:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
  34098c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  340991:	e9 6b fc ff ff       	jmp    340601 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x151>
  340996:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
  3409a0:	48 83 c2 0d          	add    $0xd,%rdx
  3409a4:	48 8d 44 1d 00       	lea    0x0(%rbp,%rbx,1),%rax
  3409a9:	48 c1 e2 04          	shl    $0x4,%rdx
  3409ad:	48 8b 88 d0 00 00 00 	mov    0xd0(%rax),%rcx
  3409b4:	8b 98 d8 00 00 00    	mov    0xd8(%rax),%ebx
  3409ba:	48 8d 44 15 00       	lea    0x0(%rbp,%rdx,1),%rax
  3409bf:	e9 b2 fd ff ff       	jmp    340776 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x2c6>
  3409c4:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  3409cf:	90                   	nop
  3409d0:	0f b6 01             	movzbl (%rcx),%eax
  3409d3:	88 07                	mov    %al,(%rdi)
  3409d5:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  3409da:	e9 b6 fc ff ff       	jmp    340695 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x1e5>
  3409df:	90                   	nop
  3409e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
  3409e4:	48 85 c0             	test   %rax,%rax
  3409e7:	0f 89 61 ff ff ff    	jns    34094e <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x49e>
  3409ed:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  3409f2:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  3409fb:	0f 85 ce 00 00 00    	jne    340acf <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x61f>
  340a01:	4c 8d 7c 24 20       	lea    0x20(%rsp),%r15
  340a06:	e8 95 29 cd ff       	call   133a0 <_ZSt17__throw_bad_allocv@plt>
  340a0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  340a10:	45 31 e4             	xor    %r12d,%r12d
  340a13:	e9 33 fd ff ff       	jmp    34074b <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x29b>
  340a18:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  340a20:	49 83 fe 10          	cmp    $0x10,%r14
  340a24:	0f 85 d7 fb ff ff    	jne    340601 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x151>
  340a2a:	bf 1f 00 00 00       	mov    $0x1f,%edi
  340a2f:	4c 8d 7c 24 20       	lea    0x20(%rsp),%r15
  340a34:	e8 c7 d9 ce ff       	call   2e400 <_Znwm>
  340a39:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  340a3e:	49 89 c7             	mov    %rax,%r15
  340a41:	48 c7 44 24 10 1e 00 00 00 	movq   $0x1e,0x10(%rsp)
  340a4a:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  340a4f:	48 89 ce             	mov    %rcx,%rsi
  340a52:	4c 89 ff             	mov    %r15,%rdi
  340a55:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  340a5a:	e8 01 29 cd ff       	call   13360 <memcpy@plt>
  340a5f:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  340a64:	e9 03 ff ff ff       	jmp    34096c <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x4bc>
  340a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  340a70:	b8 0f 00 00 00       	mov    $0xf,%eax
  340a75:	e9 f0 fb ff ff       	jmp    34066a <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x1ba>
  340a7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  340a80:	48 83 7c 24 08 01    	cmpq   $0x1,0x8(%rsp)
  340a86:	75 c2                	jne    340a4a <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x59a>
  340a88:	0f b6 01             	movzbl (%rcx),%eax
  340a8b:	41 88 07             	mov    %al,(%r15)
  340a8e:	e9 d9 fe ff ff       	jmp    34096c <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x4bc>
  340a93:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  340a9e:	66 90                	xchg   %ax,%ax
  340aa0:	41 89 da             	mov    %ebx,%r10d
  340aa3:	31 c0                	xor    %eax,%eax
  340aa5:	41 83 e2 f8          	and    $0xfffffff8,%r10d
  340aa9:	89 c7                	mov    %eax,%edi
  340aab:	83 c0 08             	add    $0x8,%eax
  340aae:	4c 8b 0c 39          	mov    (%rcx,%rdi,1),%r9
  340ab2:	4d 89 0c 3c          	mov    %r9,(%r12,%rdi,1)
  340ab6:	44 39 d0             	cmp    %r10d,%eax
  340ab9:	72 ee                	jb     340aa9 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x5f9>
  340abb:	49 8d 3c 04          	lea    (%r12,%rax,1),%rdi
  340abf:	48 01 c8             	add    %rcx,%rax
  340ac2:	e9 63 fd ff ff       	jmp    34082a <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x37a>
  340ac7:	4c 89 ef             	mov    %r13,%rdi
  340aca:	e9 e7 fd ff ff       	jmp    3408b6 <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x406>
  340acf:	e8 cc 2b cd ff       	call   136a0 <__stack_chk_fail@plt>
  340ad4:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  340ad9:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  340ae2:	75 eb                	jne    340acf <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x61f>
  340ae4:	48 8d 3d e5 c5 04 00 	lea    0x4c5e5(%rip),%rdi        # 38d0d0 <_IO_stdin_used+0xd0>
  340aeb:	4c 8d 7c 24 20       	lea    0x20(%rsp),%r15
  340af0:	e8 ab 30 cd ff       	call   13ba0 <_ZSt20__throw_length_errorPKc@plt>
  340af5:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  340afa:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  340b03:	75 ca                	jne    340acf <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x61f>
  340b05:	48 8d 3d b4 1b 05 00 	lea    0x51bb4(%rip),%rdi        # 3926c0 <_IO_stdin_used+0x56c0>
  340b0c:	e8 df 27 cd ff       	call   132f0 <_ZSt19__throw_logic_errorPKc@plt>
  340b11:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  340b16:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  340b1f:	75 ae                	jne    340acf <_ZN4tomo24command_metadata_resolveERNS_2OpEj+0x61f>
  340b21:	48 8d 3d 7c c5 04 00 	lea    0x4c57c(%rip),%rdi        # 38d0a4 <_IO_stdin_used+0xa4>
  340b28:	4c 8d 7c 24 20       	lea    0x20(%rsp),%r15
  340b2d:	e8 6e 30 cd ff       	call   13ba0 <_ZSt20__throw_length_errorPKc@plt>
  340b32:	f3 0f 1e fa          	endbr64
  340b36:	48 89 c3             	mov    %rax,%rbx
  340b39:	e9 95 62 ce ff       	jmp    26dd3 <_ZN4tomo24command_metadata_resolveERNS_2OpEj.cold>

Disassembly of section .rlfence:

Disassembly of section .fini:
