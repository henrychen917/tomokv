
/home/user/Projects/cx-exbatch/build/exbatch/POST/tomokv:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

00000000006a1f50 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE>:
  6a1f50:	f3 0f 1e fa          	endbr64
  6a1f54:	55                   	push   %rbp
  6a1f55:	48 89 e5             	mov    %rsp,%rbp
  6a1f58:	41 57                	push   %r15
  6a1f5a:	41 56                	push   %r14
  6a1f5c:	41 55                	push   %r13
  6a1f5e:	41 54                	push   %r12
  6a1f60:	53                   	push   %rbx
  6a1f61:	49 89 f4             	mov    %rsi,%r12
  6a1f64:	48 89 fb             	mov    %rdi,%rbx
  6a1f67:	48 83 ec 68          	sub    $0x68,%rsp
  6a1f6b:	64 48 8b 04 25 28 00 00 00 	mov    %fs:0x28,%rax
  6a1f74:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  6a1f79:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6a1f7d:	c6 44 24 20 00       	movb   $0x0,0x20(%rsp)
  6a1f82:	48 c7 44 24 18 00 00 00 00 	movq   $0x0,0x18(%rsp)
  6a1f8b:	8b 00                	mov    (%rax),%eax
  6a1f8d:	48 05 ee 05 00 00    	add    $0x5ee,%rax
  6a1f93:	48 c1 e0 06          	shl    $0x6,%rax
  6a1f97:	48 03 07             	add    (%rdi),%rax
  6a1f9a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6a1f9f:	48 8b 10             	mov    (%rax),%rdx
  6a1fa2:	48 89 d1             	mov    %rdx,%rcx
  6a1fa5:	83 e1 01             	and    $0x1,%ecx
  6a1fa8:	48 89 ce             	mov    %rcx,%rsi
  6a1fab:	48 83 f6 01          	xor    $0x1,%rsi
  6a1faf:	40 88 74 24 20       	mov    %sil,0x20(%rsp)
  6a1fb4:	80 64 24 20 01       	andb   $0x1,0x20(%rsp)
  6a1fb9:	48 85 c9             	test   %rcx,%rcx
  6a1fbc:	0f 84 1e 02 00 00    	je     6a21e0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x290>
  6a1fc2:	49 63 44 24 10       	movslq 0x10(%r12),%rax
  6a1fc7:	85 c0                	test   %eax,%eax
  6a1fc9:	79 34                	jns    6a1fff <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xaf>
  6a1fcb:	49 8b 0c 24          	mov    (%r12),%rcx
  6a1fcf:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6a1fd4:	48 85 c9             	test   %rcx,%rcx
  6a1fd7:	0f 84 83 00 00 00    	je     6a2060 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x110>
  6a1fdd:	89 c2                	mov    %eax,%edx
  6a1fdf:	83 e0 07             	and    $0x7,%eax
  6a1fe2:	c1 ea 03             	shr    $0x3,%edx
  6a1fe5:	83 e2 07             	and    $0x7,%edx
  6a1fe8:	48 69 c0 50 01 00 00 	imul   $0x150,%rax,%rax
  6a1fef:	48 03 84 d1 80 00 00 00 	add    0x80(%rcx,%rdx,8),%rax
  6a1ff7:	48 63 40 08          	movslq 0x8(%rax),%rax
  6a1ffb:	85 c0                	test   %eax,%eax
  6a1ffd:	78 61                	js     6a2060 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x110>
  6a1fff:	48 8b 13             	mov    (%rbx),%rdx
  6a2002:	48 05 6e 44 00 00    	add    $0x446e,%rax
  6a2008:	8b 14 82             	mov    (%rdx,%rax,4),%edx
  6a200b:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6a200f:	3b 10                	cmp    (%rax),%edx
  6a2011:	74 4d                	je     6a2060 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x110>
  6a2013:	4c 89 e6             	mov    %r12,%rsi
  6a2016:	48 89 df             	mov    %rbx,%rdi
  6a2019:	e8 c2 a6 ff ff       	call   69c6e0 <_ZN4tomo7ExLoopTILb1EE19post_forwarded_taskILb0EEEbRKNS_4TaskEj>
  6a201e:	84 c0                	test   %al,%al
  6a2020:	0f 84 1a 04 00 00    	je     6a2440 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x4f0>
  6a2026:	41 be 01 00 00 00    	mov    $0x1,%r14d
  6a202c:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
  6a2031:	0f 85 c9 01 00 00    	jne    6a2200 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x2b0>
  6a2037:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  6a203c:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  6a2045:	0f 85 ca 0b 00 00    	jne    6a2c15 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xcc5>
  6a204b:	48 83 c4 68          	add    $0x68,%rsp
  6a204f:	44 89 f0             	mov    %r14d,%eax
  6a2052:	5b                   	pop    %rbx
  6a2053:	41 5c                	pop    %r12
  6a2055:	41 5d                	pop    %r13
  6a2057:	41 5e                	pop    %r14
  6a2059:	41 5f                	pop    %r15
  6a205b:	5d                   	pop    %rbp
  6a205c:	c3                   	ret
  6a205d:	0f 1f 00             	nopl   (%rax)
  6a2060:	4c 89 e7             	mov    %r12,%rdi
  6a2063:	e8 78 2a e0 ff       	call   4a4ae0 <_ZN4tomo17multi_task_taggedERKNS_4TaskE>
  6a2068:	48 8b 0b             	mov    (%rbx),%rcx
  6a206b:	89 c6                	mov    %eax,%esi
  6a206d:	4d 63 74 24 10       	movslq 0x10(%r12),%r14
  6a2072:	0f b6 93 8a 01 00 00 	movzbl 0x18a(%rbx),%edx
  6a2079:	48 8b 83 58 01 00 00 	mov    0x158(%rbx),%rax
  6a2080:	48 8b 89 c8 03 01 00 	mov    0x103c8(%rcx),%rcx
  6a2087:	40 84 f6             	test   %sil,%sil
  6a208a:	0f 84 90 01 00 00    	je     6a2220 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x2d0>
  6a2090:	4e 8b 2c f1          	mov    (%rcx,%r14,8),%r13
  6a2094:	49 89 45 10          	mov    %rax,0x10(%r13)
  6a2098:	49 89 85 c0 01 00 00 	mov    %rax,0x1c0(%r13)
  6a209f:	41 88 95 c8 01 00 00 	mov    %dl,0x1c8(%r13)
  6a20a6:	49 8b 04 24          	mov    (%r12),%rax
  6a20aa:	48 85 c0             	test   %rax,%rax
  6a20ad:	0f 84 ad 03 00 00    	je     6a2460 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x510>
  6a20b3:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
  6a20b8:	48 8b bb 40 02 00 00 	mov    0x240(%rbx),%rdi
  6a20bf:	45 8b 74 24 10       	mov    0x10(%r12),%r14d
  6a20c4:	89 ca                	mov    %ecx,%edx
  6a20c6:	c1 ea 03             	shr    $0x3,%edx
  6a20c9:	83 e2 07             	and    $0x7,%edx
  6a20cc:	48 8b 84 d0 80 00 00 00 	mov    0x80(%rax,%rdx,8),%rax
  6a20d4:	48 39 bb 60 02 00 00 	cmp    %rdi,0x260(%rbx)
  6a20db:	0f 85 7f 07 00 00    	jne    6a2860 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x910>
  6a20e1:	48 8b bb e0 02 00 00 	mov    0x2e0(%rbx),%rdi
  6a20e8:	48 39 bb 00 03 00 00 	cmp    %rdi,0x300(%rbx)
  6a20ef:	0f 85 6b 07 00 00    	jne    6a2860 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x910>
  6a20f5:	49 8b 85 00 01 00 00 	mov    0x100(%r13),%rax
  6a20fc:	48 85 c0             	test   %rax,%rax
  6a20ff:	0f 84 4b 04 00 00    	je     6a2550 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x600>
  6a2105:	48 83 b8 10 02 00 00 00 	cmpq   $0x0,0x210(%rax)
  6a210d:	0f 84 3d 04 00 00    	je     6a2550 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x600>
  6a2113:	49 8b 14 24          	mov    (%r12),%rdx
  6a2117:	8b 88 10 02 00 00    	mov    0x210(%rax),%ecx
  6a211d:	4c 8b ba a8 07 00 00 	mov    0x7a8(%rdx),%r15
  6a2124:	85 c9                	test   %ecx,%ecx
  6a2126:	0f 84 84 08 00 00    	je     6a29b0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xa60>
  6a212c:	4c 89 fa             	mov    %r15,%rdx
  6a212f:	48 b9 cd 8c 55 ed d7 af 51 ff 	movabs $0xff51afd7ed558ccd,%rcx
  6a2139:	48 c1 ea 21          	shr    $0x21,%rdx
  6a213d:	4c 31 fa             	xor    %r15,%rdx
  6a2140:	48 0f af d1          	imul   %rcx,%rdx
  6a2144:	48 89 d1             	mov    %rdx,%rcx
  6a2147:	48 c1 e9 21          	shr    $0x21,%rcx
  6a214b:	48 31 ca             	xor    %rcx,%rdx
  6a214e:	48 b9 53 ec 85 1a fe b9 ce c4 	movabs $0xc4ceb9fe1a85ec53,%rcx
  6a2158:	48 0f af d1          	imul   %rcx,%rdx
  6a215c:	48 89 d1             	mov    %rdx,%rcx
  6a215f:	48 c1 e9 21          	shr    $0x21,%rcx
  6a2163:	48 31 ca             	xor    %rcx,%rdx
  6a2166:	83 e2 3f             	and    $0x3f,%edx
  6a2169:	4c 8b 74 d0 10       	mov    0x10(%rax,%rdx,8),%r14
  6a216e:	4d 85 f6             	test   %r14,%r14
  6a2171:	75 1a                	jne    6a218d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x23d>
  6a2173:	e9 d8 03 00 00       	jmp    6a2550 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x600>
  6a2178:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6a2180:	4d 8b 76 10          	mov    0x10(%r14),%r14
  6a2184:	4d 85 f6             	test   %r14,%r14
  6a2187:	0f 84 c3 03 00 00    	je     6a2550 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x600>
  6a218d:	49 8b 76 30          	mov    0x30(%r14),%rsi
  6a2191:	48 85 f6             	test   %rsi,%rsi
  6a2194:	74 ea                	je     6a2180 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x230>
  6a2196:	4d 3b 7e 50          	cmp    0x50(%r14),%r15
  6a219a:	75 e4                	jne    6a2180 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x230>
  6a219c:	4c 89 e7             	mov    %r12,%rdi
  6a219f:	e8 4c 29 e0 ff       	call   4a4af0 <_ZN4tomo21multi_task_owns_epochERKNS_4TaskEPKv>
  6a21a4:	84 c0                	test   %al,%al
  6a21a6:	75 d8                	jne    6a2180 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x230>
  6a21a8:	49 8b 46 30          	mov    0x30(%r14),%rax
  6a21ac:	48 8b 00             	mov    (%rax),%rax
  6a21af:	48 85 c0             	test   %rax,%rax
  6a21b2:	75 cc                	jne    6a2180 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x230>
  6a21b4:	49 8b 46 40          	mov    0x40(%r14),%rax
  6a21b8:	48 85 c0             	test   %rax,%rax
  6a21bb:	74 07                	je     6a21c4 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x274>
  6a21bd:	0f b6 00             	movzbl (%rax),%eax
  6a21c0:	84 c0                	test   %al,%al
  6a21c2:	75 bc                	jne    6a2180 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x230>
  6a21c4:	48 8d bb 30 02 00 00 	lea    0x230(%rbx),%rdi
  6a21cb:	4c 89 e6             	mov    %r12,%rsi
  6a21ce:	49 ff 85 58 04 00 00 	incq   0x458(%r13)
  6a21d5:	e8 a6 d8 d8 ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  6a21da:	e9 47 fe ff ff       	jmp    6a2026 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xd6>
  6a21df:	90                   	nop
  6a21e0:	48 8d 4a 02          	lea    0x2(%rdx),%rcx
  6a21e4:	48 ff c2             	inc    %rdx
  6a21e7:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  6a21ec:	48 89 10             	mov    %rdx,(%rax)
  6a21ef:	e9 ce fd ff ff       	jmp    6a1fc2 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x72>
  6a21f4:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a21ff:	90                   	nop
  6a2200:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6a2205:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  6a220a:	48 89 10             	mov    %rdx,(%rax)
  6a220d:	e9 25 fe ff ff       	jmp    6a2037 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xe7>
  6a2212:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a221d:	0f 1f 00             	nopl   (%rax)
  6a2220:	49 8b 3c 24          	mov    (%r12),%rdi
  6a2224:	48 85 ff             	test   %rdi,%rdi
  6a2227:	0f 84 63 04 00 00    	je     6a2690 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x740>
  6a222d:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
  6a2232:	44 89 ee             	mov    %r13d,%esi
  6a2235:	41 83 e5 07          	and    $0x7,%r13d
  6a2239:	c1 ee 03             	shr    $0x3,%esi
  6a223c:	83 e6 07             	and    $0x7,%esi
  6a223f:	4d 69 ed 50 01 00 00 	imul   $0x150,%r13,%r13
  6a2246:	4c 03 ac f7 80 00 00 00 	add    0x80(%rdi,%rsi,8),%r13
  6a224e:	45 85 f6             	test   %r14d,%r14d
  6a2251:	0f 88 e9 02 00 00    	js     6a2540 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x5f0>
  6a2257:	49 63 f6             	movslq %r14d,%rsi
  6a225a:	4c 8b 3c f1          	mov    (%rcx,%rsi,8),%r15
  6a225e:	41 88 97 c8 01 00 00 	mov    %dl,0x1c8(%r15)
  6a2265:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  6a226c:	49 89 47 10          	mov    %rax,0x10(%r15)
  6a2270:	49 89 87 c0 01 00 00 	mov    %rax,0x1c0(%r15)
  6a2277:	0f 85 33 03 00 00    	jne    6a25b0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x660>
  6a227d:	49 83 bd a8 00 00 00 00 	cmpq   $0x0,0xa8(%r13)
  6a2285:	74 0e                	je     6a2295 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x345>
  6a2287:	41 83 bd b4 00 00 00 fc 	cmpl   $0xfffffffc,0xb4(%r13)
  6a228f:	0f 84 8b 03 00 00    	je     6a2620 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x6d0>
  6a2295:	0f b6 05 fd 7a 25 00 	movzbl 0x257afd(%rip),%eax        # 8f9d99 <_ZN4tomo22atomic_tripwire_detail5armedE>
  6a229c:	84 c0                	test   %al,%al
  6a229e:	74 18                	je     6a22b8 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x368>
  6a22a0:	48 83 3d f8 7a 25 00 00 	cmpq   $0x0,0x257af8(%rip)        # 8f9da0 <_ZN4tomo22atomic_tripwire_detail5stateE>
  6a22a8:	74 0e                	je     6a22b8 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x368>
  6a22aa:	4c 89 ea             	mov    %r13,%rdx
  6a22ad:	4c 89 fe             	mov    %r15,%rsi
  6a22b0:	4c 89 e7             	mov    %r12,%rdi
  6a22b3:	e8 d8 fa e2 ff       	call   4d1d90 <_ZN4tomo30xshard_tripwire_fragment_beginERKNS_4TaskERNS_5ShardERNS_2OpE>
  6a22b8:	48 8b 83 40 02 00 00 	mov    0x240(%rbx),%rax
  6a22bf:	48 39 83 60 02 00 00 	cmp    %rax,0x260(%rbx)
  6a22c6:	0f 85 44 05 00 00    	jne    6a2810 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x8c0>
  6a22cc:	48 8b 83 e0 02 00 00 	mov    0x2e0(%rbx),%rax
  6a22d3:	48 39 83 00 03 00 00 	cmp    %rax,0x300(%rbx)
  6a22da:	0f 85 30 05 00 00    	jne    6a2810 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x8c0>
  6a22e0:	48 8b 3b             	mov    (%rbx),%rdi
  6a22e3:	4c 89 e9             	mov    %r13,%rcx
  6a22e6:	4c 89 e2             	mov    %r12,%rdx
  6a22e9:	4c 89 fe             	mov    %r15,%rsi
  6a22ec:	e8 7f 72 e0 ff       	call   4a9570 <_ZN4tomo24xshard_task_should_deferERNS_6ServerERNS_5ShardERKNS_4TaskERNS_2OpE>
  6a22f1:	41 89 c6             	mov    %eax,%r14d
  6a22f4:	84 c0                	test   %al,%al
  6a22f6:	0f 85 e4 03 00 00    	jne    6a26e0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x790>
  6a22fc:	49 8b 44 24 18       	mov    0x18(%r12),%rax
  6a2301:	48 85 c0             	test   %rax,%rax
  6a2304:	0f 84 d6 02 00 00    	je     6a25e0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x690>
  6a230a:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
  6a230e:	41 8b 57 18          	mov    0x18(%r15),%edx
  6a2312:	8b 4f 44             	mov    0x44(%rdi),%ecx
  6a2315:	49 ff 87 e8 03 00 00 	incq   0x3e8(%r15)
  6a231c:	83 fa ff             	cmp    $0xffffffff,%edx
  6a231f:	0f 84 0b 06 00 00    	je     6a2930 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x9e0>
  6a2325:	39 ca                	cmp    %ecx,%edx
  6a2327:	74 07                	je     6a2330 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x3e0>
  6a2329:	49 ff 87 10 04 00 00 	incq   0x410(%r15)
  6a2330:	48 85 c0             	test   %rax,%rax
  6a2333:	0f 84 e7 03 00 00    	je     6a2720 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x7d0>
  6a2339:	8b 0f                	mov    (%rdi),%ecx
  6a233b:	4c 89 ea             	mov    %r13,%rdx
  6a233e:	4c 89 fe             	mov    %r15,%rsi
  6a2341:	4c 89 e7             	mov    %r12,%rdi
  6a2344:	e8 47 76 e3 ff       	call   4d9990 <_ZN4tomo14xshard_executeERKNS_4TaskERNS_5ShardERNS_2OpEj>
  6a2349:	89 c1                	mov    %eax,%ecx
  6a234b:	4c 89 ea             	mov    %r13,%rdx
  6a234e:	4c 89 fe             	mov    %r15,%rsi
  6a2351:	4c 89 e7             	mov    %r12,%rdi
  6a2354:	88 44 24 08          	mov    %al,0x8(%rsp)
  6a2358:	e8 53 5d e3 ff       	call   4d80b0 <_ZN4tomo19xshard_watch_finishERKNS_4TaskERNS_5ShardERNS_2OpENS_17ScatterTaskResultE>
  6a235d:	80 7c 24 08 02       	cmpb   $0x2,0x8(%rsp)
  6a2362:	0f 84 a3 02 00 00    	je     6a260b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x6bb>
  6a2368:	80 7c 24 08 01       	cmpb   $0x1,0x8(%rsp)
  6a236d:	0f 84 b9 fc ff ff    	je     6a202c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xdc>
  6a2373:	8b 83 8c 01 00 00    	mov    0x18c(%rbx),%eax
  6a2379:	85 c0                	test   %eax,%eax
  6a237b:	74 25                	je     6a23a2 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x452>
  6a237d:	c4 e1 f9 6e cb       	vmovq  %rbx,%xmm1
  6a2382:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
  6a2387:	48 8d 15 82 38 ff ff 	lea    -0xc77e(%rip),%rdx        # 695c10 <_ZZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskEENUlPvmE0_4_FUNES6_m>
  6a238e:	4c 89 e7             	mov    %r12,%rdi
  6a2391:	c4 c3 f1 22 c7 01    	vpinsrq $0x1,%r15,%xmm1,%xmm0
  6a2397:	c5 f9 7f 44 24 30    	vmovdqa %xmm0,0x30(%rsp)
  6a239d:	e8 1e 01 e0 ff       	call   4a24c0 <_ZN4tomo24xshard_visit_task_hashesERKNS_4TaskEPvPFvS3_mE>
  6a23a2:	49 8b 87 b0 04 00 00 	mov    0x4b0(%r15),%rax
  6a23a9:	48 85 c0             	test   %rax,%rax
  6a23ac:	0f 85 81 07 00 00    	jne    6a2b33 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xbe3>
  6a23b2:	48 83 bb 80 01 00 00 00 	cmpq   $0x0,0x180(%rbx)
  6a23ba:	48 8d 43 10          	lea    0x10(%rbx),%rax
  6a23be:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6a23c3:	0f 85 30 07 00 00    	jne    6a2af9 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xba9>
  6a23c9:	4c 89 ff             	mov    %r15,%rdi
  6a23cc:	e8 5f 74 d5 ff       	call   3f9830 <_ZN4tomo5Shard12publish_sizeEv>
  6a23d1:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  6a23d5:	48 8b 3b             	mov    (%rbx),%rdi
  6a23d8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6a23dd:	4d 89 e8             	mov    %r13,%r8
  6a23e0:	4c 89 e1             	mov    %r12,%rcx
  6a23e3:	e8 08 ec e3 ff       	call   4e0ff0 <_ZN4tomo15xshard_completeERNS_6ServerERNS_9ThreadCtxERNS_4RingERKNS_4TaskERNS_2OpE>
  6a23e8:	84 c0                	test   %al,%al
  6a23ea:	0f 84 36 fc ff ff    	je     6a2026 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xd6>
  6a23f0:	3c 01                	cmp    $0x1,%al
  6a23f2:	0f 84 34 fc ff ff    	je     6a202c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xdc>
  6a23f8:	3c 02                	cmp    $0x2,%al
  6a23fa:	0f 84 59 07 00 00    	je     6a2b59 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xc09>
  6a2400:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
  6a2406:	0f 84 2d 05 00 00    	je     6a2939 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x9e9>
  6a240c:	48 8b bb 80 01 00 00 	mov    0x180(%rbx),%rdi
  6a2413:	48 85 ff             	test   %rdi,%rdi
  6a2416:	0f 84 ff 00 00 00    	je     6a251b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x5cb>
  6a241c:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6a2420:	49 8b 0c 24          	mov    (%r12),%rcx
  6a2424:	4c 89 ea             	mov    %r13,%rdx
  6a2427:	8b 30                	mov    (%rax),%esi
  6a2429:	e8 e2 a7 f9 ff       	call   63cc10 <_ZN4tomo10AofManager16defer_completionEjRNS_2OpEPNS_6ClientE>
  6a242e:	e9 e0 00 00 00       	jmp    6a2513 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x5c3>
  6a2433:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a243e:	66 90                	xchg   %ax,%ax
  6a2440:	48 8d bb 70 03 00 00 	lea    0x370(%rbx),%rdi
  6a2447:	4c 89 e6             	mov    %r12,%rsi
  6a244a:	e8 31 d6 d8 ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  6a244f:	e9 d2 fb ff ff       	jmp    6a2026 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xd6>
  6a2454:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a245f:	90                   	nop
  6a2460:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  6a2467:	0f 85 a8 05 00 00    	jne    6a2a15 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xac5>
  6a246d:	48 8b 3b             	mov    (%rbx),%rdi
  6a2470:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6a2474:	48 8d 73 10          	lea    0x10(%rbx),%rsi
  6a2478:	4c 8d 4c 24 30       	lea    0x30(%rsp),%r9
  6a247d:	c4 e1 f9 6e c6       	vmovq  %rsi,%xmm0
  6a2482:	4c 89 e6             	mov    %r12,%rsi
  6a2485:	8b 08                	mov    (%rax),%ecx
  6a2487:	48 8d 90 c0 03 00 00 	lea    0x3c0(%rax),%rdx
  6a248e:	c4 e3 f9 22 c2 01    	vpinsrq $0x1,%rdx,%xmm0,%xmm0
  6a2494:	48 8b 93 80 01 00 00 	mov    0x180(%rbx),%rdx
  6a249b:	c5 fa 7f 44 24 38    	vmovdqu %xmm0,0x38(%rsp)
  6a24a1:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
  6a24a5:	44 8b 40 44          	mov    0x44(%rax),%r8d
  6a24a9:	48 85 d2             	test   %rdx,%rdx
  6a24ac:	4c 0f 44 ca          	cmove  %rdx,%r9
  6a24b0:	4c 89 ea             	mov    %r13,%rdx
  6a24b3:	e8 48 ee e3 ff       	call   4e1300 <_ZN4tomo18multi_execute_taskERNS_6ServerERKNS_4TaskERNS_5ShardEjjPNS_15AofOwnerContextE>
  6a24b8:	41 89 c6             	mov    %eax,%r14d
  6a24bb:	4c 89 ef             	mov    %r13,%rdi
  6a24be:	e8 6d 73 d5 ff       	call   3f9830 <_ZN4tomo5Shard12publish_sizeEv>
  6a24c3:	45 84 f6             	test   %r14b,%r14b
  6a24c6:	0f 84 34 02 00 00    	je     6a2700 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x7b0>
  6a24cc:	41 80 fe 02          	cmp    $0x2,%r14b
  6a24d0:	0f 85 50 fb ff ff    	jne    6a2026 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xd6>
  6a24d6:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6a24db:	49 8b 0c 24          	mov    (%r12),%rcx
  6a24df:	48 8b bb 80 01 00 00 	mov    0x180(%rbx),%rdi
  6a24e6:	89 c2                	mov    %eax,%edx
  6a24e8:	83 e0 07             	and    $0x7,%eax
  6a24eb:	c1 ea 03             	shr    $0x3,%edx
  6a24ee:	83 e2 07             	and    $0x7,%edx
  6a24f1:	4c 69 e8 50 01 00 00 	imul   $0x150,%rax,%r13
  6a24f8:	4c 03 ac d1 80 00 00 00 	add    0x80(%rcx,%rdx,8),%r13
  6a2500:	48 85 ff             	test   %rdi,%rdi
  6a2503:	74 16                	je     6a251b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x5cb>
  6a2505:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6a2509:	4c 89 ea             	mov    %r13,%rdx
  6a250c:	8b 30                	mov    (%rax),%esi
  6a250e:	e8 fd a6 f9 ff       	call   63cc10 <_ZN4tomo10AofManager16defer_completionEjRNS_2OpEPNS_6ClientE>
  6a2513:	84 c0                	test   %al,%al
  6a2515:	0f 85 0b fb ff ff    	jne    6a2026 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xd6>
  6a251b:	41 c6 85 b8 00 00 00 02 	movb   $0x2,0xb8(%r13)
  6a2523:	49 8b 34 24          	mov    (%r12),%rsi
  6a2527:	48 89 df             	mov    %rbx,%rdi
  6a252a:	e8 11 f6 ff ff       	call   6a1b40 <_ZN4tomo7ExLoopTILb1EE13notify_senderEPNS_6ClientE>
  6a252f:	e9 f2 fa ff ff       	jmp    6a2026 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xd6>
  6a2534:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a253f:	90                   	nop
  6a2540:	45 8b 75 08          	mov    0x8(%r13),%r14d
  6a2544:	e9 0e fd ff ff       	jmp    6a2257 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x307>
  6a2549:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6a2550:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  6a2557:	0f 84 10 ff ff ff    	je     6a246d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x51d>
  6a255d:	49 8b 14 24          	mov    (%r12),%rdx
  6a2561:	48 85 d2             	test   %rdx,%rdx
  6a2564:	0f 84 ab 04 00 00    	je     6a2a15 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xac5>
  6a256a:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6a256f:	48 8b 3b             	mov    (%rbx),%rdi
  6a2572:	89 c1                	mov    %eax,%ecx
  6a2574:	83 e0 07             	and    $0x7,%eax
  6a2577:	c1 e9 03             	shr    $0x3,%ecx
  6a257a:	83 e1 07             	and    $0x7,%ecx
  6a257d:	48 69 c0 50 01 00 00 	imul   $0x150,%rax,%rax
  6a2584:	48 03 84 ca 80 00 00 00 	add    0x80(%rdx,%rcx,8),%rax
  6a258c:	f6 40 1c 10          	testb  $0x10,0x1c(%rax)
  6a2590:	0f 85 87 04 00 00    	jne    6a2a1d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xacd>
  6a2596:	41 c6 85 c9 01 00 00 00 	movb   $0x0,0x1c9(%r13)
  6a259e:	e9 cd fe ff ff       	jmp    6a2470 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x520>
  6a25a3:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a25ae:	66 90                	xchg   %ax,%ax
  6a25b0:	41 0f b6 45 1c       	movzbl 0x1c(%r13),%eax
  6a25b5:	83 e0 10             	and    $0x10,%eax
  6a25b8:	84 c0                	test   %al,%al
  6a25ba:	41 0f 95 87 c9 01 00 00 	setne  0x1c9(%r15)
  6a25c2:	0f 84 b5 fc ff ff    	je     6a227d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x32d>
  6a25c8:	48 8b 03             	mov    (%rbx),%rax
  6a25cb:	f0 48 ff 80 80 4c 01 00 	lock incq 0x14c80(%rax)
  6a25d3:	e9 a5 fc ff ff       	jmp    6a227d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x32d>
  6a25d8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6a25e0:	49 8b 55 00          	mov    0x0(%r13),%rdx
  6a25e4:	f7 42 10 01 04 00 00 	testl  $0x401,0x10(%rdx)
  6a25eb:	0f 84 19 fd ff ff    	je     6a230a <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x3ba>
  6a25f1:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6a25f6:	41 80 7f 08 00       	cmpb   $0x0,0x8(%r15)
  6a25fb:	0f 85 97 04 00 00    	jne    6a2a98 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xb48>
  6a2601:	49 8b 44 24 18       	mov    0x18(%r12),%rax
  6a2606:	e9 ff fc ff ff       	jmp    6a230a <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x3ba>
  6a260b:	48 8d bb 30 02 00 00 	lea    0x230(%rbx),%rdi
  6a2612:	4c 89 e6             	mov    %r12,%rsi
  6a2615:	e8 66 d4 d8 ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  6a261a:	e9 07 fa ff ff       	jmp    6a2026 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xd6>
  6a261f:	90                   	nop
  6a2620:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  6a2624:	41 8b 47 18          	mov    0x18(%r15),%eax
  6a2628:	8b 56 44             	mov    0x44(%rsi),%edx
  6a262b:	49 ff 87 e8 03 00 00 	incq   0x3e8(%r15)
  6a2632:	83 f8 ff             	cmp    $0xffffffff,%eax
  6a2635:	0f 84 87 03 00 00    	je     6a29c2 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xa72>
  6a263b:	39 d0                	cmp    %edx,%eax
  6a263d:	74 07                	je     6a2646 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x6f6>
  6a263f:	49 ff 87 10 04 00 00 	incq   0x410(%r15)
  6a2646:	8b 93 8c 01 00 00    	mov    0x18c(%rbx),%edx
  6a264c:	49 8b 4d 10          	mov    0x10(%r13),%rcx
  6a2650:	85 d2                	test   %edx,%edx
  6a2652:	74 14                	je     6a2668 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x718>
  6a2654:	8b 83 90 01 00 00    	mov    0x190(%rbx),%eax
  6a265a:	ff c8                	dec    %eax
  6a265c:	0f 84 4e 02 00 00    	je     6a28b0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x960>
  6a2662:	89 83 90 01 00 00    	mov    %eax,0x190(%rbx)
  6a2668:	48 8b 3b             	mov    (%rbx),%rdi
  6a266b:	48 8d 53 10          	lea    0x10(%rbx),%rdx
  6a266f:	4d 89 e9             	mov    %r13,%r9
  6a2672:	4d 89 f8             	mov    %r15,%r8
  6a2675:	4c 89 e1             	mov    %r12,%rcx
  6a2678:	e8 b3 ab e2 ff       	call   4cd230 <_ZN4tomo16blocking_executeERNS_6ServerERNS_9ThreadCtxERNS_4RingERKNS_4TaskERNS_5ShardERNS_2OpE>
  6a267d:	41 89 c6             	mov    %eax,%r14d
  6a2680:	e9 a7 f9 ff ff       	jmp    6a202c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xdc>
  6a2685:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a2690:	4e 8b 24 f1          	mov    (%rcx,%r14,8),%r12
  6a2694:	41 88 94 24 c8 01 00 00 	mov    %dl,0x1c8(%r12)
  6a269c:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  6a26a3:	49 89 44 24 10       	mov    %rax,0x10(%r12)
  6a26a8:	49 89 84 24 c0 01 00 00 	mov    %rax,0x1c0(%r12)
  6a26b0:	0f 85 7c 03 00 00    	jne    6a2a32 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xae2>
  6a26b6:	48 8b 3b             	mov    (%rbx),%rdi
  6a26b9:	ba 20 00 00 00       	mov    $0x20,%edx
  6a26be:	4c 89 e6             	mov    %r12,%rsi
  6a26c1:	e8 3a 67 e2 ff       	call   4c8e00 <_ZN4tomo20xshard_cleanup_shardERNS_6ServerERNS_5ShardEj>
  6a26c6:	4c 89 e7             	mov    %r12,%rdi
  6a26c9:	e8 62 71 d5 ff       	call   3f9830 <_ZN4tomo5Shard12publish_sizeEv>
  6a26ce:	e9 53 f9 ff ff       	jmp    6a2026 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xd6>
  6a26d3:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a26de:	66 90                	xchg   %ax,%ax
  6a26e0:	48 8d 83 30 02 00 00 	lea    0x230(%rbx),%rax
  6a26e7:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6a26ec:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6a26f1:	4c 89 e6             	mov    %r12,%rsi
  6a26f4:	e8 87 d3 d8 ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  6a26f9:	e9 28 f9 ff ff       	jmp    6a2026 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xd6>
  6a26fe:	66 90                	xchg   %ax,%ax
  6a2700:	48 8d bb 80 02 00 00 	lea    0x280(%rbx),%rdi
  6a2707:	4c 89 e6             	mov    %r12,%rsi
  6a270a:	e8 71 d3 d8 ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  6a270f:	e9 12 f9 ff ff       	jmp    6a2026 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xd6>
  6a2714:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a271f:	90                   	nop
  6a2720:	4d 8b 75 00          	mov    0x0(%r13),%r14
  6a2724:	41 0f b7 76 26       	movzwl 0x26(%r14),%esi
  6a2729:	e8 82 76 d5 ff       	call   3f9db0 <_ZN4tomo9ThreadCtx12note_commandEt>
  6a272e:	41 f6 46 11 01       	testb  $0x1,0x11(%r14)
  6a2733:	0f 85 77 03 00 00    	jne    6a2ab0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xb60>
  6a2739:	48 83 bb e0 19 00 00 00 	cmpq   $0x0,0x19e0(%rbx)
  6a2741:	0f 84 84 02 00 00    	je     6a29cb <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xa7b>
  6a2747:	49 8b 45 00          	mov    0x0(%r13),%rax
  6a274b:	8b 50 10             	mov    0x10(%rax),%edx
  6a274e:	f7 c2 01 04 00 00    	test   $0x401,%edx
  6a2754:	0f 84 a6 01 00 00    	je     6a2900 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x9b0>
  6a275a:	41 83 bd b4 00 00 00 fd 	cmpl   $0xfffffffd,0xb4(%r13)
  6a2762:	74 09                	je     6a276d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x81d>
  6a2764:	80 e6 08             	and    $0x8,%dh
  6a2767:	0f 84 93 01 00 00    	je     6a2900 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x9b0>
  6a276d:	49 8b 04 24          	mov    (%r12),%rax
  6a2771:	48 8b 3b             	mov    (%rbx),%rdi
  6a2774:	4c 8d 44 24 30       	lea    0x30(%rsp),%r8
  6a2779:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
  6a277d:	4c 89 ea             	mov    %r13,%rdx
  6a2780:	62 f1 7f 28 7f 84 24 30 00 00 00 	vmovdqu8 %ymm0,0x30(%rsp)
  6a278b:	4c 89 fe             	mov    %r15,%rsi
  6a278e:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  6a2793:	48 8b 88 a8 07 00 00 	mov    0x7a8(%rax),%rcx
  6a279a:	c5 f8 77             	vzeroupper
  6a279d:	e8 6e 70 e2 ff       	call   4c9810 <_ZN4tomo20xshard_plain_prepareERNS_6ServerERNS_5ShardERNS_2OpEmRNS_21PlainForeignReadScopeE>
  6a27a2:	88 44 24 07          	mov    %al,0x7(%rsp)
  6a27a6:	4d 8b b7 b0 04 00 00 	mov    0x4b0(%r15),%r14
  6a27ad:	4d 85 f6             	test   %r14,%r14
  6a27b0:	0f 85 be 03 00 00    	jne    6a2b74 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xc24>
  6a27b6:	84 c0                	test   %al,%al
  6a27b8:	0f 84 b2 02 00 00    	je     6a2a70 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xb20>
  6a27be:	49 8b 45 00          	mov    0x0(%r13),%rax
  6a27c2:	4c 89 ee             	mov    %r13,%rsi
  6a27c5:	4c 89 ff             	mov    %r15,%rdi
  6a27c8:	ff 50 18             	call   *0x18(%rax)
  6a27cb:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  6a27d0:	4c 89 ff             	mov    %r15,%rdi
  6a27d3:	e8 18 1b e0 ff       	call   4a42f0 <_ZN4tomo19xshard_plain_finishERNS_5ShardERNS_21PlainForeignReadScopeE>
  6a27d8:	4d 85 f6             	test   %r14,%r14
  6a27db:	0f 85 d9 03 00 00    	jne    6a2bba <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xc6a>
  6a27e1:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  6a27e6:	48 85 ff             	test   %rdi,%rdi
  6a27e9:	0f 84 11 fc ff ff    	je     6a2400 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x4b0>
  6a27ef:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  6a27f4:	48 29 fe             	sub    %rdi,%rsi
  6a27f7:	e8 a4 a3 97 ff       	call   1cba0 <_ZdlPvm@plt>
  6a27fc:	e9 ff fb ff ff       	jmp    6a2400 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x4b0>
  6a2801:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a280c:	0f 1f 40 00          	nopl   0x0(%rax)
  6a2810:	48 8d 83 30 02 00 00 	lea    0x230(%rbx),%rax
  6a2817:	45 89 f0             	mov    %r14d,%r8d
  6a281a:	4c 89 e9             	mov    %r13,%rcx
  6a281d:	4c 89 e2             	mov    %r12,%rdx
  6a2820:	48 89 c6             	mov    %rax,%rsi
  6a2823:	48 89 df             	mov    %rbx,%rdi
  6a2826:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6a282b:	e8 f0 ee ff ff       	call   6a1720 <_ZN4tomo7ExLoopTILb1EE21parked_predecessor_inERKSt5dequeINS_4TaskESaIS3_EERKS3_RNS_2OpEi>
  6a2830:	84 c0                	test   %al,%al
  6a2832:	0f 85 b4 fe ff ff    	jne    6a26ec <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x79c>
  6a2838:	48 8d b3 d0 02 00 00 	lea    0x2d0(%rbx),%rsi
  6a283f:	45 89 f0             	mov    %r14d,%r8d
  6a2842:	4c 89 e9             	mov    %r13,%rcx
  6a2845:	4c 89 e2             	mov    %r12,%rdx
  6a2848:	48 89 df             	mov    %rbx,%rdi
  6a284b:	e8 d0 ee ff ff       	call   6a1720 <_ZN4tomo7ExLoopTILb1EE21parked_predecessor_inERKSt5dequeINS_4TaskESaIS3_EERKS3_RNS_2OpEi>
  6a2850:	84 c0                	test   %al,%al
  6a2852:	0f 85 94 fe ff ff    	jne    6a26ec <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x79c>
  6a2858:	e9 83 fa ff ff       	jmp    6a22e0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x390>
  6a285d:	0f 1f 00             	nopl   (%rax)
  6a2860:	83 e1 07             	and    $0x7,%ecx
  6a2863:	4c 8d bb 30 02 00 00 	lea    0x230(%rbx),%r15
  6a286a:	45 89 f0             	mov    %r14d,%r8d
  6a286d:	4c 89 e2             	mov    %r12,%rdx
  6a2870:	48 69 c9 50 01 00 00 	imul   $0x150,%rcx,%rcx
  6a2877:	4c 89 fe             	mov    %r15,%rsi
  6a287a:	48 89 df             	mov    %rbx,%rdi
  6a287d:	48 01 c8             	add    %rcx,%rax
  6a2880:	48 89 c1             	mov    %rax,%rcx
  6a2883:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6a2888:	e8 93 ee ff ff       	call   6a1720 <_ZN4tomo7ExLoopTILb1EE21parked_predecessor_inERKSt5dequeINS_4TaskESaIS3_EERKS3_RNS_2OpEi>
  6a288d:	84 c0                	test   %al,%al
  6a288f:	0f 84 59 01 00 00    	je     6a29ee <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xa9e>
  6a2895:	4c 89 e6             	mov    %r12,%rsi
  6a2898:	4c 89 ff             	mov    %r15,%rdi
  6a289b:	e8 e0 d1 d8 ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  6a28a0:	e9 81 f7 ff ff       	jmp    6a2026 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xd6>
  6a28a5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a28b0:	49 8b 87 78 05 00 00 	mov    0x578(%r15),%rax
  6a28b7:	81 e1 ff 3f 00 00    	and    $0x3fff,%ecx
  6a28bd:	89 93 90 01 00 00    	mov    %edx,0x190(%rbx)
  6a28c3:	48 85 c0             	test   %rax,%rax
  6a28c6:	0f 84 9c fd ff ff    	je     6a2668 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x718>
  6a28cc:	41 0f b7 7f 04       	movzwl 0x4(%r15),%edi
  6a28d1:	39 f9                	cmp    %edi,%ecx
  6a28d3:	0f 82 8f fd ff ff    	jb     6a2668 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x718>
  6a28d9:	45 0f b7 47 06       	movzwl 0x6(%r15),%r8d
  6a28de:	44 39 c1             	cmp    %r8d,%ecx
  6a28e1:	0f 83 81 fd ff ff    	jae    6a2668 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x718>
  6a28e7:	29 f9                	sub    %edi,%ecx
  6a28e9:	01 14 88             	add    %edx,(%rax,%rcx,4)
  6a28ec:	e9 77 fd ff ff       	jmp    6a2668 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x718>
  6a28f1:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a28fc:	0f 1f 40 00          	nopl   0x0(%rax)
  6a2900:	49 8b 97 00 01 00 00 	mov    0x100(%r15),%rdx
  6a2907:	48 85 d2             	test   %rdx,%rdx
  6a290a:	74 0e                	je     6a291a <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x9ca>
  6a290c:	48 83 ba 10 02 00 00 00 	cmpq   $0x0,0x210(%rdx)
  6a2914:	0f 85 53 fe ff ff    	jne    6a276d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x81d>
  6a291a:	4c 89 ee             	mov    %r13,%rsi
  6a291d:	4c 89 ff             	mov    %r15,%rdi
  6a2920:	ff 50 18             	call   *0x18(%rax)
  6a2923:	e9 d8 fa ff ff       	jmp    6a2400 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x4b0>
  6a2928:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6a2930:	41 89 4f 18          	mov    %ecx,0x18(%r15)
  6a2934:	e9 f7 f9 ff ff       	jmp    6a2330 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x3e0>
  6a2939:	49 8b 55 10          	mov    0x10(%r13),%rdx
  6a293d:	4c 89 fe             	mov    %r15,%rsi
  6a2940:	48 89 df             	mov    %rbx,%rdi
  6a2943:	e8 48 ed ff ff       	call   6a1690 <_ZN4tomo7ExLoopTILb1EE12note_lb_hashERNS_5ShardEm>
  6a2948:	49 8b 45 00          	mov    0x0(%r13),%rax
  6a294c:	f7 40 10 01 04 00 00 	testl  $0x401,0x10(%rax)
  6a2953:	0f 85 e7 00 00 00    	jne    6a2a40 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xaf0>
  6a2959:	48 83 bb 80 01 00 00 00 	cmpq   $0x0,0x180(%rbx)
  6a2961:	0f 84 b4 fb ff ff    	je     6a251b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x5cb>
  6a2967:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6a296b:	48 8d 7b 10          	lea    0x10(%rbx),%rdi
  6a296f:	4c 89 ee             	mov    %r13,%rsi
  6a2972:	c4 e1 f9 6e c7       	vmovq  %rdi,%xmm0
  6a2977:	4c 89 ff             	mov    %r15,%rdi
  6a297a:	8b 10                	mov    (%rax),%edx
  6a297c:	48 05 c0 03 00 00    	add    $0x3c0,%rax
  6a2982:	c4 e3 f9 22 c0 01    	vpinsrq $0x1,%rax,%xmm0,%xmm0
  6a2988:	c5 fa 7f 44 24 38    	vmovdqu %xmm0,0x38(%rsp)
  6a298e:	89 54 24 30          	mov    %edx,0x30(%rsp)
  6a2992:	41 83 bd b4 00 00 00 fd 	cmpl   $0xfffffffd,0xb4(%r13)
  6a299a:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
  6a299f:	0f 84 3c 02 00 00    	je     6a2be1 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xc91>
  6a29a5:	e8 06 27 fa ff       	call   6450b0 <_ZN4tomo19aof_record_local_opERNS_5ShardERNS_2OpERNS_15AofOwnerContextE>
  6a29aa:	e9 5d fa ff ff       	jmp    6a240c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x4bc>
  6a29af:	90                   	nop
  6a29b0:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  6a29b7:	0f 84 b0 fa ff ff    	je     6a246d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x51d>
  6a29bd:	e9 a8 fb ff ff       	jmp    6a256a <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x61a>
  6a29c2:	41 89 57 18          	mov    %edx,0x18(%r15)
  6a29c6:	e9 7b fc ff ff       	jmp    6a2646 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x6f6>
  6a29cb:	49 8b 87 00 01 00 00 	mov    0x100(%r15),%rax
  6a29d2:	48 85 c0             	test   %rax,%rax
  6a29d5:	74 0e                	je     6a29e5 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xa95>
  6a29d7:	48 83 b8 10 02 00 00 00 	cmpq   $0x0,0x210(%rax)
  6a29df:	0f 85 88 fd ff ff    	jne    6a276d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x81d>
  6a29e5:	49 8b 45 00          	mov    0x0(%r13),%rax
  6a29e9:	e9 2c ff ff ff       	jmp    6a291a <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x9ca>
  6a29ee:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6a29f3:	48 8d b3 d0 02 00 00 	lea    0x2d0(%rbx),%rsi
  6a29fa:	45 89 f0             	mov    %r14d,%r8d
  6a29fd:	4c 89 e2             	mov    %r12,%rdx
  6a2a00:	48 89 df             	mov    %rbx,%rdi
  6a2a03:	e8 18 ed ff ff       	call   6a1720 <_ZN4tomo7ExLoopTILb1EE21parked_predecessor_inERKSt5dequeINS_4TaskESaIS3_EERKS3_RNS_2OpEi>
  6a2a08:	84 c0                	test   %al,%al
  6a2a0a:	0f 85 85 fe ff ff    	jne    6a2895 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x945>
  6a2a10:	e9 e0 f6 ff ff       	jmp    6a20f5 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x1a5>
  6a2a15:	48 8b 3b             	mov    (%rbx),%rdi
  6a2a18:	e9 79 fb ff ff       	jmp    6a2596 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x646>
  6a2a1d:	41 c6 85 c9 01 00 00 01 	movb   $0x1,0x1c9(%r13)
  6a2a25:	f0 48 ff 87 80 4c 01 00 	lock incq 0x14c80(%rdi)
  6a2a2d:	e9 3b fa ff ff       	jmp    6a246d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x51d>
  6a2a32:	41 c6 84 24 c9 01 00 00 00 	movb   $0x0,0x1c9(%r12)
  6a2a3b:	e9 76 fc ff ff       	jmp    6a26b6 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x766>
  6a2a40:	4c 89 ff             	mov    %r15,%rdi
  6a2a43:	e8 18 3c ff ff       	call   696660 <_ZNK4tomo5Shard11has_watchesEv>
  6a2a48:	84 c0                	test   %al,%al
  6a2a4a:	0f 85 81 01 00 00    	jne    6a2bd1 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xc81>
  6a2a50:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
  6a2a56:	0f 84 fd fe ff ff    	je     6a2959 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xa09>
  6a2a5c:	e9 ab f9 ff ff       	jmp    6a240c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x4bc>
  6a2a61:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a2a6c:	0f 1f 40 00          	nopl   0x0(%rax)
  6a2a70:	4c 89 ef             	mov    %r13,%rdi
  6a2a73:	e8 68 79 08 00       	call   72a3e0 <_ZN4tomo22l4prebuild_discard_setERNS_2OpE>
  6a2a78:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  6a2a7d:	4c 89 ff             	mov    %r15,%rdi
  6a2a80:	e8 6b 18 e0 ff       	call   4a42f0 <_ZN4tomo19xshard_plain_finishERNS_5ShardERNS_21PlainForeignReadScopeE>
  6a2a85:	e9 57 fd ff ff       	jmp    6a27e1 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x891>
  6a2a8a:	49 83 bf d8 04 00 00 00 	cmpq   $0x0,0x4d8(%r15)
  6a2a92:	0f 84 ae 00 00 00    	je     6a2b46 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xbf6>
  6a2a98:	4c 89 ee             	mov    %r13,%rsi
  6a2a9b:	4c 89 ff             	mov    %r15,%rdi
  6a2a9e:	e8 8d 4b e3 ff       	call   4d7630 <_ZN4tomo23multi_plain_write_readyERNS_5ShardERNS_2OpE>
  6a2aa3:	84 c0                	test   %al,%al
  6a2aa5:	0f 85 56 fb ff ff    	jne    6a2601 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x6b1>
  6a2aab:	e9 7c f5 ff ff       	jmp    6a202c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xdc>
  6a2ab0:	49 8b 95 c0 00 00 00 	mov    0xc0(%r13),%rdx
  6a2ab7:	41 0f bf 46 20       	movswl 0x20(%r14),%eax
  6a2abc:	49 8d 7f 38          	lea    0x38(%r15),%rdi
  6a2ac0:	48 85 d2             	test   %rdx,%rdx
  6a2ac3:	0f 84 e1 00 00 00    	je     6a2baa <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xc5a>
  6a2ac9:	48 c1 e0 04          	shl    $0x4,%rax
  6a2acd:	48 01 d0             	add    %rdx,%rax
  6a2ad0:	48 8b 30             	mov    (%rax),%rsi
  6a2ad3:	48 8b 50 08          	mov    0x8(%rax),%rdx
  6a2ad7:	e8 44 7a d6 ff       	call   40a520 <_ZN4tomo9FlatStore12budget_admitENS_5SliceE>
  6a2adc:	84 c0                	test   %al,%al
  6a2ade:	0f 85 55 fc ff ff    	jne    6a2739 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x7e9>
  6a2ae4:	4c 89 ef             	mov    %r13,%rdi
  6a2ae7:	e8 84 cb e9 ff       	call   53f670 <_ZN4tomo19reply_maxmemory_oomERNS_2OpE>
  6a2aec:	4c 89 ef             	mov    %r13,%rdi
  6a2aef:	e8 ec 78 08 00       	call   72a3e0 <_ZN4tomo22l4prebuild_discard_setERNS_2OpE>
  6a2af4:	e9 07 f9 ff ff       	jmp    6a2400 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x4b0>
  6a2af9:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6a2afd:	c5 fa 7e 54 24 08    	vmovq  0x8(%rsp),%xmm2
  6a2b03:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
  6a2b08:	4c 89 fe             	mov    %r15,%rsi
  6a2b0b:	4c 89 e7             	mov    %r12,%rdi
  6a2b0e:	8b 10                	mov    (%rax),%edx
  6a2b10:	48 05 c0 03 00 00    	add    $0x3c0,%rax
  6a2b16:	c4 e3 e9 22 c0 01    	vpinsrq $0x1,%rax,%xmm2,%xmm0
  6a2b1c:	c5 fa 7f 44 24 38    	vmovdqu %xmm0,0x38(%rsp)
  6a2b22:	89 54 24 30          	mov    %edx,0x30(%rsp)
  6a2b26:	4c 89 ea             	mov    %r13,%rdx
  6a2b29:	e8 f2 f5 df ff       	call   4a2120 <_ZN4tomo15xshard_aof_emitERKNS_4TaskERNS_5ShardERNS_2OpERNS_15AofOwnerContextE>
  6a2b2e:	e9 96 f8 ff ff       	jmp    6a23c9 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x479>
  6a2b33:	4c 89 ea             	mov    %r13,%rdx
  6a2b36:	4c 89 fe             	mov    %r15,%rsi
  6a2b39:	4c 89 e7             	mov    %r12,%rdi
  6a2b3c:	e8 af a3 e2 ff       	call   4ccef0 <_ZN4tomo35blocking_scatter_mutation_publishedERKNS_4TaskERNS_5ShardERNS_2OpE>
  6a2b41:	e9 6c f8 ff ff       	jmp    6a23b2 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x462>
  6a2b46:	49 83 bf 10 05 00 00 00 	cmpq   $0x0,0x510(%r15)
  6a2b4e:	0f 84 ad fa ff ff    	je     6a2601 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x6b1>
  6a2b54:	e9 3f ff ff ff       	jmp    6a2a98 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xb48>
  6a2b59:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  6a2b5d:	48 8b 3b             	mov    (%rbx),%rdi
  6a2b60:	4c 89 e2             	mov    %r12,%rdx
  6a2b63:	e8 78 fa df ff       	call   4a25e0 <_ZN4tomo19xshard_queue_commitERNS_6ServerERNS_9ThreadCtxERKNS_4TaskE>
  6a2b68:	c6 83 da 15 00 00 01 	movb   $0x1,0x15da(%rbx)
  6a2b6f:	e9 b2 f4 ff ff       	jmp    6a2026 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xd6>
  6a2b74:	bf 01 00 00 00       	mov    $0x1,%edi
  6a2b79:	e8 02 1b e0 ff       	call   4a4680 <_ZN4tomo32blocking_defer_plain_publicationEb>
  6a2b7e:	80 7c 24 07 00       	cmpb   $0x0,0x7(%rsp)
  6a2b83:	0f 85 35 fc ff ff    	jne    6a27be <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x86e>
  6a2b89:	4c 89 ef             	mov    %r13,%rdi
  6a2b8c:	e8 4f 78 08 00       	call   72a3e0 <_ZN4tomo22l4prebuild_discard_setERNS_2OpE>
  6a2b91:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  6a2b96:	4c 89 ff             	mov    %r15,%rdi
  6a2b99:	e8 52 17 e0 ff       	call   4a42f0 <_ZN4tomo19xshard_plain_finishERNS_5ShardERNS_21PlainForeignReadScopeE>
  6a2b9e:	31 ff                	xor    %edi,%edi
  6a2ba0:	e8 db 1a e0 ff       	call   4a4680 <_ZN4tomo32blocking_defer_plain_publicationEb>
  6a2ba5:	e9 37 fc ff ff       	jmp    6a27e1 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x891>
  6a2baa:	48 83 c0 0d          	add    $0xd,%rax
  6a2bae:	48 c1 e0 04          	shl    $0x4,%rax
  6a2bb2:	4c 01 e8             	add    %r13,%rax
  6a2bb5:	e9 16 ff ff ff       	jmp    6a2ad0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xb80>
  6a2bba:	31 ff                	xor    %edi,%edi
  6a2bbc:	e8 bf 1a e0 ff       	call   4a4680 <_ZN4tomo32blocking_defer_plain_publicationEb>
  6a2bc1:	4c 89 ee             	mov    %r13,%rsi
  6a2bc4:	4c 89 ff             	mov    %r15,%rdi
  6a2bc7:	e8 64 a1 e2 ff       	call   4ccd30 <_ZN4tomo33blocking_plain_mutation_publishedERNS_5ShardERNS_2OpE>
  6a2bcc:	e9 10 fc ff ff       	jmp    6a27e1 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x891>
  6a2bd1:	4c 89 ee             	mov    %r13,%rsi
  6a2bd4:	4c 89 ff             	mov    %r15,%rdi
  6a2bd7:	e8 24 53 e3 ff       	call   4d7f00 <_ZN4tomo27multi_plain_write_committedERNS_5ShardERNS_2OpE>
  6a2bdc:	e9 6f fe ff ff       	jmp    6a2a50 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xb00>
  6a2be1:	e8 0a 78 e0 ff       	call   4aa3f0 <_ZN4tomo21xshard_aof_emit_localERNS_5ShardERNS_2OpERNS_15AofOwnerContextE>
  6a2be6:	e9 21 f8 ff ff       	jmp    6a240c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0x4bc>
  6a2beb:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6a2bf0:	c5 f8 77             	vzeroupper
  6a2bf3:	e8 f8 ea ff ff       	call   6a16f0 <_ZNSt6vectorIN4tomo21PlainForeignReadScope3KeyESaIS2_EED1Ev>
  6a2bf8:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6a2bfd:	c5 f8 77             	vzeroupper
  6a2c00:	e8 cb 8b d5 ff       	call   3fb7d0 <_ZN4tomo6Server15ClientWorkScopeD1Ev>
  6a2c05:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  6a2c0a:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  6a2c13:	74 17                	je     6a2c2c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xcdc>
  6a2c15:	e8 86 9b 97 ff       	call   1c7a0 <__stack_chk_fail@plt>
  6a2c1a:	f3 0f 1e fa          	endbr64
  6a2c1e:	48 89 c3             	mov    %rax,%rbx
  6a2c21:	eb c8                	jmp    6a2beb <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xc9b>
  6a2c23:	f3 0f 1e fa          	endbr64
  6a2c27:	48 89 c3             	mov    %rax,%rbx
  6a2c2a:	eb cc                	jmp    6a2bf8 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE+0xca8>
  6a2c2c:	48 89 df             	mov    %rbx,%rdi
  6a2c2f:	e8 3c a1 97 ff       	call   1cd70 <_Unwind_Resume@plt>

Disassembly of section .rlfence:

Disassembly of section .fini:
