
/home/user/Projects/cx-exbatch/build/exbatch/POST/tomokv:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

00000000006a2c40 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE>:
  6a2c40:	f3 0f 1e fa          	endbr64
  6a2c44:	55                   	push   %rbp
  6a2c45:	48 89 e5             	mov    %rsp,%rbp
  6a2c48:	41 57                	push   %r15
  6a2c4a:	41 56                	push   %r14
  6a2c4c:	41 55                	push   %r13
  6a2c4e:	41 54                	push   %r12
  6a2c50:	53                   	push   %rbx
  6a2c51:	49 89 f4             	mov    %rsi,%r12
  6a2c54:	48 89 fb             	mov    %rdi,%rbx
  6a2c57:	48 83 ec 68          	sub    $0x68,%rsp
  6a2c5b:	64 48 8b 04 25 28 00 00 00 	mov    %fs:0x28,%rax
  6a2c64:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  6a2c69:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6a2c6d:	c6 44 24 20 00       	movb   $0x0,0x20(%rsp)
  6a2c72:	48 c7 44 24 18 00 00 00 00 	movq   $0x0,0x18(%rsp)
  6a2c7b:	8b 00                	mov    (%rax),%eax
  6a2c7d:	48 05 ee 05 00 00    	add    $0x5ee,%rax
  6a2c83:	48 c1 e0 06          	shl    $0x6,%rax
  6a2c87:	48 03 07             	add    (%rdi),%rax
  6a2c8a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6a2c8f:	48 8b 10             	mov    (%rax),%rdx
  6a2c92:	48 89 d1             	mov    %rdx,%rcx
  6a2c95:	83 e1 01             	and    $0x1,%ecx
  6a2c98:	48 89 ce             	mov    %rcx,%rsi
  6a2c9b:	48 83 f6 01          	xor    $0x1,%rsi
  6a2c9f:	40 88 74 24 20       	mov    %sil,0x20(%rsp)
  6a2ca4:	80 64 24 20 01       	andb   $0x1,0x20(%rsp)
  6a2ca9:	48 85 c9             	test   %rcx,%rcx
  6a2cac:	0f 84 1e 02 00 00    	je     6a2ed0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x290>
  6a2cb2:	49 63 44 24 10       	movslq 0x10(%r12),%rax
  6a2cb7:	85 c0                	test   %eax,%eax
  6a2cb9:	79 34                	jns    6a2cef <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xaf>
  6a2cbb:	49 8b 0c 24          	mov    (%r12),%rcx
  6a2cbf:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6a2cc4:	48 85 c9             	test   %rcx,%rcx
  6a2cc7:	0f 84 83 00 00 00    	je     6a2d50 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x110>
  6a2ccd:	89 c2                	mov    %eax,%edx
  6a2ccf:	83 e0 07             	and    $0x7,%eax
  6a2cd2:	c1 ea 03             	shr    $0x3,%edx
  6a2cd5:	83 e2 07             	and    $0x7,%edx
  6a2cd8:	48 69 c0 50 01 00 00 	imul   $0x150,%rax,%rax
  6a2cdf:	48 03 84 d1 80 00 00 00 	add    0x80(%rcx,%rdx,8),%rax
  6a2ce7:	48 63 40 08          	movslq 0x8(%rax),%rax
  6a2ceb:	85 c0                	test   %eax,%eax
  6a2ced:	78 61                	js     6a2d50 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x110>
  6a2cef:	48 8b 13             	mov    (%rbx),%rdx
  6a2cf2:	48 05 6e 44 00 00    	add    $0x446e,%rax
  6a2cf8:	8b 14 82             	mov    (%rdx,%rax,4),%edx
  6a2cfb:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6a2cff:	3b 10                	cmp    (%rax),%edx
  6a2d01:	74 4d                	je     6a2d50 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x110>
  6a2d03:	4c 89 e6             	mov    %r12,%rsi
  6a2d06:	48 89 df             	mov    %rbx,%rdi
  6a2d09:	e8 d2 99 ff ff       	call   69c6e0 <_ZN4tomo7ExLoopTILb1EE19post_forwarded_taskILb0EEEbRKNS_4TaskEj>
  6a2d0e:	84 c0                	test   %al,%al
  6a2d10:	0f 84 2a 04 00 00    	je     6a3140 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x500>
  6a2d16:	41 be 01 00 00 00    	mov    $0x1,%r14d
  6a2d1c:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
  6a2d21:	0f 85 c9 01 00 00    	jne    6a2ef0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x2b0>
  6a2d27:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  6a2d2c:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  6a2d35:	0f 85 30 0c 00 00    	jne    6a396b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd2b>
  6a2d3b:	48 83 c4 68          	add    $0x68,%rsp
  6a2d3f:	44 89 f0             	mov    %r14d,%eax
  6a2d42:	5b                   	pop    %rbx
  6a2d43:	41 5c                	pop    %r12
  6a2d45:	41 5d                	pop    %r13
  6a2d47:	41 5e                	pop    %r14
  6a2d49:	41 5f                	pop    %r15
  6a2d4b:	5d                   	pop    %rbp
  6a2d4c:	c3                   	ret
  6a2d4d:	0f 1f 00             	nopl   (%rax)
  6a2d50:	4c 89 e7             	mov    %r12,%rdi
  6a2d53:	e8 88 1d e0 ff       	call   4a4ae0 <_ZN4tomo17multi_task_taggedERKNS_4TaskE>
  6a2d58:	89 c2                	mov    %eax,%edx
  6a2d5a:	48 8b 03             	mov    (%rbx),%rax
  6a2d5d:	4d 63 74 24 10       	movslq 0x10(%r12),%r14
  6a2d62:	48 8b 80 c8 03 01 00 	mov    0x103c8(%rax),%rax
  6a2d69:	84 d2                	test   %dl,%dl
  6a2d6b:	0f 84 9f 01 00 00    	je     6a2f10 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x2d0>
  6a2d71:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
  6a2d75:	0f b6 93 8a 01 00 00 	movzbl 0x18a(%rbx),%edx
  6a2d7c:	48 8b 83 58 01 00 00 	mov    0x158(%rbx),%rax
  6a2d83:	41 88 95 c8 01 00 00 	mov    %dl,0x1c8(%r13)
  6a2d8a:	49 89 45 10          	mov    %rax,0x10(%r13)
  6a2d8e:	49 89 85 c0 01 00 00 	mov    %rax,0x1c0(%r13)
  6a2d95:	49 8b 04 24          	mov    (%r12),%rax
  6a2d99:	48 85 c0             	test   %rax,%rax
  6a2d9c:	0f 84 be 03 00 00    	je     6a3160 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x520>
  6a2da2:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
  6a2da7:	48 8b bb 40 02 00 00 	mov    0x240(%rbx),%rdi
  6a2dae:	45 8b 74 24 10       	mov    0x10(%r12),%r14d
  6a2db3:	89 ca                	mov    %ecx,%edx
  6a2db5:	c1 ea 03             	shr    $0x3,%edx
  6a2db8:	83 e2 07             	and    $0x7,%edx
  6a2dbb:	48 8b 84 d0 80 00 00 00 	mov    0x80(%rax,%rdx,8),%rax
  6a2dc3:	48 39 bb 60 02 00 00 	cmp    %rdi,0x260(%rbx)
  6a2dca:	0f 85 00 08 00 00    	jne    6a35d0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x990>
  6a2dd0:	48 8b bb e0 02 00 00 	mov    0x2e0(%rbx),%rdi
  6a2dd7:	48 39 bb 00 03 00 00 	cmp    %rdi,0x300(%rbx)
  6a2dde:	0f 85 ec 07 00 00    	jne    6a35d0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x990>
  6a2de4:	49 8b 85 00 01 00 00 	mov    0x100(%r13),%rax
  6a2deb:	48 85 c0             	test   %rax,%rax
  6a2dee:	0f 84 5c 04 00 00    	je     6a3250 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x610>
  6a2df4:	48 83 b8 10 02 00 00 00 	cmpq   $0x0,0x210(%rax)
  6a2dfc:	0f 84 4e 04 00 00    	je     6a3250 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x610>
  6a2e02:	49 8b 14 24          	mov    (%r12),%rdx
  6a2e06:	8b 88 10 02 00 00    	mov    0x210(%rax),%ecx
  6a2e0c:	4c 8b ba a8 07 00 00 	mov    0x7a8(%rdx),%r15
  6a2e13:	85 c9                	test   %ecx,%ecx
  6a2e15:	0f 84 05 09 00 00    	je     6a3720 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xae0>
  6a2e1b:	4c 89 fa             	mov    %r15,%rdx
  6a2e1e:	48 b9 cd 8c 55 ed d7 af 51 ff 	movabs $0xff51afd7ed558ccd,%rcx
  6a2e28:	48 c1 ea 21          	shr    $0x21,%rdx
  6a2e2c:	4c 31 fa             	xor    %r15,%rdx
  6a2e2f:	48 0f af d1          	imul   %rcx,%rdx
  6a2e33:	48 89 d1             	mov    %rdx,%rcx
  6a2e36:	48 c1 e9 21          	shr    $0x21,%rcx
  6a2e3a:	48 31 ca             	xor    %rcx,%rdx
  6a2e3d:	48 b9 53 ec 85 1a fe b9 ce c4 	movabs $0xc4ceb9fe1a85ec53,%rcx
  6a2e47:	48 0f af d1          	imul   %rcx,%rdx
  6a2e4b:	48 89 d1             	mov    %rdx,%rcx
  6a2e4e:	48 c1 e9 21          	shr    $0x21,%rcx
  6a2e52:	48 31 ca             	xor    %rcx,%rdx
  6a2e55:	83 e2 3f             	and    $0x3f,%edx
  6a2e58:	4c 8b 74 d0 10       	mov    0x10(%rax,%rdx,8),%r14
  6a2e5d:	4d 85 f6             	test   %r14,%r14
  6a2e60:	75 1b                	jne    6a2e7d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x23d>
  6a2e62:	e9 e9 03 00 00       	jmp    6a3250 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x610>
  6a2e67:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
  6a2e70:	4d 8b 76 10          	mov    0x10(%r14),%r14
  6a2e74:	4d 85 f6             	test   %r14,%r14
  6a2e77:	0f 84 d3 03 00 00    	je     6a3250 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x610>
  6a2e7d:	49 8b 76 30          	mov    0x30(%r14),%rsi
  6a2e81:	48 85 f6             	test   %rsi,%rsi
  6a2e84:	74 ea                	je     6a2e70 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x230>
  6a2e86:	4d 3b 7e 50          	cmp    0x50(%r14),%r15
  6a2e8a:	75 e4                	jne    6a2e70 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x230>
  6a2e8c:	4c 89 e7             	mov    %r12,%rdi
  6a2e8f:	e8 5c 1c e0 ff       	call   4a4af0 <_ZN4tomo21multi_task_owns_epochERKNS_4TaskEPKv>
  6a2e94:	84 c0                	test   %al,%al
  6a2e96:	75 d8                	jne    6a2e70 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x230>
  6a2e98:	49 8b 46 30          	mov    0x30(%r14),%rax
  6a2e9c:	48 8b 00             	mov    (%rax),%rax
  6a2e9f:	48 85 c0             	test   %rax,%rax
  6a2ea2:	75 cc                	jne    6a2e70 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x230>
  6a2ea4:	49 8b 46 40          	mov    0x40(%r14),%rax
  6a2ea8:	48 85 c0             	test   %rax,%rax
  6a2eab:	74 07                	je     6a2eb4 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x274>
  6a2ead:	0f b6 00             	movzbl (%rax),%eax
  6a2eb0:	84 c0                	test   %al,%al
  6a2eb2:	75 bc                	jne    6a2e70 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x230>
  6a2eb4:	48 8d bb 30 02 00 00 	lea    0x230(%rbx),%rdi
  6a2ebb:	4c 89 e6             	mov    %r12,%rsi
  6a2ebe:	49 ff 85 58 04 00 00 	incq   0x458(%r13)
  6a2ec5:	e8 b6 cb d8 ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  6a2eca:	e9 47 fe ff ff       	jmp    6a2d16 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  6a2ecf:	90                   	nop
  6a2ed0:	48 8d 4a 02          	lea    0x2(%rdx),%rcx
  6a2ed4:	48 ff c2             	inc    %rdx
  6a2ed7:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  6a2edc:	48 89 10             	mov    %rdx,(%rax)
  6a2edf:	e9 ce fd ff ff       	jmp    6a2cb2 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x72>
  6a2ee4:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a2eef:	90                   	nop
  6a2ef0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6a2ef5:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  6a2efa:	48 89 10             	mov    %rdx,(%rax)
  6a2efd:	e9 25 fe ff ff       	jmp    6a2d27 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xe7>
  6a2f02:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a2f0d:	0f 1f 00             	nopl   (%rax)
  6a2f10:	49 8b 0c 24          	mov    (%r12),%rcx
  6a2f14:	48 85 c9             	test   %rcx,%rcx
  6a2f17:	0f 84 d3 04 00 00    	je     6a33f0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x7b0>
  6a2f1d:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
  6a2f22:	44 89 ea             	mov    %r13d,%edx
  6a2f25:	41 83 e5 07          	and    $0x7,%r13d
  6a2f29:	c1 ea 03             	shr    $0x3,%edx
  6a2f2c:	83 e2 07             	and    $0x7,%edx
  6a2f2f:	4d 69 ed 50 01 00 00 	imul   $0x150,%r13,%r13
  6a2f36:	4c 03 ac d1 80 00 00 00 	add    0x80(%rcx,%rdx,8),%r13
  6a2f3e:	45 85 f6             	test   %r14d,%r14d
  6a2f41:	0f 88 f9 02 00 00    	js     6a3240 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x600>
  6a2f47:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  6a2f4e:	49 63 d6             	movslq %r14d,%rdx
  6a2f51:	4c 8b 3c d0          	mov    (%rax,%rdx,8),%r15
  6a2f55:	0f 85 55 03 00 00    	jne    6a32b0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x670>
  6a2f5b:	0f b6 93 8a 01 00 00 	movzbl 0x18a(%rbx),%edx
  6a2f62:	48 8b 83 58 01 00 00 	mov    0x158(%rbx),%rax
  6a2f69:	41 88 97 c8 01 00 00 	mov    %dl,0x1c8(%r15)
  6a2f70:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  6a2f77:	49 89 47 10          	mov    %rax,0x10(%r15)
  6a2f7b:	49 89 87 c0 01 00 00 	mov    %rax,0x1c0(%r15)
  6a2f82:	0f 85 88 03 00 00    	jne    6a3310 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x6d0>
  6a2f88:	49 83 bd a8 00 00 00 00 	cmpq   $0x0,0xa8(%r13)
  6a2f90:	74 0e                	je     6a2fa0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x360>
  6a2f92:	41 83 bd b4 00 00 00 fc 	cmpl   $0xfffffffc,0xb4(%r13)
  6a2f9a:	0f 84 e0 03 00 00    	je     6a3380 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x740>
  6a2fa0:	0f b6 05 f2 6d 25 00 	movzbl 0x256df2(%rip),%eax        # 8f9d99 <_ZN4tomo22atomic_tripwire_detail5armedE>
  6a2fa7:	84 c0                	test   %al,%al
  6a2fa9:	74 18                	je     6a2fc3 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x383>
  6a2fab:	48 83 3d ed 6d 25 00 00 	cmpq   $0x0,0x256ded(%rip)        # 8f9da0 <_ZN4tomo22atomic_tripwire_detail5stateE>
  6a2fb3:	74 0e                	je     6a2fc3 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x383>
  6a2fb5:	4c 89 ea             	mov    %r13,%rdx
  6a2fb8:	4c 89 fe             	mov    %r15,%rsi
  6a2fbb:	4c 89 e7             	mov    %r12,%rdi
  6a2fbe:	e8 cd ed e2 ff       	call   4d1d90 <_ZN4tomo30xshard_tripwire_fragment_beginERKNS_4TaskERNS_5ShardERNS_2OpE>
  6a2fc3:	48 8b 83 40 02 00 00 	mov    0x240(%rbx),%rax
  6a2fca:	48 39 83 60 02 00 00 	cmp    %rax,0x260(%rbx)
  6a2fd1:	0f 85 a9 05 00 00    	jne    6a3580 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x940>
  6a2fd7:	48 8b 83 e0 02 00 00 	mov    0x2e0(%rbx),%rax
  6a2fde:	48 39 83 00 03 00 00 	cmp    %rax,0x300(%rbx)
  6a2fe5:	0f 85 95 05 00 00    	jne    6a3580 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x940>
  6a2feb:	48 8b 3b             	mov    (%rbx),%rdi
  6a2fee:	4c 89 e9             	mov    %r13,%rcx
  6a2ff1:	4c 89 e2             	mov    %r12,%rdx
  6a2ff4:	4c 89 fe             	mov    %r15,%rsi
  6a2ff7:	e8 74 65 e0 ff       	call   4a9570 <_ZN4tomo24xshard_task_should_deferERNS_6ServerERNS_5ShardERKNS_4TaskERNS_2OpE>
  6a2ffc:	41 89 c6             	mov    %eax,%r14d
  6a2fff:	84 c0                	test   %al,%al
  6a3001:	0f 85 49 04 00 00    	jne    6a3450 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x810>
  6a3007:	49 8b 44 24 18       	mov    0x18(%r12),%rax
  6a300c:	48 85 c0             	test   %rax,%rax
  6a300f:	0f 84 2b 03 00 00    	je     6a3340 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x700>
  6a3015:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
  6a3019:	41 8b 57 18          	mov    0x18(%r15),%edx
  6a301d:	8b 4f 44             	mov    0x44(%rdi),%ecx
  6a3020:	49 ff 87 e8 03 00 00 	incq   0x3e8(%r15)
  6a3027:	83 fa ff             	cmp    $0xffffffff,%edx
  6a302a:	0f 84 40 06 00 00    	je     6a3670 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa30>
  6a3030:	39 ca                	cmp    %ecx,%edx
  6a3032:	74 07                	je     6a303b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x3fb>
  6a3034:	49 ff 87 10 04 00 00 	incq   0x410(%r15)
  6a303b:	48 85 c0             	test   %rax,%rax
  6a303e:	0f 84 4c 04 00 00    	je     6a3490 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x850>
  6a3044:	8b 0f                	mov    (%rdi),%ecx
  6a3046:	4c 89 ea             	mov    %r13,%rdx
  6a3049:	4c 89 fe             	mov    %r15,%rsi
  6a304c:	4c 89 e7             	mov    %r12,%rdi
  6a304f:	e8 3c 69 e3 ff       	call   4d9990 <_ZN4tomo14xshard_executeERKNS_4TaskERNS_5ShardERNS_2OpEj>
  6a3054:	89 c1                	mov    %eax,%ecx
  6a3056:	4c 89 ea             	mov    %r13,%rdx
  6a3059:	4c 89 fe             	mov    %r15,%rsi
  6a305c:	4c 89 e7             	mov    %r12,%rdi
  6a305f:	88 44 24 08          	mov    %al,0x8(%rsp)
  6a3063:	e8 48 50 e3 ff       	call   4d80b0 <_ZN4tomo19xshard_watch_finishERKNS_4TaskERNS_5ShardERNS_2OpENS_17ScatterTaskResultE>
  6a3068:	80 7c 24 08 02       	cmpb   $0x2,0x8(%rsp)
  6a306d:	0f 84 f8 02 00 00    	je     6a336b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x72b>
  6a3073:	80 7c 24 08 01       	cmpb   $0x1,0x8(%rsp)
  6a3078:	0f 84 9e fc ff ff    	je     6a2d1c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xdc>
  6a307e:	8b 83 8c 01 00 00    	mov    0x18c(%rbx),%eax
  6a3084:	85 c0                	test   %eax,%eax
  6a3086:	74 25                	je     6a30ad <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x46d>
  6a3088:	c4 e1 f9 6e cb       	vmovq  %rbx,%xmm1
  6a308d:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
  6a3092:	48 8d 15 07 2b ff ff 	lea    -0xd4f9(%rip),%rdx        # 695ba0 <_ZZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskEENUlPvmE0_4_FUNES6_m>
  6a3099:	4c 89 e7             	mov    %r12,%rdi
  6a309c:	c4 c3 f1 22 c7 01    	vpinsrq $0x1,%r15,%xmm1,%xmm0
  6a30a2:	c5 f9 7f 44 24 30    	vmovdqa %xmm0,0x30(%rsp)
  6a30a8:	e8 13 f4 df ff       	call   4a24c0 <_ZN4tomo24xshard_visit_task_hashesERKNS_4TaskEPvPFvS3_mE>
  6a30ad:	49 8b 87 b0 04 00 00 	mov    0x4b0(%r15),%rax
  6a30b4:	48 85 c0             	test   %rax,%rax
  6a30b7:	0f 85 e6 07 00 00    	jne    6a38a3 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xc63>
  6a30bd:	48 83 bb 80 01 00 00 00 	cmpq   $0x0,0x180(%rbx)
  6a30c5:	48 8d 43 10          	lea    0x10(%rbx),%rax
  6a30c9:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6a30ce:	0f 85 95 07 00 00    	jne    6a3869 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xc29>
  6a30d4:	4c 89 ff             	mov    %r15,%rdi
  6a30d7:	e8 54 67 d5 ff       	call   3f9830 <_ZN4tomo5Shard12publish_sizeEv>
  6a30dc:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  6a30e0:	48 8b 3b             	mov    (%rbx),%rdi
  6a30e3:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6a30e8:	4d 89 e8             	mov    %r13,%r8
  6a30eb:	4c 89 e1             	mov    %r12,%rcx
  6a30ee:	e8 fd de e3 ff       	call   4e0ff0 <_ZN4tomo15xshard_completeERNS_6ServerERNS_9ThreadCtxERNS_4RingERKNS_4TaskERNS_2OpE>
  6a30f3:	84 c0                	test   %al,%al
  6a30f5:	0f 84 1b fc ff ff    	je     6a2d16 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  6a30fb:	3c 01                	cmp    $0x1,%al
  6a30fd:	0f 84 19 fc ff ff    	je     6a2d1c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xdc>
  6a3103:	3c 02                	cmp    $0x2,%al
  6a3105:	0f 84 be 07 00 00    	je     6a38c9 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xc89>
  6a310b:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
  6a3111:	0f 84 91 05 00 00    	je     6a36a8 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa68>
  6a3117:	48 8b bb 80 01 00 00 	mov    0x180(%rbx),%rdi
  6a311e:	48 85 ff             	test   %rdi,%rdi
  6a3121:	0f 84 f4 00 00 00    	je     6a321b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x5db>
  6a3127:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6a312b:	49 8b 0c 24          	mov    (%r12),%rcx
  6a312f:	4c 89 ea             	mov    %r13,%rdx
  6a3132:	8b 30                	mov    (%rax),%esi
  6a3134:	e8 d7 9a f9 ff       	call   63cc10 <_ZN4tomo10AofManager16defer_completionEjRNS_2OpEPNS_6ClientE>
  6a3139:	e9 d5 00 00 00       	jmp    6a3213 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x5d3>
  6a313e:	66 90                	xchg   %ax,%ax
  6a3140:	48 8d bb 70 03 00 00 	lea    0x370(%rbx),%rdi
  6a3147:	4c 89 e6             	mov    %r12,%rsi
  6a314a:	e8 31 c9 d8 ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  6a314f:	e9 c2 fb ff ff       	jmp    6a2d16 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  6a3154:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a315f:	90                   	nop
  6a3160:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  6a3167:	0f 85 18 06 00 00    	jne    6a3785 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xb45>
  6a316d:	48 8b 3b             	mov    (%rbx),%rdi
  6a3170:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6a3174:	48 8d 73 10          	lea    0x10(%rbx),%rsi
  6a3178:	4c 8d 4c 24 30       	lea    0x30(%rsp),%r9
  6a317d:	c4 e1 f9 6e c6       	vmovq  %rsi,%xmm0
  6a3182:	4c 89 e6             	mov    %r12,%rsi
  6a3185:	8b 08                	mov    (%rax),%ecx
  6a3187:	48 8d 90 c0 03 00 00 	lea    0x3c0(%rax),%rdx
  6a318e:	c4 e3 f9 22 c2 01    	vpinsrq $0x1,%rdx,%xmm0,%xmm0
  6a3194:	48 8b 93 80 01 00 00 	mov    0x180(%rbx),%rdx
  6a319b:	c5 fa 7f 44 24 38    	vmovdqu %xmm0,0x38(%rsp)
  6a31a1:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
  6a31a5:	44 8b 40 44          	mov    0x44(%rax),%r8d
  6a31a9:	48 85 d2             	test   %rdx,%rdx
  6a31ac:	4c 0f 44 ca          	cmove  %rdx,%r9
  6a31b0:	4c 89 ea             	mov    %r13,%rdx
  6a31b3:	e8 48 e1 e3 ff       	call   4e1300 <_ZN4tomo18multi_execute_taskERNS_6ServerERKNS_4TaskERNS_5ShardEjjPNS_15AofOwnerContextE>
  6a31b8:	41 89 c6             	mov    %eax,%r14d
  6a31bb:	4c 89 ef             	mov    %r13,%rdi
  6a31be:	e8 6d 66 d5 ff       	call   3f9830 <_ZN4tomo5Shard12publish_sizeEv>
  6a31c3:	45 84 f6             	test   %r14b,%r14b
  6a31c6:	0f 84 a4 02 00 00    	je     6a3470 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x830>
  6a31cc:	41 80 fe 02          	cmp    $0x2,%r14b
  6a31d0:	0f 85 40 fb ff ff    	jne    6a2d16 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  6a31d6:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6a31db:	49 8b 0c 24          	mov    (%r12),%rcx
  6a31df:	48 8b bb 80 01 00 00 	mov    0x180(%rbx),%rdi
  6a31e6:	89 c2                	mov    %eax,%edx
  6a31e8:	83 e0 07             	and    $0x7,%eax
  6a31eb:	c1 ea 03             	shr    $0x3,%edx
  6a31ee:	83 e2 07             	and    $0x7,%edx
  6a31f1:	4c 69 e8 50 01 00 00 	imul   $0x150,%rax,%r13
  6a31f8:	4c 03 ac d1 80 00 00 00 	add    0x80(%rcx,%rdx,8),%r13
  6a3200:	48 85 ff             	test   %rdi,%rdi
  6a3203:	74 16                	je     6a321b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x5db>
  6a3205:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6a3209:	4c 89 ea             	mov    %r13,%rdx
  6a320c:	8b 30                	mov    (%rax),%esi
  6a320e:	e8 fd 99 f9 ff       	call   63cc10 <_ZN4tomo10AofManager16defer_completionEjRNS_2OpEPNS_6ClientE>
  6a3213:	84 c0                	test   %al,%al
  6a3215:	0f 85 fb fa ff ff    	jne    6a2d16 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  6a321b:	41 c6 85 b8 00 00 00 02 	movb   $0x2,0xb8(%r13)
  6a3223:	49 8b 34 24          	mov    (%r12),%rsi
  6a3227:	48 89 df             	mov    %rbx,%rdi
  6a322a:	e8 11 e9 ff ff       	call   6a1b40 <_ZN4tomo7ExLoopTILb1EE13notify_senderEPNS_6ClientE>
  6a322f:	e9 e2 fa ff ff       	jmp    6a2d16 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  6a3234:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a323f:	90                   	nop
  6a3240:	45 8b 75 08          	mov    0x8(%r13),%r14d
  6a3244:	e9 fe fc ff ff       	jmp    6a2f47 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x307>
  6a3249:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6a3250:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  6a3257:	0f 84 10 ff ff ff    	je     6a316d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x52d>
  6a325d:	49 8b 14 24          	mov    (%r12),%rdx
  6a3261:	48 85 d2             	test   %rdx,%rdx
  6a3264:	0f 84 1b 05 00 00    	je     6a3785 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xb45>
  6a326a:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6a326f:	48 8b 3b             	mov    (%rbx),%rdi
  6a3272:	89 c1                	mov    %eax,%ecx
  6a3274:	83 e0 07             	and    $0x7,%eax
  6a3277:	c1 e9 03             	shr    $0x3,%ecx
  6a327a:	83 e1 07             	and    $0x7,%ecx
  6a327d:	48 69 c0 50 01 00 00 	imul   $0x150,%rax,%rax
  6a3284:	48 03 84 ca 80 00 00 00 	add    0x80(%rdx,%rcx,8),%rax
  6a328c:	f6 40 1c 10          	testb  $0x10,0x1c(%rax)
  6a3290:	0f 85 f7 04 00 00    	jne    6a378d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xb4d>
  6a3296:	41 c6 85 c9 01 00 00 00 	movb   $0x0,0x1c9(%r13)
  6a329e:	e9 cd fe ff ff       	jmp    6a3170 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x530>
  6a32a3:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a32ae:	66 90                	xchg   %ax,%ax
  6a32b0:	48 83 bb e0 19 00 00 00 	cmpq   $0x0,0x19e0(%rbx)
  6a32b8:	0f 84 9d fc ff ff    	je     6a2f5b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x31b>
  6a32be:	41 80 7d 1c 00       	cmpb   $0x0,0x1c(%r13)
  6a32c3:	0f 89 92 fc ff ff    	jns    6a2f5b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x31b>
  6a32c9:	41 0f b6 87 2b 01 00 00 	movzbl 0x12b(%r15),%eax
  6a32d1:	88 44 24 08          	mov    %al,0x8(%rsp)
  6a32d5:	84 c0                	test   %al,%al
  6a32d7:	0f 84 7e fc ff ff    	je     6a2f5b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x31b>
  6a32dd:	41 80 bf 2a 01 00 00 00 	cmpb   $0x0,0x12a(%r15)
  6a32e5:	74 08                	je     6a32ef <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x6af>
  6a32e7:	41 c6 87 2b 01 00 00 00 	movb   $0x0,0x12b(%r15)
  6a32ef:	4c 89 e6             	mov    %r12,%rsi
  6a32f2:	48 89 df             	mov    %rbx,%rdi
  6a32f5:	e8 56 ec ff ff       	call   6a1f50 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb1EEEbRKNS_4TaskE>
  6a32fa:	41 89 c6             	mov    %eax,%r14d
  6a32fd:	0f b6 44 24 08       	movzbl 0x8(%rsp),%eax
  6a3302:	41 88 87 2b 01 00 00 	mov    %al,0x12b(%r15)
  6a3309:	e9 0e fa ff ff       	jmp    6a2d1c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xdc>
  6a330e:	66 90                	xchg   %ax,%ax
  6a3310:	41 0f b6 45 1c       	movzbl 0x1c(%r13),%eax
  6a3315:	83 e0 10             	and    $0x10,%eax
  6a3318:	84 c0                	test   %al,%al
  6a331a:	41 0f 95 87 c9 01 00 00 	setne  0x1c9(%r15)
  6a3322:	0f 84 60 fc ff ff    	je     6a2f88 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x348>
  6a3328:	48 8b 03             	mov    (%rbx),%rax
  6a332b:	f0 48 ff 80 80 4c 01 00 	lock incq 0x14c80(%rax)
  6a3333:	e9 50 fc ff ff       	jmp    6a2f88 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x348>
  6a3338:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6a3340:	49 8b 55 00          	mov    0x0(%r13),%rdx
  6a3344:	f7 42 10 01 04 00 00 	testl  $0x401,0x10(%rdx)
  6a334b:	0f 84 c4 fc ff ff    	je     6a3015 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x3d5>
  6a3351:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6a3356:	41 80 7f 08 00       	cmpb   $0x0,0x8(%r15)
  6a335b:	0f 85 a7 04 00 00    	jne    6a3808 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xbc8>
  6a3361:	49 8b 44 24 18       	mov    0x18(%r12),%rax
  6a3366:	e9 aa fc ff ff       	jmp    6a3015 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x3d5>
  6a336b:	48 8d bb 30 02 00 00 	lea    0x230(%rbx),%rdi
  6a3372:	4c 89 e6             	mov    %r12,%rsi
  6a3375:	e8 06 c7 d8 ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  6a337a:	e9 97 f9 ff ff       	jmp    6a2d16 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  6a337f:	90                   	nop
  6a3380:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  6a3384:	41 8b 47 18          	mov    0x18(%r15),%eax
  6a3388:	8b 56 44             	mov    0x44(%rsi),%edx
  6a338b:	49 ff 87 e8 03 00 00 	incq   0x3e8(%r15)
  6a3392:	83 f8 ff             	cmp    $0xffffffff,%eax
  6a3395:	0f 84 97 03 00 00    	je     6a3732 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xaf2>
  6a339b:	39 d0                	cmp    %edx,%eax
  6a339d:	74 07                	je     6a33a6 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x766>
  6a339f:	49 ff 87 10 04 00 00 	incq   0x410(%r15)
  6a33a6:	8b 93 8c 01 00 00    	mov    0x18c(%rbx),%edx
  6a33ac:	49 8b 4d 10          	mov    0x10(%r13),%rcx
  6a33b0:	85 d2                	test   %edx,%edx
  6a33b2:	74 14                	je     6a33c8 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x788>
  6a33b4:	8b 83 90 01 00 00    	mov    0x190(%rbx),%eax
  6a33ba:	ff c8                	dec    %eax
  6a33bc:	0f 84 5e 02 00 00    	je     6a3620 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x9e0>
  6a33c2:	89 83 90 01 00 00    	mov    %eax,0x190(%rbx)
  6a33c8:	48 8b 3b             	mov    (%rbx),%rdi
  6a33cb:	48 8d 53 10          	lea    0x10(%rbx),%rdx
  6a33cf:	4d 89 e9             	mov    %r13,%r9
  6a33d2:	4d 89 f8             	mov    %r15,%r8
  6a33d5:	4c 89 e1             	mov    %r12,%rcx
  6a33d8:	e8 53 9e e2 ff       	call   4cd230 <_ZN4tomo16blocking_executeERNS_6ServerERNS_9ThreadCtxERNS_4RingERKNS_4TaskERNS_5ShardERNS_2OpE>
  6a33dd:	41 89 c6             	mov    %eax,%r14d
  6a33e0:	e9 37 f9 ff ff       	jmp    6a2d1c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xdc>
  6a33e5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a33f0:	4e 8b 24 f0          	mov    (%rax,%r14,8),%r12
  6a33f4:	0f b6 93 8a 01 00 00 	movzbl 0x18a(%rbx),%edx
  6a33fb:	48 8b 83 58 01 00 00 	mov    0x158(%rbx),%rax
  6a3402:	41 88 94 24 c8 01 00 00 	mov    %dl,0x1c8(%r12)
  6a340a:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  6a3411:	49 89 44 24 10       	mov    %rax,0x10(%r12)
  6a3416:	49 89 84 24 c0 01 00 00 	mov    %rax,0x1c0(%r12)
  6a341e:	0f 85 7e 03 00 00    	jne    6a37a2 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xb62>
  6a3424:	48 8b 3b             	mov    (%rbx),%rdi
  6a3427:	ba 20 00 00 00       	mov    $0x20,%edx
  6a342c:	4c 89 e6             	mov    %r12,%rsi
  6a342f:	e8 cc 59 e2 ff       	call   4c8e00 <_ZN4tomo20xshard_cleanup_shardERNS_6ServerERNS_5ShardEj>
  6a3434:	4c 89 e7             	mov    %r12,%rdi
  6a3437:	e8 f4 63 d5 ff       	call   3f9830 <_ZN4tomo5Shard12publish_sizeEv>
  6a343c:	e9 d5 f8 ff ff       	jmp    6a2d16 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  6a3441:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a344c:	0f 1f 40 00          	nopl   0x0(%rax)
  6a3450:	48 8d 83 30 02 00 00 	lea    0x230(%rbx),%rax
  6a3457:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6a345c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6a3461:	4c 89 e6             	mov    %r12,%rsi
  6a3464:	e8 17 c6 d8 ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  6a3469:	e9 a8 f8 ff ff       	jmp    6a2d16 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  6a346e:	66 90                	xchg   %ax,%ax
  6a3470:	48 8d bb 80 02 00 00 	lea    0x280(%rbx),%rdi
  6a3477:	4c 89 e6             	mov    %r12,%rsi
  6a347a:	e8 01 c6 d8 ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  6a347f:	e9 92 f8 ff ff       	jmp    6a2d16 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  6a3484:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a348f:	90                   	nop
  6a3490:	4d 8b 75 00          	mov    0x0(%r13),%r14
  6a3494:	41 0f b7 76 26       	movzwl 0x26(%r14),%esi
  6a3499:	e8 12 69 d5 ff       	call   3f9db0 <_ZN4tomo9ThreadCtx12note_commandEt>
  6a349e:	41 f6 46 11 01       	testb  $0x1,0x11(%r14)
  6a34a3:	0f 85 77 03 00 00    	jne    6a3820 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xbe0>
  6a34a9:	48 83 bb e0 19 00 00 00 	cmpq   $0x0,0x19e0(%rbx)
  6a34b1:	0f 84 84 02 00 00    	je     6a373b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xafb>
  6a34b7:	49 8b 45 00          	mov    0x0(%r13),%rax
  6a34bb:	8b 50 10             	mov    0x10(%rax),%edx
  6a34be:	f7 c2 01 04 00 00    	test   $0x401,%edx
  6a34c4:	0f 84 b6 01 00 00    	je     6a3680 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa40>
  6a34ca:	41 83 bd b4 00 00 00 fd 	cmpl   $0xfffffffd,0xb4(%r13)
  6a34d2:	74 09                	je     6a34dd <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x89d>
  6a34d4:	80 e6 08             	and    $0x8,%dh
  6a34d7:	0f 84 a3 01 00 00    	je     6a3680 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa40>
  6a34dd:	49 8b 04 24          	mov    (%r12),%rax
  6a34e1:	48 8b 3b             	mov    (%rbx),%rdi
  6a34e4:	4c 8d 44 24 30       	lea    0x30(%rsp),%r8
  6a34e9:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
  6a34ed:	4c 89 ea             	mov    %r13,%rdx
  6a34f0:	62 f1 7f 28 7f 84 24 30 00 00 00 	vmovdqu8 %ymm0,0x30(%rsp)
  6a34fb:	4c 89 fe             	mov    %r15,%rsi
  6a34fe:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  6a3503:	48 8b 88 a8 07 00 00 	mov    0x7a8(%rax),%rcx
  6a350a:	c5 f8 77             	vzeroupper
  6a350d:	e8 fe 62 e2 ff       	call   4c9810 <_ZN4tomo20xshard_plain_prepareERNS_6ServerERNS_5ShardERNS_2OpEmRNS_21PlainForeignReadScopeE>
  6a3512:	88 44 24 07          	mov    %al,0x7(%rsp)
  6a3516:	4d 8b b7 b0 04 00 00 	mov    0x4b0(%r15),%r14
  6a351d:	4d 85 f6             	test   %r14,%r14
  6a3520:	0f 85 be 03 00 00    	jne    6a38e4 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xca4>
  6a3526:	84 c0                	test   %al,%al
  6a3528:	0f 84 b2 02 00 00    	je     6a37e0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xba0>
  6a352e:	49 8b 45 00          	mov    0x0(%r13),%rax
  6a3532:	4c 89 ee             	mov    %r13,%rsi
  6a3535:	4c 89 ff             	mov    %r15,%rdi
  6a3538:	ff 50 18             	call   *0x18(%rax)
  6a353b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  6a3540:	4c 89 ff             	mov    %r15,%rdi
  6a3543:	e8 a8 0d e0 ff       	call   4a42f0 <_ZN4tomo19xshard_plain_finishERNS_5ShardERNS_21PlainForeignReadScopeE>
  6a3548:	4d 85 f6             	test   %r14,%r14
  6a354b:	0f 85 d9 03 00 00    	jne    6a392a <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xcea>
  6a3551:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  6a3556:	48 85 ff             	test   %rdi,%rdi
  6a3559:	0f 84 ac fb ff ff    	je     6a310b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4cb>
  6a355f:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  6a3564:	48 29 fe             	sub    %rdi,%rsi
  6a3567:	e8 34 96 97 ff       	call   1cba0 <_ZdlPvm@plt>
  6a356c:	e9 9a fb ff ff       	jmp    6a310b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4cb>
  6a3571:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a357c:	0f 1f 40 00          	nopl   0x0(%rax)
  6a3580:	48 8d 83 30 02 00 00 	lea    0x230(%rbx),%rax
  6a3587:	45 89 f0             	mov    %r14d,%r8d
  6a358a:	4c 89 e9             	mov    %r13,%rcx
  6a358d:	4c 89 e2             	mov    %r12,%rdx
  6a3590:	48 89 c6             	mov    %rax,%rsi
  6a3593:	48 89 df             	mov    %rbx,%rdi
  6a3596:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6a359b:	e8 80 e1 ff ff       	call   6a1720 <_ZN4tomo7ExLoopTILb1EE21parked_predecessor_inERKSt5dequeINS_4TaskESaIS3_EERKS3_RNS_2OpEi>
  6a35a0:	84 c0                	test   %al,%al
  6a35a2:	0f 85 b4 fe ff ff    	jne    6a345c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x81c>
  6a35a8:	48 8d b3 d0 02 00 00 	lea    0x2d0(%rbx),%rsi
  6a35af:	45 89 f0             	mov    %r14d,%r8d
  6a35b2:	4c 89 e9             	mov    %r13,%rcx
  6a35b5:	4c 89 e2             	mov    %r12,%rdx
  6a35b8:	48 89 df             	mov    %rbx,%rdi
  6a35bb:	e8 60 e1 ff ff       	call   6a1720 <_ZN4tomo7ExLoopTILb1EE21parked_predecessor_inERKSt5dequeINS_4TaskESaIS3_EERKS3_RNS_2OpEi>
  6a35c0:	84 c0                	test   %al,%al
  6a35c2:	0f 85 94 fe ff ff    	jne    6a345c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x81c>
  6a35c8:	e9 1e fa ff ff       	jmp    6a2feb <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x3ab>
  6a35cd:	0f 1f 00             	nopl   (%rax)
  6a35d0:	83 e1 07             	and    $0x7,%ecx
  6a35d3:	4c 8d bb 30 02 00 00 	lea    0x230(%rbx),%r15
  6a35da:	45 89 f0             	mov    %r14d,%r8d
  6a35dd:	4c 89 e2             	mov    %r12,%rdx
  6a35e0:	48 69 c9 50 01 00 00 	imul   $0x150,%rcx,%rcx
  6a35e7:	4c 89 fe             	mov    %r15,%rsi
  6a35ea:	48 89 df             	mov    %rbx,%rdi
  6a35ed:	48 01 c8             	add    %rcx,%rax
  6a35f0:	48 89 c1             	mov    %rax,%rcx
  6a35f3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6a35f8:	e8 23 e1 ff ff       	call   6a1720 <_ZN4tomo7ExLoopTILb1EE21parked_predecessor_inERKSt5dequeINS_4TaskESaIS3_EERKS3_RNS_2OpEi>
  6a35fd:	84 c0                	test   %al,%al
  6a35ff:	0f 84 59 01 00 00    	je     6a375e <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xb1e>
  6a3605:	4c 89 e6             	mov    %r12,%rsi
  6a3608:	4c 89 ff             	mov    %r15,%rdi
  6a360b:	e8 70 c4 d8 ff       	call   42fa80 <_ZNSt5dequeIN4tomo4TaskESaIS1_EE9push_backERKS1_>
  6a3610:	e9 01 f7 ff ff       	jmp    6a2d16 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  6a3615:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a3620:	49 8b 87 78 05 00 00 	mov    0x578(%r15),%rax
  6a3627:	81 e1 ff 3f 00 00    	and    $0x3fff,%ecx
  6a362d:	89 93 90 01 00 00    	mov    %edx,0x190(%rbx)
  6a3633:	48 85 c0             	test   %rax,%rax
  6a3636:	0f 84 8c fd ff ff    	je     6a33c8 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x788>
  6a363c:	41 0f b7 7f 04       	movzwl 0x4(%r15),%edi
  6a3641:	39 f9                	cmp    %edi,%ecx
  6a3643:	0f 82 7f fd ff ff    	jb     6a33c8 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x788>
  6a3649:	45 0f b7 47 06       	movzwl 0x6(%r15),%r8d
  6a364e:	44 39 c1             	cmp    %r8d,%ecx
  6a3651:	0f 83 71 fd ff ff    	jae    6a33c8 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x788>
  6a3657:	29 f9                	sub    %edi,%ecx
  6a3659:	01 14 88             	add    %edx,(%rax,%rcx,4)
  6a365c:	e9 67 fd ff ff       	jmp    6a33c8 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x788>
  6a3661:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a366c:	0f 1f 40 00          	nopl   0x0(%rax)
  6a3670:	41 89 4f 18          	mov    %ecx,0x18(%r15)
  6a3674:	e9 c2 f9 ff ff       	jmp    6a303b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x3fb>
  6a3679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6a3680:	49 8b 97 00 01 00 00 	mov    0x100(%r15),%rdx
  6a3687:	48 85 d2             	test   %rdx,%rdx
  6a368a:	74 0e                	je     6a369a <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa5a>
  6a368c:	48 83 ba 10 02 00 00 00 	cmpq   $0x0,0x210(%rdx)
  6a3694:	0f 85 43 fe ff ff    	jne    6a34dd <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x89d>
  6a369a:	4c 89 ee             	mov    %r13,%rsi
  6a369d:	4c 89 ff             	mov    %r15,%rdi
  6a36a0:	ff 50 18             	call   *0x18(%rax)
  6a36a3:	e9 63 fa ff ff       	jmp    6a310b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4cb>
  6a36a8:	49 8b 55 10          	mov    0x10(%r13),%rdx
  6a36ac:	4c 89 fe             	mov    %r15,%rsi
  6a36af:	48 89 df             	mov    %rbx,%rdi
  6a36b2:	e8 d9 df ff ff       	call   6a1690 <_ZN4tomo7ExLoopTILb1EE12note_lb_hashERNS_5ShardEm>
  6a36b7:	49 8b 45 00          	mov    0x0(%r13),%rax
  6a36bb:	f7 40 10 01 04 00 00 	testl  $0x401,0x10(%rax)
  6a36c2:	0f 85 e8 00 00 00    	jne    6a37b0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xb70>
  6a36c8:	48 83 bb 80 01 00 00 00 	cmpq   $0x0,0x180(%rbx)
  6a36d0:	0f 84 45 fb ff ff    	je     6a321b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x5db>
  6a36d6:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6a36da:	48 8d 7b 10          	lea    0x10(%rbx),%rdi
  6a36de:	4c 89 ee             	mov    %r13,%rsi
  6a36e1:	c4 e1 f9 6e c7       	vmovq  %rdi,%xmm0
  6a36e6:	4c 89 ff             	mov    %r15,%rdi
  6a36e9:	8b 10                	mov    (%rax),%edx
  6a36eb:	48 05 c0 03 00 00    	add    $0x3c0,%rax
  6a36f1:	c4 e3 f9 22 c0 01    	vpinsrq $0x1,%rax,%xmm0,%xmm0
  6a36f7:	c5 fa 7f 44 24 38    	vmovdqu %xmm0,0x38(%rsp)
  6a36fd:	89 54 24 30          	mov    %edx,0x30(%rsp)
  6a3701:	41 83 bd b4 00 00 00 fd 	cmpl   $0xfffffffd,0xb4(%r13)
  6a3709:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
  6a370e:	0f 84 6c 02 00 00    	je     6a3980 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd40>
  6a3714:	e8 97 19 fa ff       	call   6450b0 <_ZN4tomo19aof_record_local_opERNS_5ShardERNS_2OpERNS_15AofOwnerContextE>
  6a3719:	e9 f9 f9 ff ff       	jmp    6a3117 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4d7>
  6a371e:	66 90                	xchg   %ax,%ax
  6a3720:	80 bb 88 01 00 00 00 	cmpb   $0x0,0x188(%rbx)
  6a3727:	0f 84 40 fa ff ff    	je     6a316d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x52d>
  6a372d:	e9 38 fb ff ff       	jmp    6a326a <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x62a>
  6a3732:	41 89 57 18          	mov    %edx,0x18(%r15)
  6a3736:	e9 6b fc ff ff       	jmp    6a33a6 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x766>
  6a373b:	49 8b 87 00 01 00 00 	mov    0x100(%r15),%rax
  6a3742:	48 85 c0             	test   %rax,%rax
  6a3745:	74 0e                	je     6a3755 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xb15>
  6a3747:	48 83 b8 10 02 00 00 00 	cmpq   $0x0,0x210(%rax)
  6a374f:	0f 85 88 fd ff ff    	jne    6a34dd <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x89d>
  6a3755:	49 8b 45 00          	mov    0x0(%r13),%rax
  6a3759:	e9 3c ff ff ff       	jmp    6a369a <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa5a>
  6a375e:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6a3763:	48 8d b3 d0 02 00 00 	lea    0x2d0(%rbx),%rsi
  6a376a:	45 89 f0             	mov    %r14d,%r8d
  6a376d:	4c 89 e2             	mov    %r12,%rdx
  6a3770:	48 89 df             	mov    %rbx,%rdi
  6a3773:	e8 a8 df ff ff       	call   6a1720 <_ZN4tomo7ExLoopTILb1EE21parked_predecessor_inERKSt5dequeINS_4TaskESaIS3_EERKS3_RNS_2OpEi>
  6a3778:	84 c0                	test   %al,%al
  6a377a:	0f 85 85 fe ff ff    	jne    6a3605 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x9c5>
  6a3780:	e9 5f f6 ff ff       	jmp    6a2de4 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x1a4>
  6a3785:	48 8b 3b             	mov    (%rbx),%rdi
  6a3788:	e9 09 fb ff ff       	jmp    6a3296 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x656>
  6a378d:	41 c6 85 c9 01 00 00 01 	movb   $0x1,0x1c9(%r13)
  6a3795:	f0 48 ff 87 80 4c 01 00 	lock incq 0x14c80(%rdi)
  6a379d:	e9 cb f9 ff ff       	jmp    6a316d <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x52d>
  6a37a2:	41 c6 84 24 c9 01 00 00 00 	movb   $0x0,0x1c9(%r12)
  6a37ab:	e9 74 fc ff ff       	jmp    6a3424 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x7e4>
  6a37b0:	4c 89 ff             	mov    %r15,%rdi
  6a37b3:	e8 a8 2e ff ff       	call   696660 <_ZNK4tomo5Shard11has_watchesEv>
  6a37b8:	84 c0                	test   %al,%al
  6a37ba:	0f 85 b0 01 00 00    	jne    6a3970 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd30>
  6a37c0:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
  6a37c6:	0f 84 fc fe ff ff    	je     6a36c8 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xa88>
  6a37cc:	e9 46 f9 ff ff       	jmp    6a3117 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4d7>
  6a37d1:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6a37dc:	0f 1f 40 00          	nopl   0x0(%rax)
  6a37e0:	4c 89 ef             	mov    %r13,%rdi
  6a37e3:	e8 f8 6b 08 00       	call   72a3e0 <_ZN4tomo22l4prebuild_discard_setERNS_2OpE>
  6a37e8:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  6a37ed:	4c 89 ff             	mov    %r15,%rdi
  6a37f0:	e8 fb 0a e0 ff       	call   4a42f0 <_ZN4tomo19xshard_plain_finishERNS_5ShardERNS_21PlainForeignReadScopeE>
  6a37f5:	e9 57 fd ff ff       	jmp    6a3551 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x911>
  6a37fa:	49 83 bf d8 04 00 00 00 	cmpq   $0x0,0x4d8(%r15)
  6a3802:	0f 84 ae 00 00 00    	je     6a38b6 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xc76>
  6a3808:	4c 89 ee             	mov    %r13,%rsi
  6a380b:	4c 89 ff             	mov    %r15,%rdi
  6a380e:	e8 1d 3e e3 ff       	call   4d7630 <_ZN4tomo23multi_plain_write_readyERNS_5ShardERNS_2OpE>
  6a3813:	84 c0                	test   %al,%al
  6a3815:	0f 85 46 fb ff ff    	jne    6a3361 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x721>
  6a381b:	e9 fc f4 ff ff       	jmp    6a2d1c <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xdc>
  6a3820:	49 8b 95 c0 00 00 00 	mov    0xc0(%r13),%rdx
  6a3827:	41 0f bf 46 20       	movswl 0x20(%r14),%eax
  6a382c:	49 8d 7f 38          	lea    0x38(%r15),%rdi
  6a3830:	48 85 d2             	test   %rdx,%rdx
  6a3833:	0f 84 e1 00 00 00    	je     6a391a <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xcda>
  6a3839:	48 c1 e0 04          	shl    $0x4,%rax
  6a383d:	48 01 d0             	add    %rdx,%rax
  6a3840:	48 8b 30             	mov    (%rax),%rsi
  6a3843:	48 8b 50 08          	mov    0x8(%rax),%rdx
  6a3847:	e8 d4 6c d6 ff       	call   40a520 <_ZN4tomo9FlatStore12budget_admitENS_5SliceE>
  6a384c:	84 c0                	test   %al,%al
  6a384e:	0f 85 55 fc ff ff    	jne    6a34a9 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x869>
  6a3854:	4c 89 ef             	mov    %r13,%rdi
  6a3857:	e8 14 be e9 ff       	call   53f670 <_ZN4tomo19reply_maxmemory_oomERNS_2OpE>
  6a385c:	4c 89 ef             	mov    %r13,%rdi
  6a385f:	e8 7c 6b 08 00       	call   72a3e0 <_ZN4tomo22l4prebuild_discard_setERNS_2OpE>
  6a3864:	e9 a2 f8 ff ff       	jmp    6a310b <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4cb>
  6a3869:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6a386d:	c5 fa 7e 54 24 08    	vmovq  0x8(%rsp),%xmm2
  6a3873:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
  6a3878:	4c 89 fe             	mov    %r15,%rsi
  6a387b:	4c 89 e7             	mov    %r12,%rdi
  6a387e:	8b 10                	mov    (%rax),%edx
  6a3880:	48 05 c0 03 00 00    	add    $0x3c0,%rax
  6a3886:	c4 e3 e9 22 c0 01    	vpinsrq $0x1,%rax,%xmm2,%xmm0
  6a388c:	c5 fa 7f 44 24 38    	vmovdqu %xmm0,0x38(%rsp)
  6a3892:	89 54 24 30          	mov    %edx,0x30(%rsp)
  6a3896:	4c 89 ea             	mov    %r13,%rdx
  6a3899:	e8 82 e8 df ff       	call   4a2120 <_ZN4tomo15xshard_aof_emitERKNS_4TaskERNS_5ShardERNS_2OpERNS_15AofOwnerContextE>
  6a389e:	e9 31 f8 ff ff       	jmp    6a30d4 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x494>
  6a38a3:	4c 89 ea             	mov    %r13,%rdx
  6a38a6:	4c 89 fe             	mov    %r15,%rsi
  6a38a9:	4c 89 e7             	mov    %r12,%rdi
  6a38ac:	e8 3f 96 e2 ff       	call   4ccef0 <_ZN4tomo35blocking_scatter_mutation_publishedERKNS_4TaskERNS_5ShardERNS_2OpE>
  6a38b1:	e9 07 f8 ff ff       	jmp    6a30bd <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x47d>
  6a38b6:	49 83 bf 10 05 00 00 00 	cmpq   $0x0,0x510(%r15)
  6a38be:	0f 84 9d fa ff ff    	je     6a3361 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x721>
  6a38c4:	e9 3f ff ff ff       	jmp    6a3808 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xbc8>
  6a38c9:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  6a38cd:	48 8b 3b             	mov    (%rbx),%rdi
  6a38d0:	4c 89 e2             	mov    %r12,%rdx
  6a38d3:	e8 08 ed df ff       	call   4a25e0 <_ZN4tomo19xshard_queue_commitERNS_6ServerERNS_9ThreadCtxERKNS_4TaskE>
  6a38d8:	c6 83 da 15 00 00 01 	movb   $0x1,0x15da(%rbx)
  6a38df:	e9 32 f4 ff ff       	jmp    6a2d16 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd6>
  6a38e4:	bf 01 00 00 00       	mov    $0x1,%edi
  6a38e9:	e8 92 0d e0 ff       	call   4a4680 <_ZN4tomo32blocking_defer_plain_publicationEb>
  6a38ee:	80 7c 24 07 00       	cmpb   $0x0,0x7(%rsp)
  6a38f3:	0f 85 35 fc ff ff    	jne    6a352e <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x8ee>
  6a38f9:	4c 89 ef             	mov    %r13,%rdi
  6a38fc:	e8 df 6a 08 00       	call   72a3e0 <_ZN4tomo22l4prebuild_discard_setERNS_2OpE>
  6a3901:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  6a3906:	4c 89 ff             	mov    %r15,%rdi
  6a3909:	e8 e2 09 e0 ff       	call   4a42f0 <_ZN4tomo19xshard_plain_finishERNS_5ShardERNS_21PlainForeignReadScopeE>
  6a390e:	31 ff                	xor    %edi,%edi
  6a3910:	e8 6b 0d e0 ff       	call   4a4680 <_ZN4tomo32blocking_defer_plain_publicationEb>
  6a3915:	e9 37 fc ff ff       	jmp    6a3551 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x911>
  6a391a:	48 83 c0 0d          	add    $0xd,%rax
  6a391e:	48 c1 e0 04          	shl    $0x4,%rax
  6a3922:	4c 01 e8             	add    %r13,%rax
  6a3925:	e9 16 ff ff ff       	jmp    6a3840 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xc00>
  6a392a:	31 ff                	xor    %edi,%edi
  6a392c:	e8 4f 0d e0 ff       	call   4a4680 <_ZN4tomo32blocking_defer_plain_publicationEb>
  6a3931:	4c 89 ee             	mov    %r13,%rsi
  6a3934:	4c 89 ff             	mov    %r15,%rdi
  6a3937:	e8 f4 93 e2 ff       	call   4ccd30 <_ZN4tomo33blocking_plain_mutation_publishedERNS_5ShardERNS_2OpE>
  6a393c:	e9 10 fc ff ff       	jmp    6a3551 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x911>
  6a3941:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6a3946:	c5 f8 77             	vzeroupper
  6a3949:	e8 a2 dd ff ff       	call   6a16f0 <_ZNSt6vectorIN4tomo21PlainForeignReadScope3KeyESaIS2_EED1Ev>
  6a394e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6a3953:	c5 f8 77             	vzeroupper
  6a3956:	e8 75 7e d5 ff       	call   3fb7d0 <_ZN4tomo6Server15ClientWorkScopeD1Ev>
  6a395b:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  6a3960:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
  6a3969:	74 48                	je     6a39b3 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd73>
  6a396b:	e8 30 8e 97 ff       	call   1c7a0 <__stack_chk_fail@plt>
  6a3970:	4c 89 ee             	mov    %r13,%rsi
  6a3973:	4c 89 ff             	mov    %r15,%rdi
  6a3976:	e8 85 45 e3 ff       	call   4d7f00 <_ZN4tomo27multi_plain_write_committedERNS_5ShardERNS_2OpE>
  6a397b:	e9 40 fe ff ff       	jmp    6a37c0 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xb80>
  6a3980:	e8 6b 6a e0 ff       	call   4aa3f0 <_ZN4tomo21xshard_aof_emit_localERNS_5ShardERNS_2OpERNS_15AofOwnerContextE>
  6a3985:	e9 8d f7 ff ff       	jmp    6a3117 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0x4d7>
  6a398a:	f3 0f 1e fa          	endbr64
  6a398e:	48 89 c3             	mov    %rax,%rbx
  6a3991:	eb ae                	jmp    6a3941 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd01>
  6a3993:	f3 0f 1e fa          	endbr64
  6a3997:	48 89 c3             	mov    %rax,%rbx
  6a399a:	eb 09                	jmp    6a39a5 <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd65>
  6a399c:	f3 0f 1e fa          	endbr64
  6a39a0:	48 89 c3             	mov    %rax,%rbx
  6a39a3:	eb a9                	jmp    6a394e <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd0e>
  6a39a5:	0f b6 44 24 08       	movzbl 0x8(%rsp),%eax
  6a39aa:	41 88 87 2b 01 00 00 	mov    %al,0x12b(%r15)
  6a39b1:	eb 9b                	jmp    6a394e <_ZN4tomo7ExLoopTILb1EE7executeILb0ELb0EEEbRKNS_4TaskE+0xd0e>
  6a39b3:	48 89 df             	mov    %rbx,%rdi
  6a39b6:	e8 b5 93 97 ff       	call   1cd70 <_Unwind_Resume@plt>

Disassembly of section .rlfence:

Disassembly of section .fini:
