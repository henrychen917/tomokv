
build/exbatch-unit:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

000000000002e3f0 <_ZN12_GLOBAL__N_17publishERN4tomo5ShardE>:
   2e3f0:	e9 2b b2 00 00       	jmp    39620 <_ZN4tomo5Shard12publish_sizeEv>

Disassembly of section .rlfence:

Disassembly of section .fini:
