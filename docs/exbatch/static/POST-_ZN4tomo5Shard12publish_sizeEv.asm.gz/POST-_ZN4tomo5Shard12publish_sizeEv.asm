
build/exbatch-unit:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

0000000000039620 <_ZN4tomo5Shard12publish_sizeEv>:
   39620:	f3 0f 1e fa          	endbr64
   39624:	48 89 f8             	mov    %rdi,%rax
   39627:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   3962c:	8b 97 8c 01 00 00    	mov    0x18c(%rdi),%edx
   39632:	03 97 88 01 00 00    	add    0x188(%rdi),%edx
   39638:	8b 4f 1c             	mov    0x1c(%rdi),%ecx
   3963b:	39 d1                	cmp    %edx,%ecx
   3963d:	0f 85 ad 00 00 00    	jne    396f0 <_ZN4tomo5Shard12publish_sizeEv+0xd0>
   39643:	48 8b 50 38          	mov    0x38(%rax),%rdx
   39647:	48 03 90 a0 01 00 00 	add    0x1a0(%rax),%rdx
   3964e:	48 8b 48 20          	mov    0x20(%rax),%rcx
   39652:	48 39 d1             	cmp    %rdx,%rcx
   39655:	0f 85 85 00 00 00    	jne    396e0 <_ZN4tomo5Shard12publish_sizeEv+0xc0>
   3965b:	8b 90 54 02 00 00    	mov    0x254(%rax),%edx
   39661:	03 90 50 02 00 00    	add    0x250(%rax),%edx
   39667:	8b 48 28             	mov    0x28(%rax),%ecx
   3966a:	39 ca                	cmp    %ecx,%edx
   3966c:	75 52                	jne    396c0 <_ZN4tomo5Shard12publish_sizeEv+0xa0>
   3966e:	48 8b 90 08 04 00 00 	mov    0x408(%rax),%rdx
   39675:	48 8b 48 30          	mov    0x30(%rax),%rcx
   39679:	48 39 ca             	cmp    %rcx,%rdx
   3967c:	75 36                	jne    396b4 <_ZN4tomo5Shard12publish_sizeEv+0x94>
   3967e:	c3                   	ret
   3967f:	90                   	nop
   39680:	8b 97 8c 01 00 00    	mov    0x18c(%rdi),%edx
   39686:	03 97 88 01 00 00    	add    0x188(%rdi),%edx
   3968c:	89 57 1c             	mov    %edx,0x1c(%rdi)
   3968f:	48 8b 57 38          	mov    0x38(%rdi),%rdx
   39693:	48 03 97 a0 01 00 00 	add    0x1a0(%rdi),%rdx
   3969a:	48 89 57 20          	mov    %rdx,0x20(%rdi)
   3969e:	8b 97 54 02 00 00    	mov    0x254(%rdi),%edx
   396a4:	03 97 50 02 00 00    	add    0x250(%rdi),%edx
   396aa:	89 57 28             	mov    %edx,0x28(%rdi)
   396ad:	48 8b 97 08 04 00 00 	mov    0x408(%rdi),%rdx
   396b4:	48 89 50 30          	mov    %rdx,0x30(%rax)
   396b8:	c3                   	ret
   396b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   396c0:	89 50 28             	mov    %edx,0x28(%rax)
   396c3:	48 8b 90 08 04 00 00 	mov    0x408(%rax),%rdx
   396ca:	48 8b 48 30          	mov    0x30(%rax),%rcx
   396ce:	48 39 ca             	cmp    %rcx,%rdx
   396d1:	74 ab                	je     3967e <_ZN4tomo5Shard12publish_sizeEv+0x5e>
   396d3:	eb df                	jmp    396b4 <_ZN4tomo5Shard12publish_sizeEv+0x94>
   396d5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   396e0:	48 89 50 20          	mov    %rdx,0x20(%rax)
   396e4:	e9 72 ff ff ff       	jmp    3965b <_ZN4tomo5Shard12publish_sizeEv+0x3b>
   396e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   396f0:	89 57 1c             	mov    %edx,0x1c(%rdi)
   396f3:	e9 4b ff ff ff       	jmp    39643 <_ZN4tomo5Shard12publish_sizeEv+0x23>

Disassembly of section .rlfence:

Disassembly of section .fini:
