
build/exbatch/PRE/unit:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

000000000002d1f0 <_ZN12_GLOBAL__N_17watchesERKN4tomo5ShardE>:
   2d1f0:	48 83 bf d8 04 00 00 00 	cmpq   $0x0,0x4d8(%rdi)
   2d1f8:	b8 01 00 00 00       	mov    $0x1,%eax
   2d1fd:	75 0b                	jne    2d20a <_ZN12_GLOBAL__N_17watchesERKN4tomo5ShardE+0x1a>
   2d1ff:	48 83 bf 10 05 00 00 00 	cmpq   $0x0,0x510(%rdi)
   2d207:	0f 95 c0             	setne  %al
   2d20a:	c3                   	ret

Disassembly of section .rlfence:

Disassembly of section .fini:
