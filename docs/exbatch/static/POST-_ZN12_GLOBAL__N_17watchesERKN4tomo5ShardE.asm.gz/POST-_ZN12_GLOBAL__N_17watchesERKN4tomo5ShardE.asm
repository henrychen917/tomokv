
build/exbatch-unit:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

000000000002d2f0 <_ZN12_GLOBAL__N_17watchesERKN4tomo5ShardE>:
   2d2f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   2d2f5:	0f b6 47 08          	movzbl 0x8(%rdi),%eax
   2d2f9:	c3                   	ret
   2d2fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2d300:	48 83 bf d8 04 00 00 00 	cmpq   $0x0,0x4d8(%rdi)
   2d308:	b8 01 00 00 00       	mov    $0x1,%eax
   2d30d:	74 01                	je     2d310 <_ZN12_GLOBAL__N_17watchesERKN4tomo5ShardE+0x20>
   2d30f:	c3                   	ret
   2d310:	48 83 bf 10 05 00 00 00 	cmpq   $0x0,0x510(%rdi)
   2d318:	0f 95 c0             	setne  %al
   2d31b:	c3                   	ret

Disassembly of section .rlfence:

Disassembly of section .fini:
