set pagination off
set confirm off
set non-stop on
set breakpoint pending on
handle SIGPIPE nostop noprint pass
handle SIGTERM nostop noprint pass
handle SIGINT nostop noprint pass
python
import os, time, json
class Hold(gdb.Breakpoint):
    def stop(self):
        if not str(gdb.parse_and_eval('stage')).endswith('ExDrain'): return False
        self.enabled = False
        with open('/home/user/Projects/cx-fliplisten/build/gate-run.klo5C9/jobs/fliplisten/fliplisten-io-ex-complete/uring-a0/held.json', "w") as f:
            json.dump(dict(pid=gdb.selected_inferior().pid, stage=str(gdb.parse_and_eval('stage'))), f)
        deadline = time.monotonic() + 15
        while not os.path.exists('/home/user/Projects/cx-fliplisten/build/gate-run.klo5C9/jobs/fliplisten/fliplisten-io-ex-complete/uring-a0/release') and time.monotonic() < deadline:
            time.sleep(.005)
        return False
Hold('tomo::IoLoop::flip_publish_stage')
Hold('tomo_db0::IoLoop::flip_publish_stage')
end
run
